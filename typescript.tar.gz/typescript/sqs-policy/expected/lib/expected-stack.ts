import * as cdk from 'aws-cdk-lib';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as sqs from 'aws-cdk-lib/aws-sqs';

export interface ExpectedStackProps extends cdk.StackProps {
  /**
   * The KMS key master ID
   */
  readonly kmsKey: string;
}

/**
 * This stack creates a SQS queue using KMS encryption
 * with a SQS policy allowing the account that the 
 * queue is deployed into the ability to read and write
 * from the queue

 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps) {
    super(scope, id, props);

    // Resources
    const queue = new sqs.CfnQueue(this, 'Queue', {
      delaySeconds: 0,
      fifoQueue: false,
      kmsDataKeyReusePeriodSeconds: 300,
      kmsMasterKeyId: props.kmsKey!,
      maximumMessageSize: 262144,
      messageRetentionPeriod: 345600,
      receiveMessageWaitTimeSeconds: 0,
      visibilityTimeout: 30,
    });
    queue.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.RETAIN;

    const cloudWatchAlarm = new cloudwatch.CfnAlarm(this, 'CloudWatchAlarm', {
      alarmDescription: 'Alarm when there are more than 100 messages in the queue',
      metricName: 'ApproximateNumberOfMessagesVisible',
      namespace: 'AWS/SQS',
      statistic: 'Average',
      period: 300,
      evaluationPeriods: 1,
      threshold: 100,
      comparisonOperator: 'GreaterThanThreshold',
      actionsEnabled: false,
      alarmActions: [
        'arn:aws:sns:REGION:ACCOUNT_ID:YOUR_SNS_TOPIC_ARN',
      ],
      dimensions: [
        {
          name: 'QueueName',
          value: queue.attrQueueName,
        },
      ],
    });

    const queuePolicy = new sqs.CfnQueuePolicy(this, 'QueuePolicy', {
      queues: [
        queue.attrQueueUrl,
      ],
      policyDocument: {
        Statement: [
          {
            Action: [
              'SQS:SendMessage',
              'SQS:ReceiveMessage',
            ],
            Effect: 'Allow',
            Resource: queue.attrArn,
            Principal: {
              AWS: [
                this.account,
              ],
            },
          },
        ],
      },
    });
  }
}
