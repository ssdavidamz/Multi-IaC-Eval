import * as cdk from 'aws-cdk-lib';
import * as sqs from 'aws-cdk-lib/aws-sqs';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * The KMS key master ID
   */
  readonly kmsKey: string;
}

/**
 * This stack creates a SQS queue using KMS encryption
 * with a SQS policy allowing the account that the 
 * queue is deployed into the ability to read and write
 * from the queue

 */
export class InitialStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Resources
    const queue = new sqs.CfnQueue(this, 'Queue', {
      delaySeconds: 0,
      fifoQueue: false,
      kmsDataKeyReusePeriodSeconds: 300,
      kmsMasterKeyId: props.kmsKey!,
      maximumMessageSize: 262144,
      messageRetentionPeriod: 345600,
      receiveMessageWaitTimeSeconds: 0,
      visibilityTimeout: 30,
    });
    queue.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.RETAIN;

    const queuePolicy = new sqs.CfnQueuePolicy(this, 'QueuePolicy', {
      queues: [
        queue.attrQueueUrl,
      ],
      policyDocument: {
        Statement: [
          {
            Action: [
              'SQS:SendMessage',
              'SQS:ReceiveMessage',
            ],
            Effect: 'Allow',
            Resource: queue.attrArn,
            Principal: {
              AWS: [
                this.account,
              ],
            },
          },
        ],
      },
    });
  }
}
