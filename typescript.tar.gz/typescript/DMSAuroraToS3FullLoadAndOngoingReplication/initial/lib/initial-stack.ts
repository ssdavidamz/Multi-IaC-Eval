import * as cdk from 'aws-cdk-lib';
import * as dms from 'aws-cdk-lib/aws-dms';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as s3 from 'aws-cdk-lib/aws-s3';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * The IP address range that can be used to connect to the RDS instances from your local machine. It must be a valid IP CIDR range of the form x.x.x.x/x. Pls get your address using checkip.amazonaws.com or whatsmyip.org
   * @default '0.0.0.0/0'
   */
  readonly clientIp?: string;
  /**
   * If the dms-vpc-role exists in your account, please enter Y, else enter N
   * @default 'N'
   */
  readonly existsDmsvpcRole?: string;
  /**
   * If the dms-cloudwatch-logs-role exists in your account, please enter Y, else enter N
   * @default 'N'
   */
  readonly existsDmsCloudwatchRole?: string;
  /**
   * The ARN of the Aurora DB Cluster Snapshot used to populate the Aurora DB Cluster that will be used as the source for the DMS task.
   * @default 'arn:aws:rds:us-east-1:01234567890123:cluster-snapshot:dms-sampledb-snapshot'
   */
  readonly snapshotIdentifier?: string;
}

/**
 * This CloudFormation sample template DMSAuroraToS3FullLoadAndOngoingReplication creates an Aurora RDS instance and DMS instance in a VPC, and an S3 bucket. The Aurora RDS instance is configured as the DMS Source Endpoint and the S3 bucket is configured as the DMS Target Endpoint. A DMS task is created and configured to migrate existing data and replicate ongoing changes from the source endpoint to the target endpoint. You will be billed for the AWS resources used if you create a stack from this template.
 */
export class InitialStack extends cdk.Stack {
  public readonly stackName;
  public readonly regionName;
  public readonly s3BucketName;
  public readonly auroraEndpoint;

  public constructor(scope: cdk.App, id: string, props: InitialStackProps = {}) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      clientIp: props.clientIp ?? '0.0.0.0/0',
      existsDmsvpcRole: props.existsDmsvpcRole ?? 'N',
      existsDmsCloudwatchRole: props.existsDmsCloudwatchRole ?? 'N',
      snapshotIdentifier: props.snapshotIdentifier ?? 'arn:aws:rds:us-east-1:01234567890123:cluster-snapshot:dms-sampledb-snapshot',
    };

    // Conditions
    const notExistsDmsCloudwatchRole = props.existsDmsCloudwatchRole! === 'N';
    const notExistsDmsvpcRole = props.existsDmsvpcRole! === 'N';

    // Resources
    const dmsCloudwatchRole = notExistsDmsCloudwatchRole
      ? new iam.CfnRole(this, 'DMSCloudwatchRole', {
          roleName: 'dms-cloudwatch-logs-role',
          assumeRolePolicyDocument: {
            Version: '2012-10-17',
            Statement: [
              {
                Effect: 'Allow',
                Principal: {
                  Service: [
                    'dms.amazonaws.com',
                  ],
                },
                Action: [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          managedPolicyArns: [
            'arn:aws:iam::aws:policy/service-role/AmazonDMSCloudWatchLogsRole',
          ],
          path: '/',
        })
      : undefined;
    if (dmsCloudwatchRole != null) {
    }

    const dmsVpcRole = notExistsDmsvpcRole
      ? new iam.CfnRole(this, 'DMSVpcRole', {
          roleName: 'dms-vpc-role',
          assumeRolePolicyDocument: {
            Version: '2012-10-17',
            Statement: [
              {
                Effect: 'Allow',
                Principal: {
                  Service: [
                    'dms.amazonaws.com',
                  ],
                },
                Action: [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          managedPolicyArns: [
            'arn:aws:iam::aws:policy/service-role/AmazonDMSVPCManagementRole',
          ],
          path: '/',
        })
      : undefined;
    if (dmsVpcRole != null) {
    }

    const internetGateway = new ec2.CfnInternetGateway(this, 'InternetGateway', {
      tags: [
        {
          key: 'Application',
          value: this.stackId,
        },
      ],
    });

    const s3Bucket = new s3.CfnBucket(this, 'S3Bucket', {
      bucketEncryption: {
        serverSideEncryptionConfiguration: [
          {
            serverSideEncryptionByDefault: {
              sseAlgorithm: 'AES256',
            },
          },
        ],
      },
      publicAccessBlockConfiguration: {
        blockPublicAcls: true,
        blockPublicPolicy: true,
        ignorePublicAcls: true,
        restrictPublicBuckets: true,
      },
    });
    s3Bucket.cfnOptions.metadata = {
      guard: {
        SuppressedRules: [
          'S3_BUCKET_DEFAULT_LOCK_ENABLED',
          'S3_BUCKET_VERSIONING_ENABLED',
          'S3_BUCKET_REPLICATION_ENABLED',
          'S3_BUCKET_LOGGING_ENABLED',
        ],
      },
    };

    const vpc = new ec2.CfnVPC(this, 'VPC', {
      cidrBlock: '10.0.0.0/24',
      enableDnsSupport: true,
      enableDnsHostnames: true,
      tags: [
        {
          key: 'Application',
          value: this.stackId,
        },
        {
          key: 'Name',
          value: this.stackName,
        },
      ],
    });

    const attachGateway = new ec2.CfnVPCGatewayAttachment(this, 'AttachGateway', {
      vpcId: vpc.ref,
      internetGatewayId: internetGateway.ref,
    });

    const auroraSecurityGroup = new ec2.CfnSecurityGroup(this, 'AuroraSecurityGroup', {
      groupDescription: 'Security group for Aurora SampleDB DB Instance',
      groupName: 'Aurora SampleDB Security Group',
      vpcId: vpc.ref,
      securityGroupIngress: [
        {
          ipProtocol: 'tcp',
          fromPort: 3306,
          toPort: 3306,
          cidrIp: props.clientIp!,
        },
        {
          ipProtocol: 'tcp',
          fromPort: 3306,
          toPort: 3306,
          cidrIp: '10.0.0.0/24',
        },
      ],
    });

    const dbSubnet1 = new ec2.CfnSubnet(this, 'DBSubnet1', {
      vpcId: vpc.ref,
      cidrBlock: '10.0.0.0/26',
      availabilityZone: cdk.Fn.select(0, cdk.Fn.getAzs(undefined)),
      tags: [
        {
          key: 'Application',
          value: this.stackId,
        },
      ],
    });

    const dbSubnet2 = new ec2.CfnSubnet(this, 'DBSubnet2', {
      vpcId: vpc.ref,
      cidrBlock: '10.0.0.64/26',
      availabilityZone: cdk.Fn.select(1, cdk.Fn.getAzs(undefined)),
      tags: [
        {
          key: 'Application',
          value: this.stackId,
        },
      ],
    });

    const dmsSecurityGroup = new ec2.CfnSecurityGroup(this, 'DMSSecurityGroup', {
      groupDescription: 'Security group for DMS Instance',
      groupName: 'DMS Demo Security Group',
      vpcId: vpc.ref,
    });

    const routeTable = new ec2.CfnRouteTable(this, 'RouteTable', {
      vpcId: vpc.ref,
      tags: [
        {
          key: 'Application',
          value: this.stackId,
        },
      ],
    });

    const s3TargetDmsRole = new iam.CfnRole(this, 'S3TargetDMSRole', {
      roleName: 'dms-s3-target-role',
      assumeRolePolicyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'dms.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
      policies: [
        {
          policyName: 'S3AccessForDMSPolicy',
          policyDocument: {
            Version: '2012-10-17',
            Statement: [
              {
                Effect: 'Allow',
                Action: [
                  's3:PutObject',
                  's3:DeleteObject',
                ],
                Resource: [
                  s3Bucket.attrArn,
                  `${s3Bucket.attrArn}/*`,
                ],
              },
              {
                Effect: 'Allow',
                Action: 's3:ListBucket',
                Resource: s3Bucket.attrArn,
              },
            ],
          },
        },
      ],
    });
    s3TargetDmsRole.addDependency(s3Bucket);

    const auroraDbSubnetGroup = new rds.CfnDBSubnetGroup(this, 'AuroraDBSubnetGroup', {
      dbSubnetGroupDescription: 'Subnets available for the Aurora SampleDB DB Instance',
      subnetIds: [
        dbSubnet1.ref,
        dbSubnet2.ref,
      ],
    });

    const dmsReplicationSubnetGroup = new dms.CfnReplicationSubnetGroup(this, 'DMSReplicationSubnetGroup', {
      replicationSubnetGroupDescription: 'Subnets available for DMS',
      subnetIds: [
        dbSubnet1.ref,
        dbSubnet2.ref,
      ],
    });

    const route = new ec2.CfnRoute(this, 'Route', {
      routeTableId: routeTable.ref,
      destinationCidrBlock: '0.0.0.0/0',
      gatewayId: internetGateway.ref,
    });
    route.addDependency(attachGateway);

    const subnetRouteTableAssociation = new ec2.CfnSubnetRouteTableAssociation(this, 'SubnetRouteTableAssociation', {
      subnetId: dbSubnet1.ref,
      routeTableId: routeTable.ref,
    });

    const subnetRouteTableAssociation1 = new ec2.CfnSubnetRouteTableAssociation(this, 'SubnetRouteTableAssociation1', {
      subnetId: dbSubnet2.ref,
      routeTableId: routeTable.ref,
    });

    const auroraCluster = new rds.CfnDBCluster(this, 'AuroraCluster', {
      databaseName: 'dms_sample',
      backupRetentionPeriod: 7,
      dbSubnetGroupName: auroraDbSubnetGroup.ref,
      engine: 'aurora-postgresql',
      snapshotIdentifier: props.snapshotIdentifier!,
      vpcSecurityGroupIds: [
        auroraSecurityGroup.ref,
      ],
      storageEncrypted: true,
    });
    auroraCluster.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.RETAIN;

    const dmsReplicationInstance = new dms.CfnReplicationInstance(this, 'DMSReplicationInstance', {
      availabilityZone: dbSubnet1.attrAvailabilityZone,
      publiclyAccessible: false,
      replicationInstanceClass: 'dms.t3.medium',
      replicationInstanceIdentifier: 'aurora-s3-repinstance-sampledb',
      replicationSubnetGroupIdentifier: dmsReplicationSubnetGroup.ref,
      vpcSecurityGroupIds: [
        dmsSecurityGroup.ref,
      ],
    });
    dmsReplicationInstance.addDependency(dmsReplicationSubnetGroup);
    dmsReplicationInstance.addDependency(dmsSecurityGroup);

    const auroraDb = new rds.CfnDBInstance(this, 'AuroraDB', {
      dbClusterIdentifier: auroraCluster.ref,
      dbInstanceClass: 'db.t3.medium',
      dbInstanceIdentifier: 'dms-sample',
      dbSubnetGroupName: auroraDbSubnetGroup.ref,
      engine: 'aurora-postgresql',
      multiAz: false,
      publiclyAccessible: false,
      tags: [
        {
          key: 'Application',
          value: this.stackId,
        },
      ],
    });
    auroraDb.cfnOptions.metadata = {
      guard: {
        SuppressedRules: [
          'DB_INSTANCE_BACKUP_ENABLED',
          'RDS_SNAPSHOT_ENCRYPTED',
          'RDS_STORAGE_ENCRYPTED',
        ],
      },
    };
    auroraDb.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.RETAIN;
    auroraDb.addDependency(auroraCluster);

    const s3TargetEndpoint = new dms.CfnEndpoint(this, 'S3TargetEndpoint', {
      endpointType: 'target',
      engineName: 'S3',
      extraConnectionAttributes: 'addColumnName=true',
      s3Settings: {
        bucketName: s3Bucket.ref,
        serviceAccessRoleArn: s3TargetDmsRole.attrArn,
      },
    });
    s3TargetEndpoint.addDependency(dmsReplicationInstance);
    s3TargetEndpoint.addDependency(s3Bucket);
    s3TargetEndpoint.addDependency(s3TargetDmsRole);

    const auroraSourceEndpoint = new dms.CfnEndpoint(this, 'AuroraSourceEndpoint', {
      endpointType: 'source',
      engineName: 'AURORA',
      password: '{{resolve:secretsmanager:aurora-source-enpoint-password:SecretString:password}}',
      port: 3306,
      serverName: auroraCluster.attrEndpointAddress,
      username: 'admin',
    });
    auroraSourceEndpoint.addDependency(dmsReplicationInstance);
    auroraSourceEndpoint.addDependency(auroraCluster);
    auroraSourceEndpoint.addDependency(auroraDb);

    const dmsReplicationTask = new dms.CfnReplicationTask(this, 'DMSReplicationTask', {
      migrationType: 'full-load-and-cdc',
      replicationInstanceArn: dmsReplicationInstance.ref,
      replicationTaskSettings: '{ \"Logging\" : { \"EnableLogging\" : true, \"LogComponents\": [ { \"Id\" : \"SOURCE_UNLOAD\", \"Severity\" : \"LOGGER_SEVERITY_DEFAULT\" }, { \"Id\" : \"SOURCE_CAPTURE\", \"Severity\" : \"LOGGER_SEVERITY_DEFAULT\" }, { \"Id\" : \"TARGET_LOAD\", \"Severity\" : \"LOGGER_SEVERITY_DEFAULT\" }, { \"Id\" : \"TARGET_APPLY\", \"Severity\" : \"LOGGER_SEVERITY_DEFAULT\" } ] } }',
      sourceEndpointArn: auroraSourceEndpoint.ref,
      tableMappings: '{ \"rules\": [ { \"rule-type\" : \"selection\", \"rule-id\" : \"1\", \"rule-name\" : \"1\", \"object-locator\" : { \"schema-name\" : \"dms_sample\", \"table-name\" : \"%\" }, \"rule-action\" : \"include\" } ] }',
      targetEndpointArn: s3TargetEndpoint.ref,
    });
    dmsReplicationTask.addDependency(auroraSourceEndpoint);
    dmsReplicationTask.addDependency(s3TargetEndpoint);
    dmsReplicationTask.addDependency(dmsReplicationInstance);

    // Outputs
    this.stackName = this.stackName;
    new cdk.CfnOutput(this, 'CfnOutputStackName', {
      key: 'StackName',
      value: this.stackName!.toString(),
    });
    this.regionName = this.region;
    new cdk.CfnOutput(this, 'CfnOutputRegionName', {
      key: 'RegionName',
      value: this.regionName!.toString(),
    });
    this.s3BucketName = s3Bucket.ref;
    new cdk.CfnOutput(this, 'CfnOutputS3BucketName', {
      key: 'S3BucketName',
      value: this.s3BucketName!.toString(),
    });
    this.auroraEndpoint = auroraCluster.attrEndpointAddress;
    new cdk.CfnOutput(this, 'CfnOutputAuroraEndpoint', {
      key: 'AuroraEndpoint',
      value: this.auroraEndpoint!.toString(),
    });
  }
}
