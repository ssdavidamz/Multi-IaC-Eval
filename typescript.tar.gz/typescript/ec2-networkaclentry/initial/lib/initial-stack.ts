import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

export interface InitialStackProps extends cdk.StackProps {
}

/**
 * This stack automates the creation of an EC2 Newtork Acl and
 * its entries

 */
export class InitialStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: InitialStackProps = {}) {
    super(scope, id, props);

    // Conditions
    const isUsEast1 = this.region === 'us-east-1';

    // Resources
    const dhcpOptions = new ec2.CfnDHCPOptions(this, 'DhcpOptions', {
      domainName: isUsEast1 ? 'ec2.internal' : `${this.region}.compute.internal`,
      domainNameServers: [
        'AmazonProvidedDNS',
      ],
      netbiosNodeType: 2,
    });

    const vpc = new ec2.CfnVPC(this, 'Vpc', {
      cidrBlock: '10.0.0.0/24',
    });

    const networkAcl = new ec2.CfnNetworkAcl(this, 'NetworkAcl', {
      vpcId: vpc.ref,
    });

    const subnet1 = new ec2.CfnSubnet(this, 'Subnet1', {
      availabilityZone: cdk.Fn.select(0, cdk.Fn.getAzs('us-east-1')),
      cidrBlock: cdk.Fn.select(0, cdk.Fn.cidr(vpc.attrCidrBlock, 2, String(6))),
      mapPublicIpOnLaunch: false,
      vpcId: vpc.ref,
    });

    const vpcDhcpOptions = new ec2.CfnVPCDHCPOptionsAssociation(this, 'VpcDhcpOptions', {
      dhcpOptionsId: dhcpOptions.attrDhcpOptionsId,
      vpcId: vpc.ref,
    });

    const inboundHttpsRule = new ec2.CfnNetworkAclEntry(this, 'InboundHTTPSRule', {
      networkAclId: networkAcl.ref,
      ruleNumber: 100,
      protocol: 6,
      ruleAction: 'allow',
      cidrBlock: vpc.attrCidrBlock,
      portRange: {
        from: 443,
        to: 443,
      },
    });

    const inboundSshRule = new ec2.CfnNetworkAclEntry(this, 'InboundSSHRule', {
      networkAclId: networkAcl.ref,
      ruleNumber: 101,
      protocol: 6,
      ruleAction: 'allow',
      cidrBlock: vpc.attrCidrBlock,
      portRange: {
        from: 22,
        to: 22,
      },
    });

    const outboundRule = new ec2.CfnNetworkAclEntry(this, 'OutboundRule', {
      networkAclId: networkAcl.ref,
      ruleNumber: 100,
      protocol: -1,
      egress: true,
      ruleAction: 'allow',
      cidrBlock: '0.0.0.0/0',
    });

    const subnet1NetworkAcl = new ec2.CfnSubnetNetworkAclAssociation(this, 'Subnet1NetworkAcl', {
      subnetId: subnet1.attrSubnetId,
      networkAclId: networkAcl.attrId,
    });
  }
}
