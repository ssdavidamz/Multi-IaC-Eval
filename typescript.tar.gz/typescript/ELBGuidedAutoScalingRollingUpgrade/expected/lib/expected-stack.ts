import * as cdk from 'aws-cdk-lib';
import * as autoscaling from 'aws-cdk-lib/aws-autoscaling';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as elasticloadbalancing from 'aws-cdk-lib/aws-elasticloadbalancing';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as rds from 'aws-cdk-lib/aws-rds';

export interface ExpectedStackProps extends cdk.StackProps {
  /**
   * WebServer EC2 instance type
   * @default 't2.small'
   */
  readonly instanceType?: string;
  /**
   * Name of an existing EC2 KeyPair to enable SSH access to the instances
   */
  readonly keyName: string;
  /**
   * The IP address range that can be used to SSH to the EC2 instances
   * @default '192.168.1.0/0'
   */
  readonly sshLocation?: string;
  /**
   * @default '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2'
   */
  readonly latestAmiId?: string;
}

/**
 * AWS CloudFormation Sample Template ELBGuidedAutoScalingRollingUpdates: This example creates an auto scaling group behind a load balancer with a simple health check. The Auto Scaling launch configuration includes an update policy that will keep 2 instances running while doing an autoscaling rolling update. The update will roll forward only when the ELB health check detects an updated instance in-service. **WARNING** This template creates one or more Amazon EC2  instances and an Elastic Load Balancer. You will be billed for the AWS resources used if you create a stack from this template.
 */
export class ExpectedStack extends cdk.Stack {
  /**
   * URL of the website
   */
  public readonly url;
  /**
   * Endpoint of the RDS database instance
   */
  public readonly dbEndpoint;

  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      instanceType: props.instanceType ?? 't2.small',
      keyName: new cdk.CfnParameter(this, 'KeyName', {
        type: 'AWS::EC2::KeyPair::KeyName',
        default: props.keyName.toString(),
        description: 'Name of an existing EC2 KeyPair to enable SSH access to the instances',
      }).valueAsString,
      sshLocation: props.sshLocation ?? '192.168.1.0/0',
      latestAmiId: new cdk.CfnParameter(this, 'LatestAmiId', {
        type: 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default: props.latestAmiId?.toString() ?? '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2',
      }).valueAsString,
    };

    // Mappings
    const region2Examples: Record<string, Record<string, string>> = {
      'us-east-1': {
        'Examples': 'https://s3.amazonaws.com/cloudformation-examples-us-east-1',
      },
      'us-west-2': {
        'Examples': 'https://s3-us-west-2.amazonaws.com/cloudformation-examples-us-west-2',
      },
      'us-west-1': {
        'Examples': 'https://s3-us-west-1.amazonaws.com/cloudformation-examples-us-west-1',
      },
      'eu-west-1': {
        'Examples': 'https://s3-eu-west-1.amazonaws.com/cloudformation-examples-eu-west-1',
      },
      'eu-central-1': {
        'Examples': 'https://s3-eu-central-1.amazonaws.com/cloudformation-examples-eu-central-1',
      },
      'ap-southeast-1': {
        'Examples': 'https://s3-ap-southeast-1.amazonaws.com/cloudformation-examples-ap-southeast-1',
      },
      'ap-northeast-1': {
        'Examples': 'https://s3-ap-northeast-1.amazonaws.com/cloudformation-examples-ap-northeast-1',
      },
      'ap-northeast-2': {
        'Examples': 'https://s3-ap-northeast-2.amazonaws.com/cloudformation-examples-ap-northeast-2',
      },
      'ap-southeast-2': {
        'Examples': 'https://s3-ap-southeast-2.amazonaws.com/cloudformation-examples-ap-southeast-2',
      },
      'ap-south-1': {
        'Examples': 'https://s3-ap-south-1.amazonaws.com/cloudformation-examples-ap-south-1',
      },
      'us-east-2': {
        'Examples': 'https://s3-us-east-2.amazonaws.com/cloudformation-examples-us-east-2',
      },
      'sa-east-1': {
        'Examples': 'https://s3-sa-east-1.amazonaws.com/cloudformation-examples-sa-east-1',
      },
      'cn-north-1': {
        'Examples': 'https://s3.cn-north-1.amazonaws.com.cn/cloudformation-examples-cn-north-1',
      },
    };

    // Resources
    const describeHealthRole = new iam.CfnRole(this, 'DescribeHealthRole', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'ec2.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
      policies: [
        {
          policyName: 'describe-instance-health-policy',
          policyDocument: {
            Statement: [
              {
                Effect: 'Allow',
                Action: [
                  'elasticloadbalancing:DescribeInstanceHealth',
                ],
                Resource: '*',
              },
            ],
          },
        },
      ],
    });

    const elasticLoadBalancer = new elasticloadbalancing.CfnLoadBalancer(this, 'ElasticLoadBalancer', {
      availabilityZones: cdk.Fn.getAzs(undefined),
      crossZone: true,
      listeners: [
        {
          loadBalancerPort: '80',
          instancePort: '80',
          protocol: 'HTTP',
        },
      ],
      healthCheck: {
        target: 'HTTP:80/',
        healthyThreshold: '3',
        unhealthyThreshold: '5',
        interval: '30',
        timeout: '5',
      },
    });

    const instanceSecurityGroup = new ec2.CfnSecurityGroup(this, 'InstanceSecurityGroup', {
      groupDescription: 'Enable SSH access and HTTP access on the configured port',
      securityGroupIngress: [
        {
          ipProtocol: 'tcp',
          fromPort: 22,
          toPort: 22,
          cidrIp: props.sshLocation!,
        },
        {
          ipProtocol: 'tcp',
          fromPort: 80,
          toPort: 80,
          cidrIp: '0.0.0.0/0',
        },
      ],
    });

    const webServerDb = new rds.CfnDBInstance(this, 'WebServerDB', {
      dbInstanceIdentifier: 'web-server-db',
      allocatedStorage: '20',
      dbInstanceClass: 'db.t2.micro',
      engine: 'MySQL',
      masterUsername: 'admin',
      masterUserPassword: 'MyPassword123',
      vpcSecurityGroups: [
        instanceSecurityGroup.ref,
      ],
    });

    const webServerInstanceProfile = new iam.CfnInstanceProfile(this, 'WebServerInstanceProfile', {
      path: '/',
      roles: [
        describeHealthRole.ref,
      ],
    });

    const launchConfig = new autoscaling.CfnLaunchConfiguration(this, 'LaunchConfig', {
      keyName: props.keyName!,
      imageId: props.latestAmiId!,
      instanceType: props.instanceType!,
      securityGroups: [
        instanceSecurityGroup.ref,
      ],
      iamInstanceProfile: webServerInstanceProfile.ref,
      userData: cdk.Fn.base64(`#!/bin/bash -xe          
      yum update -y aws-cfn-bootstrap 
      /opt/aws/bin/cfn-init -v --stack ${this.stackName} \
               --resource LaunchConfig \
               --configsets full_install \
               --region ${this.region}

      /opt/aws/bin/cfn-signal -e $? --stack ${this.stackName} \
               --resource WebServerGroup \
               --region ${this.region} 
      `),
    });
    launchConfig.cfnOptions.metadata = {
      AWS::CloudFormation::Init: {
        configSets: {
          'full_install': [
            'install_cfn',
            'install_app',
            'verify_instance_health',
          ],
        },
        'install_cfn': {
          files: {
            '/etc/cfn/cfn-hup.conf': {
              content: [
                '[main] ',
                'stack=',
                this.stackId,
                ' ',
                'region=',
                this.region,
                ' ',
              ].join(''),
              mode: '000400',
              owner: 'root',
              group: 'root',
            },
            '/etc/cfn/hooks.d/cfn-auto-reloader.conf': {
              content: [
                '[cfn-auto-reloader-hook] ',
                'triggers=post.update ',
                'path=Resources.WebServerInstance.Metadata.AWS::CloudFormation::Init ',
                'action=/opt/aws/bin/cfn-init -v ',
                '         --stack ',
                this.stackName,
                '         --resource WebServerInstance ',
                '         --configsets full_install ',
                '         --region ',
                this.region,
                ' ',
                'runas=root ',
              ].join(''),
            },
          },
          services: {
            sysvinit: {
              'cfn-hup': {
                enabled: 'true',
                ensureRunning: 'true',
                files: [
                  '/etc/cfn/cfn-hup.conf',
                  '/etc/cfn/hooks.d/cfn-auto-reloader.conf',
                ],
              },
            },
          },
        },
        'install_app': {
          packages: {
            yum: {
              httpd: [
              ],
            },
          },
          files: {
            '/var/www/html/index.html': {
              content: [
                '<img src=\"',
                region2Examples[this.region]['Examples'],
                '/cloudformation_graphic.png\" alt=\"AWS CloudFormation Logo\"/>',
                '<h1>Congratulations, you have successfully launched the AWS CloudFormation sample.</h1>',
              ].join(''),
              mode: '000644',
              owner: 'root',
              group: 'root',
            },
          },
          services: {
            sysvinit: {
              httpd: {
                enabled: 'true',
                ensureRunning: 'true',
              },
            },
          },
        },
        'verify_instance_health': {
          commands: {
            ELBHealthCheck: {
              command: [
                'until [ \"$state\" == \"\\\"InService\\\"\" ]; do ',
                '  state=$(aws --region ',
                this.region,
                ' elb describe-instance-health ',
                '              --load-balancer-name ',
                elasticLoadBalancer.ref,
                '              --instances $(curl -s http://169.254.169.254/latest/meta-data/instance-id) ',
                '              --query InstanceStates[0].State); ',
                '  sleep 10; ',
                'done',
              ].join(''),
            },
          },
        },
      },
    };

    const webServerGroup = new autoscaling.CfnAutoScalingGroup(this, 'WebServerGroup', {
      availabilityZones: cdk.Fn.getAzs(undefined),
      launchConfigurationName: launchConfig.ref,
      minSize: '2',
      maxSize: '4',
      loadBalancerNames: [
        elasticLoadBalancer.ref,
      ],
    });
    webServerGroup.cfnOptions.updatePolicy = {
      AutoScalingRollingUpdate: {
        MaxBatchSize: 1,
        MinInstancesInService: 1,
        PauseTime: 'PT15M',
        WaitOnResourceSignals: true,
      },
    };
    // Outputs
    this.url = [
      'http://',
      elasticLoadBalancer.attrDnsName,
    ].join('');
    new cdk.CfnOutput(this, 'CfnOutputURL', {
      key: 'URL',
      description: 'URL of the website',
      value: this.url!.toString(),
    });
    this.dbEndpoint = webServerDb.attrEndpointAddress;
    new cdk.CfnOutput(this, 'CfnOutputDBEndpoint', {
      key: 'DBEndpoint',
      description: 'Endpoint of the RDS database instance',
      value: this.dbEndpoint!.toString(),
    });
  }
}
