import * as cdk from 'aws-cdk-lib';
import * as autoscaling from 'aws-cdk-lib/aws-autoscaling';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as elasticloadbalancingv2 from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as sns from 'aws-cdk-lib/aws-sns';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * WebServer EC2 instance type
   * @default 't4g.micro'
   */
  readonly instanceType?: string;
  /**
   * Email address to notify if there are any scaling operations
   */
  readonly operatorEMail: string;
  /**
   * The EC2 Key Pair to allow SSH access to the instances
   */
  readonly keyName: string;
  /**
   * The IP address range that can be used to SSH to the EC2 instances
   * @default '192.168.1.0/24'
   */
  readonly sshLocation?: string;
  /**
   * @default '/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-6.1-arm64'
   */
  readonly latestAmiId?: string;
  /**
   * KMS Key ARN to encrypt data
   */
  readonly kmsKeyArn: string;
  /**
   * Certificate ARN for HTTPS
   */
  readonly certificateArn: string;
  /**
   * Security Groups to be used
   */
  readonly securityGroups: string[];
  /**
   * Subnets to be used
   */
  readonly subnets: string[];
  /**
   * Availability Zones to be used
   */
  readonly aZs: string[];
  /**
   * VPC to be used
   */
  readonly vpc: string;
}

/**
 * Create a multi-az, load balanced and Auto Scaled sample web site running on
 * an Apache Web Server. The application is configured to span all
 * Availability Zones in the region and is Auto-Scaled based on the CPU
 * utilization of the web servers. Notifications will be sent to the operator
 * email address on scaling events. The instances are load balanced with a
 * simple health check against the default web page. **WARNING** This template
 * creates one or more Amazon EC2 instances and an Elastic Load Balancer. You
 * will be billed for the AWS resources used if you create a stack from this
 * template.

 */
export class InitialStack extends cdk.Stack {
  /**
   * The URL of the website
   */
  public readonly url;

  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      instanceType: props.instanceType ?? 't4g.micro',
      keyName: new cdk.CfnParameter(this, 'KeyName', {
        type: 'AWS::EC2::KeyPair::KeyName',
        default: props.keyName.toString(),
        description: 'The EC2 Key Pair to allow SSH access to the instances',
      }).valueAsString,
      sshLocation: props.sshLocation ?? '192.168.1.0/24',
      latestAmiId: new cdk.CfnParameter(this, 'LatestAmiId', {
        type: 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default: props.latestAmiId?.toString() ?? '/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-6.1-arm64',
      }).valueAsString,
      securityGroups: new cdk.CfnParameter(this, 'SecurityGroups', {
        type: 'List<AWS::EC2::SecurityGroup::Id>',
        default: props.securityGroups.join(','),
        description: 'Security Groups to be used',
      }).valueAsList,
      subnets: new cdk.CfnParameter(this, 'Subnets', {
        type: 'List<AWS::EC2::Subnet::Id>',
        default: props.subnets.join(','),
        description: 'Subnets to be used',
      }).valueAsList,
      aZs: new cdk.CfnParameter(this, 'AZs', {
        type: 'List<AWS::EC2::AvailabilityZone::Name>',
        default: props.aZs.join(','),
        description: 'Availability Zones to be used',
      }).valueAsList,
      vpc: new cdk.CfnParameter(this, 'Vpc', {
        type: 'AWS::EC2::VPC::Id',
        default: props.vpc.toString(),
        description: 'VPC to be used',
      }).valueAsString,
    };

    // Mappings
    const region2Examples: Record<string, Record<string, string>> = {
      'us-east-1': {
        'Examples': 'https://s3.amazonaws.com/cloudformation-examples-us-east-1',
      },
      'us-west-2': {
        'Examples': 'https://s3-us-west-2.amazonaws.com/cloudformation-examples-us-west-2',
      },
      'us-west-1': {
        'Examples': 'https://s3-us-west-1.amazonaws.com/cloudformation-examples-us-west-1',
      },
      'eu-west-1': {
        'Examples': 'https://s3-eu-west-1.amazonaws.com/cloudformation-examples-eu-west-1',
      },
      'eu-central-1': {
        'Examples': 'https://s3-eu-central-1.amazonaws.com/cloudformation-examples-eu-central-1',
      },
      'ap-southeast-1': {
        'Examples': 'https://s3-ap-southeast-1.amazonaws.com/cloudformation-examples-ap-southeast-1',
      },
      'ap-northeast-1': {
        'Examples': 'https://s3-ap-northeast-1.amazonaws.com/cloudformation-examples-ap-northeast-1',
      },
      'ap-northeast-2': {
        'Examples': 'https://s3-ap-northeast-2.amazonaws.com/cloudformation-examples-ap-northeast-2',
      },
      'ap-southeast-2': {
        'Examples': 'https://s3-ap-southeast-2.amazonaws.com/cloudformation-examples-ap-southeast-2',
      },
      'ap-south-1': {
        'Examples': 'https://s3-ap-south-1.amazonaws.com/cloudformation-examples-ap-south-1',
      },
      'us-east-2': {
        'Examples': 'https://s3-us-east-2.amazonaws.com/cloudformation-examples-us-east-2',
      },
      'sa-east-1': {
        'Examples': 'https://s3-sa-east-1.amazonaws.com/cloudformation-examples-sa-east-1',
      },
      'cn-north-1': {
        'Examples': 'https://s3.cn-north-1.amazonaws.com.cn/cloudformation-examples-cn-north-1',
      },
    };

    // Resources
    const launchTemplate = new ec2.CfnLaunchTemplate(this, 'LaunchTemplate', {
      launchTemplateName: `${this.stackName}-LaunchTemplate`,
      launchTemplateData: {
        imageId: props.latestAmiId!,
        instanceType: props.instanceType!,
        securityGroupIds: props.securityGroups!,
        keyName: props.keyName!,
        blockDeviceMappings: [
          {
            deviceName: '/dev/sda1',
            ebs: {
              volumeSize: 32,
            },
          },
        ],
        userData: cdk.Fn.base64(`#!/bin/bash
        /opt/aws/bin/cfn-init -v --stack ${this.stackName} --resource LaunchTemplate --region ${this.region}
        /opt/aws/bin/cfn-signal -e $? --stack ${this.stackName} --resource WebServerGroup --region ${this.region}
        `),
        tagSpecifications: [
          {
            resourceType: 'instance',
            tags: [
              {
                key: 'Name',
                value: `${this.stackName}-Instance`,
              },
            ],
          },
        ],
      },
    });
    launchTemplate.cfnOptions.metadata = {
      AWS::CloudFormation::Init: {
        config: {
          packages: {
            yum: {
              httpd: [
              ],
            },
          },
          files: {
            '/var/www/html/index.html': {
              content: [
                '<img src=\"',
                region2Examples[this.region]['Examples'],
                '/cloudformation_graphic.png\" alt=\"AWS CloudFormation Logo\"/>',
                '<h1>Congratulations, you have successfully launched the AWS CloudFormation sample.</h1>',
              ].join(''),
              mode: '000644',
              owner: 'root',
              group: 'root',
            },
            '/etc/cfn/cfn-hup.conf': {
              content: `[main]
              stack=${this.stackId}
              region=${this.region}
              `,
              mode: '000400',
              owner: 'root',
              group: 'root',
            },
            '/etc/cfn/hooks.d/cfn-auto-reloader.conf': {
              content: `[cfn-auto-reloader-hook]
              triggers=post.update
              path=Resources.LaunchTemplate.Metadata.AWS::CloudFormation::Init
              action=/opt/aws/bin/cfn-init -v --stack ${this.stackName} --resource LaunchTemplate --region ${this.region}
              runas=root
              `,
            },
          },
          services: {
            sysvinit: {
              httpd: {
                enabled: true,
                ensureRunning: true,
              },
              'cfn-hup': {
                enabled: true,
                ensureRunning: true,
                files: [
                  '/etc/cfn/cfn-hup.conf',
                  '/etc/cfn/hooks.d/cfn-auto-reloader.conf',
                ],
              },
            },
          },
        },
      },
    };

    const loadBalancerSecurityGroup = new ec2.CfnSecurityGroup(this, 'LoadBalancerSecurityGroup', {
      groupDescription: 'Allows inbound traffic on port 443',
      securityGroupIngress: [
        {
          ipProtocol: 'tcp',
          fromPort: 443,
          toPort: 443,
          cidrIp: '0.0.0.0/0',
        },
      ],
      vpcId: props.vpc!,
    });

    const notificationTopic = new sns.CfnTopic(this, 'NotificationTopic', {
      displayName: `${this.stackName}-NotificationTopic`,
      subscription: [
        {
          endpoint: props.operatorEMail!,
          protocol: 'email',
        },
      ],
      kmsMasterKeyId: props.kmsKeyArn!,
    });

    const targetGroup = new elasticloadbalancingv2.CfnTargetGroup(this, 'TargetGroup', {
      healthCheckPath: '/',
      name: 'MyTargetGroup',
      port: 80,
      protocol: 'HTTP',
      targetType: 'instance',
      vpcId: props.vpc!,
    });

    const elasticLoadBalancer = new elasticloadbalancingv2.CfnLoadBalancer(this, 'ElasticLoadBalancer', {
      scheme: 'internet-facing',
      securityGroups: [
        loadBalancerSecurityGroup.ref,
      ],
      subnets: props.subnets!,
      type: 'application',
    });

    const instanceSecurityGroup = new ec2.CfnSecurityGroup(this, 'InstanceSecurityGroup', {
      groupDescription: 'Enable SSH access and HTTP from the load balancer only',
      securityGroupIngress: [
        {
          ipProtocol: 'tcp',
          fromPort: 22,
          toPort: 22,
          cidrIp: props.sshLocation!,
        },
        {
          ipProtocol: 'tcp',
          fromPort: 80,
          toPort: 80,
          sourceSecurityGroupId: loadBalancerSecurityGroup.ref,
        },
      ],
    });
    instanceSecurityGroup.cfnOptions.metadata = {
      guard: {
        SuppressedRules: [
          'INCOMING_SSH_DISABLED',
        ],
      },
    };

    const webServerGroup = new autoscaling.CfnAutoScalingGroup(this, 'WebServerGroup', {
      availabilityZones: props.aZs!,
      launchTemplate: {
        launchTemplateId: launchTemplate.ref,
        version: launchTemplate.attrLatestVersionNumber,
      },
      minSize: '1',
      maxSize: '3',
      targetGroupArns: [
        targetGroup.ref,
      ],
      notificationConfigurations: [
        {
          topicArn: notificationTopic.ref,
          notificationTypes: [
            'autoscaling:EC2_INSTANCE_LAUNCH',
            'autoscaling:EC2_INSTANCE_LAUNCH_ERROR',
            'autoscaling:EC2_INSTANCE_TERMINATE',
            'autoscaling:EC2_INSTANCE_TERMINATE_ERROR',
          ],
        },
      ],
      healthCheckType: 'ELB',
      vpcZoneIdentifier: props.subnets!,
    });
    webServerGroup.cfnOptions.metadata = {
      cfn-lint: {
        config: {
          'ignore_checks': [
            'E3014',
          ],
        },
      },
    };
    webServerGroup.cfnOptions.updatePolicy = {
      AutoScalingRollingUpdate: {
        MinInstancesInService: 1,
        MaxBatchSize: 1,
        PauseTime: 'PT5M',
        WaitOnResourceSignals: true,
      },
    };
    const loadBalancerListener = new elasticloadbalancingv2.CfnListener(this, 'LoadBalancerListener', {
      defaultActions: [
        {
          type: 'forward',
          targetGroupArn: targetGroup.ref,
        },
      ],
      loadBalancerArn: elasticLoadBalancer.ref,
      port: 443,
      protocol: 'HTTPS',
      sslPolicy: 'ELBSecurityPolicy-2016-08',
      certificates: [
        {
          certificateArn: props.certificateArn!,
        },
      ],
    });

    const webServerScaleDownPolicy = new autoscaling.CfnScalingPolicy(this, 'WebServerScaleDownPolicy', {
      adjustmentType: 'ChangeInCapacity',
      autoScalingGroupName: webServerGroup.ref,
      cooldown: '60',
      scalingAdjustment: -1,
    });

    const webServerScaleUpPolicy = new autoscaling.CfnScalingPolicy(this, 'WebServerScaleUpPolicy', {
      adjustmentType: 'ChangeInCapacity',
      autoScalingGroupName: webServerGroup.ref,
      cooldown: '60',
      scalingAdjustment: 1,
    });

    const cpuAlarmHigh = new cloudwatch.CfnAlarm(this, 'CPUAlarmHigh', {
      alarmDescription: 'Scale-up if CPU > 90% for 10 minutes',
      metricName: 'CPUUtilization',
      namespace: 'AWS/EC2',
      statistic: 'Average',
      period: 300,
      evaluationPeriods: 2,
      threshold: 90,
      alarmActions: [
        webServerScaleUpPolicy.ref,
      ],
      dimensions: [
        {
          name: 'AutoScalingGroupName',
          value: webServerGroup.ref,
        },
      ],
      comparisonOperator: 'GreaterThanThreshold',
    });

    const cpuAlarmLow = new cloudwatch.CfnAlarm(this, 'CPUAlarmLow', {
      alarmDescription: 'Scale-down if CPU < 70% for 10 minutes',
      metricName: 'CPUUtilization',
      namespace: 'AWS/EC2',
      statistic: 'Average',
      period: 300,
      evaluationPeriods: 2,
      threshold: 70,
      alarmActions: [
        webServerScaleDownPolicy.ref,
      ],
      dimensions: [
        {
          name: 'AutoScalingGroupName',
          value: webServerGroup.ref,
        },
      ],
      comparisonOperator: 'LessThanThreshold',
    });

    // Outputs
    this.url = [
      'https://',
      elasticLoadBalancer.attrDnsName,
    ].join('');
    new cdk.CfnOutput(this, 'CfnOutputURL', {
      key: 'URL',
      description: 'The URL of the website',
      value: this.url!.toString(),
    });
  }
}
