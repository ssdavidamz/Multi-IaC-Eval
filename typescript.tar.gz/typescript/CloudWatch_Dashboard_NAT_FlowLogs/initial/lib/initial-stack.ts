import * as cdk from 'aws-cdk-lib';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * The private IP address of the NAT Gateway
   */
  readonly natGatewayPrivateIp: string;
  /**
   * The ID of the NAT Gateway
   */
  readonly natGatewayId: string;
  /**
   * The CIDR block of the VPC
   */
  readonly vpcCidr: string;
  /**
   * The ARN of the log group to query
   */
  readonly logGroupName: string;
}

/**
 * Creates a CloudWatch Dashboard with four CloudWatch Logs Insights log widgets that query VPC flow logs for NAT Gateway, related to https://repost.aws/knowledge-center/vpc-find-traffic-sources-nat-gateway
 */
export class InitialStack extends cdk.Stack {
  /**
   * ARN of the created CloudWatch Dashboard
   */
  public readonly dashboardArn;

  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Resources
    const cloudWatchDashboard = new cloudwatch.CfnDashboard(this, 'CloudWatchDashboard', {
      dashboardName: `${props.natGatewayId!}-Traffic-Dashboard`,
      dashboardBody: `{
        "widgets": [
          {
            "type": "log",
            "x": 0,
            "y": 0,
            "width": 12,
            "height": 9,
            "properties": {
              "query": "SOURCE '${props.logGroupName!}' | fields @timestamp, @message | filter (dstAddr like '${props.natGatewayPrivateIp!}' and isIpv4InSubnet(srcAddr, '${props.vpcCidr!}')) | stats sum(bytes) as bytesTransferred by srcAddr, dstAddr | sort bytesTransferred desc | limit 10",
              "region": "${this.region}",
              "stacked": false,
              "title": "Top 10 - Instances sending most traffic through NAT gateway ${props.natGatewayId!}", 
              "view": "table"
            }
          },
          {
            "type": "log",
            "x": 12,
            "y": 0,
            "width": 12,
            "height": 9,
            "properties": {
              "query": "SOURCE '${props.logGroupName!}' | fields @timestamp, @message | filter (dstAddr like '${props.natGatewayPrivateIp!}' and isIpv4InSubnet(srcAddr, '${props.vpcCidr!}')) or (srcAddr like '${props.natGatewayPrivateIp!}' and isIpv4InSubnet(dstAddr, '${props.vpcCidr!}'))| stats sum(bytes) as bytesTransferred by srcAddr, dstAddr | sort bytesTransferred desc | limit 10",
              "region": "${this.region}",
              "stacked": false,
              "title": "Top 10 - Traffic To and from NAT gateway ${props.natGatewayId!}",
              "view": "table"
            }
          },
          {
            "type": "log",
            "x": 0,
            "y": 9,
            "width": 12,
            "height": 9,
            "properties": {
              "query": "SOURCE '${props.logGroupName!}' | fields @timestamp, @message | filter (srcAddr like '${props.natGatewayPrivateIp!}' and not isIpv4InSubnet(dstAddr, '${props.vpcCidr!}')) | stats sum(bytes) as bytesTransferred by srcAddr, dstAddr | sort bytesTransferred desc | limit 10",
              "region": "${this.region}",
              "stacked": false,
              "title": "Top 10 - Most often upload communication destinations through NAT Gateway ${props.natGatewayId!}",
              "view": "table"
            }
          },
          {
            "type": "log",
            "x": 12,
            "y": 9,
            "width": 12,
            "height": 9,
            "properties": {
              "query": "SOURCE '${props.logGroupName!}' | fields @timestamp, @message | filter (dstAddr like '${props.natGatewayPrivateIp!}' and not isIpv4InSubnet(srcAddr, '${props.vpcCidr!}')) | stats sum(bytes) as bytesTransferred by srcAddr, dstAddr | sort bytesTransferred desc | limit 10",
              "region": "${this.region}",
              "stacked": false,
              "title": "Top 10 - Most often download communication destinations through NAT Gateway ${props.natGatewayId!}",
              "view": "table"
            }
          }
        ]
      }
      `,
    });

    // Outputs
    this.dashboardArn = cloudWatchDashboard.ref;
    new cdk.CfnOutput(this, 'CfnOutputDashboardArn', {
      key: 'DashboardArn',
      description: 'ARN of the created CloudWatch Dashboard',
      value: this.dashboardArn!.toString(),
    });
  }
}
