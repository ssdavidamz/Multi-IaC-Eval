import * as cdk from 'aws-cdk-lib';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * HashType PrimaryKey Name
   */
  readonly hashKeyElementName: string;
  /**
   * HashType PrimaryKey Type
   * @default 'S'
   */
  readonly hashKeyElementType?: string;
  /**
   * Provisioned read throughput
   * @default 5
   */
  readonly readCapacityUnits?: string;
  /**
   * Provisioned write throughput
   * @default 10
   */
  readonly writeCapacityUnits?: string;
}

/**
 * AWS CloudFormation Sample Template DynamoDB_Table: This template demonstrates the creation of a DynamoDB table.  **WARNING** This template creates an Amazon DynamoDB table. You will be billed for the AWS resources used if you create a stack from this template.
 */
export class InitialStack extends cdk.Stack {
  /**
   * Table name of the newly created DynamoDB table
   */
  public readonly tableName;

  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      hashKeyElementType: props.hashKeyElementType ?? 'S',
      readCapacityUnits: props.readCapacityUnits ?? 5,
      writeCapacityUnits: props.writeCapacityUnits ?? 10,
    };

    // Resources
    const myDynamoDbTable = new dynamodb.CfnTable(this, 'myDynamoDBTable', {
      attributeDefinitions: [
        {
          attributeName: props.hashKeyElementName!,
          attributeType: props.hashKeyElementType!,
        },
      ],
      keySchema: [
        {
          attributeName: props.hashKeyElementName!,
          keyType: 'HASH',
        },
      ],
      provisionedThroughput: {
        readCapacityUnits: props.readCapacityUnits!,
        writeCapacityUnits: props.writeCapacityUnits!,
      },
      pointInTimeRecoverySpecification: {
        pointInTimeRecoveryEnabled: true,
      },
    });

    // Outputs
    this.tableName = myDynamoDbTable.ref;
    new cdk.CfnOutput(this, 'CfnOutputTableName', {
      key: 'TableName',
      description: 'Table name of the newly created DynamoDB table',
      value: this.tableName!.toString(),
    });
  }
}
