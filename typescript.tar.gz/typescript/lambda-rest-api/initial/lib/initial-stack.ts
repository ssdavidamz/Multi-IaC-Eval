import * as cdk from 'aws-cdk-lib';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as logs from 'aws-cdk-lib/aws-logs';

export interface InitialStackProps extends cdk.StackProps {
  /**
   */
  readonly resourceNamePrefix: string;
}

/**
 * This template deploys a Lambda function and an API Gateway to implement 
 * a basic REST API.

 */
export class InitialStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Resources
    const restApi = new apigateway.CfnRestApi(this, 'RestApi', {
      name: `${props.resourceNamePrefix!}-api`,
    });
    restApi.cfnOptions.metadata = {
      Comment: 'An API Gateway REST API',
    };

    const restApiAccessLog = new logs.CfnLogGroup(this, 'RestApiAccessLog', {
      logGroupName: `/aws/lambda/${props.resourceNamePrefix!}-rest-api-access`,
      retentionInDays: 90,
    });
    restApiAccessLog.cfnOptions.metadata = {
      Comment: 'A log group for the rest api function access logs',
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_158',
            commment: 'Log groups are encrypted by default',
          },
        ],
      },
      guard: {
        SuppressedRules: [
          'CLOUDWATCH_LOG_GROUP_ENCRYPTED',
        ],
        Comments: [
          'CloudWatch log groups are encrypted by default',
        ],
      },
    };

    const restApiCloudWatchRole = new iam.CfnRole(this, 'RestApiCloudWatchRole', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Action: 'sts:AssumeRole',
            Effect: 'Allow',
            Principal: {
              Service: [
                'apigateway.amazonaws.com',
                'lambda.amazonaws.com',
              ],
            },
          },
        ],
      },
      path: '/',
    });
    restApiCloudWatchRole.cfnOptions.metadata = {
      Comment: 'A role that allows the API Gateway REST API to log to CloudWatch.\nWe set this to retain to prevent an issue with the Account resource \nbeing a singleton that could result in the role being deleted for\na separately configured API. Ideally this role would be created \nseparately and referenced from this template and others like it.\n',
    };
    restApiCloudWatchRole.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.RETAIN;

    const restFunctionLogGroup = new logs.CfnLogGroup(this, 'RestFunctionLogGroup', {
      logGroupName: `/aws/lambda/${props.resourceNamePrefix!}-rest-api`,
      retentionInDays: 90,
    });
    restFunctionLogGroup.cfnOptions.metadata = {
      Comment: 'A log group for the rest api function',
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_158',
            commment: 'Log groups are encrypted by default',
          },
        ],
      },
      guard: {
        SuppressedRules: [
          'CLOUDWATCH_LOG_GROUP_ENCRYPTED',
        ],
        Comments: [
          'CloudWatch log groups are encrypted by default',
        ],
      },
    };

    const restFunctionRole = new iam.CfnRole(this, 'RestFunctionRole', {
      roleName: `${props.resourceNamePrefix!}-lambda-exec`,
      assumeRolePolicyDocument: {
        Statement: [
          {
            Action: [
              'sts:AssumeRole',
            ],
            Effect: 'Allow',
            Principal: {
              Service: [
                'lambda.amazonaws.com',
              ],
            },
          },
        ],
        Version: '2012-10-17',
      },
      managedPolicyArns: [
        'arn:aws:iam::aws:policy/AWSLambdaExecute',
      ],
      path: '/',
    });
    restFunctionRole.cfnOptions.metadata = {
      Comment: 'An execution role for the REST API Lambda function',
    };

    const restApiCloudWatchPolicy = new iam.CfnPolicy(this, 'RestApiCloudWatchPolicy', {
      policyName: 'cwlogsapigateway',
      policyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Action: [
              'logs:CreateLogGroup',
              'logs:CreateLogStream',
              'logs:DescribeLogGroups',
              'logs:DescribeLogStreams',
              'logs:PutLogEvents',
              'logs:GetLogEvents',
              'logs:FilterLogEvents',
            ],
            Effect: 'Allow',
            Resource: '*',
          },
        ],
      },
      roles: [
        restApiCloudWatchRole.ref,
      ],
    });
    restApiCloudWatchPolicy.cfnOptions.metadata = {
      Comment: 'A policy that allows the API Gateway REST API to log to CloudWatch.\nNote that we have to use a * for the resource here because this policy \nis attached to a role that is actually a singleton for all gateways \nin the region. Configuring the ::Account resource overwrites the role \nfor any previosly configured gateways.\n',
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_111',
            comment: 'This policy is a singleton for all gateways, so it needs access to all logs',
          },
        ],
      },
    };
    restApiCloudWatchPolicy.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.RETAIN;

    const restApiProxy = new apigateway.CfnResource(this, 'RestApiProxy', {
      parentId: restApi.attrRootResourceId,
      pathPart: '{proxy+}',
      restApiId: restApi.ref,
    });

    const restFunction = new lambda.CfnFunction(this, 'RestFunction', {
      functionName: `${props.resourceNamePrefix!}-rest-api`,
      runtime: 'python3.9',
      role: restFunctionRole.attrArn,
      handler: 'index.handler',
      reservedConcurrentExecutions: 100,
      code: {
        zipFile: 'import boto3\nimport json\ndef handler(event, context):\n  print(event)\n  return {\n      \"statusCode\": 200,\n      \"body\": json.dumps(\'Success\')\n  }\n',
      },
    });
    restFunction.cfnOptions.metadata = {
      Comment: 'A lambda function that implements REST API endpoints',
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_116',
            comment: 'This function is not called async',
          },
          {
            id: 'CKV_AWS_117',
            comment: 'This example does not run in a VPC',
          },
        ],
      },
      guard: {
        SuppressedRules: [
          'LAMBDA_INSIDE_VPC',
          'LAMBDA_DLQ_CHECK',
        ],
        Comments: [
          'This example does not run in a VPC',
          'The function is not called async so a DLQ is not necessary',
        ],
      },
    };
    restFunction.addDependency(restFunctionLogGroup);

    const restFunctionPolicy = new iam.CfnPolicy(this, 'RestFunctionPolicy', {
      policyName: 'lambdaexec',
      policyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Action: [
              'logs:CreateLogStream',
              'logs:PutLogEvents',
            ],
            Effect: 'Allow',
            Resource: [
              `arn:aws:logs:${this.region}:${this.account}:log-group:/aws/lambda/${props.resourceNamePrefix!}-rest-api`,
              `arn:aws:logs:${this.region}:${this.account}:log-group:/aws/lambda/${props.resourceNamePrefix!}-rest-api:*`,
            ],
          },
        ],
      },
      roles: [
        `${props.resourceNamePrefix!}-lambda-exec`,
      ],
    });
    restFunctionPolicy.cfnOptions.metadata = {
      Comment: 'A policy for the REST API Lambda function role',
    };
    restFunctionPolicy.addDependency(restFunctionRole);

    const restApiAnyProxy = new apigateway.CfnMethod(this, 'RestApiANYProxy', {
      httpMethod: 'ANY',
      resourceId: restApiProxy.ref,
      restApiId: restApi.ref,
      authorizationType: 'AWS_IAM',
      integration: {
        integrationHttpMethod: 'POST',
        type: 'AWS_PROXY',
        uri: `arn:${this.partition}:apigateway:${this.region}:lambda:path/2015-03-31/functions/${restFunction.attrArn}/invocations`,
      },
    });

    const restApiAnyRoot = new apigateway.CfnMethod(this, 'RestApiANYRoot', {
      httpMethod: 'ANY',
      resourceId: restApi.attrRootResourceId,
      restApiId: restApi.ref,
      authorizationType: 'AWS_IAM',
      integration: {
        integrationHttpMethod: 'POST',
        type: 'AWS_PROXY',
        uri: `arn:${this.partition}:apigateway:${this.region}:lambda:path/2015-03-31/functions/${restFunction.attrArn}/invocations`,
      },
    });

    const restApiAccount = new apigateway.CfnAccount(this, 'RestApiAccount', {
      cloudWatchRoleArn: restApiCloudWatchRole.attrArn,
    });
    restApiAccount.cfnOptions.metadata = {
      Comment: 'This is the API Gateway account resource to associate the role with the logs.\nThere is a gotcha with this resource since it\'s actually a singleton for all\ngateways in the account and region. The role will overwrite the role for all \nother gateways, and deleting it will delete it for the others, unless you \nput a retention policy on the role. The redundant DependsOn is required to \nprevent a race condition that causes an error when deploying the stack.\n',
      cfn-lint: {
        config: {
          'ignore_checks': [
            'W3005',
          ],
        },
      },
    };
    restApiAccount.addDependency(restApi);
    restApiAccount.addDependency(restApiCloudWatchRole);
    restApiAccount.addDependency(restApiCloudWatchPolicy);

    const restApiPermission = new lambda.CfnPermission(this, 'RestApiPermission', {
      action: 'lambda:InvokeFunction',
      functionName: restFunction.attrArn,
      principal: 'apigateway.amazonaws.com',
      sourceArn: `arn:${this.partition}:execute-api:${this.region}:${this.account}:${restApi.ref}/*/*/*`,
    });

    const restApiRootPermission = new lambda.CfnPermission(this, 'RestApiRootPermission', {
      action: 'lambda:InvokeFunction',
      functionName: restFunction.attrArn,
      principal: 'apigateway.amazonaws.com',
      sourceArn: `arn:${this.partition}:execute-api:${this.region}:${this.account}:${restApi.ref}/*/*/`,
    });

    const restApiDeployment = new apigateway.CfnDeployment(this, 'RestApiDeployment', {
      restApiId: restApi.ref,
    });
    restApiDeployment.addDependency(restApiAnyProxy);
    restApiDeployment.addDependency(restApiAnyRoot);

    const restApiStage = new apigateway.CfnStage(this, 'RestApiStage', {
      restApiId: restApi.ref,
      deploymentId: restApiDeployment.ref,
      stageName: 'prod',
      tracingEnabled: true,
      accessLogSetting: {
        destinationArn: restApiAccessLog.attrArn,
        format: '$context.identity.sourceIp $context.identity.caller $context.identity.user [$context.requestTime] $context.httpMethod $context.resourcePath $context.protocol $context.status $context.responseLength $context.requestId $context.extendedRequestId',
      },
    });
    restApiStage.cfnOptions.metadata = {
      Comment: 'The API Gateway stage resource',
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_120',
            comment: 'Caching is not always needed and can increase costs',
          },
        ],
      },
    };
  }
}
