import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';

export interface ExpectedStackProps extends cdk.StackProps {
}

/**
 * AWS CloudFormation Sample Template RDS_Snapshot_On_Delete: Sample template showing how to create an RDS DBInstance that is snapshotted on stack deletion. **WARNING** This template creates an Amazon RDS database instance. When the stack is deleted a database snapshot will be left in your account. You will be billed for the AWS resources used if you create a stack from this template.
 */
export class ExpectedStack extends cdk.Stack {
  /**
   * JDBC connection string for the database
   */
  public readonly jdbcConnectionString;

  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps = {}) {
    super(scope, id, props);

    // Resources
    const myDb = new rds.CfnDBInstance(this, 'MyDB', {
      dbName: 'MyDatabase',
      allocatedStorage: '5',
      dbInstanceClass: 'db.t3.small',
      backupRetentionPeriod: 7,
      engine: 'MySQL',
      masterUsername: 'myName',
      manageMasterUserPassword: true,
      publiclyAccessible: false,
      storageEncrypted: true,
      multiAz: true,
    });
    myDb.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.SNAPSHOT;

    // Outputs
    this.jdbcConnectionString = [
      'jdbc:mysql://',
      myDb.attrEndpointAddress,
      ':',
      myDb.attrEndpointPort,
      '/MyDatabase',
    ].join('');
    new cdk.CfnOutput(this, 'CfnOutputJDBCConnectionString', {
      key: 'JDBCConnectionString',
      description: 'JDBC connection string for the database',
      value: this.jdbcConnectionString!.toString(),
    });
  }
}
