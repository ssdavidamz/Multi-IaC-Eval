import * as cdk from 'aws-cdk-lib';
import * as events from 'aws-cdk-lib/aws-events';

export interface ExpectedStackProps extends cdk.StackProps {
  /**
   */
  readonly organizationId: string;
}

/**
 * This stack will create different event bus policies

 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps) {
    super(scope, id, props);

    // Resources
    const customEventBus = new events.CfnEventBus(this, 'CustomEventBus', {
      name: 'OrganizationalEventBus',
    });

    const oneAccountEventBusPolicy = new events.CfnEventBusPolicy(this, 'OneAccountEventBusPolicy', {
      statementId: 'OneAccountPut',
      statement: {
        Effect: 'Allow',
        Principal: {
          AWS: `arn:${this.partition}:iam::${this.account}:root`,
        },
        Action: 'events:PutEvents',
        Resource: `arn:${this.partition}:events:${this.region}:${this.account}:event-bus/default`,
      },
    });

    const organizationEventBusPolicy = new events.CfnEventBusPolicy(this, 'OrganizationEventBusPolicy', {
      statementId: 'OrganizationalPut',
      statement: {
        Effect: 'Allow',
        Principal: '*',
        Action: 'events:PutEvents',
        Resource: `arn:${this.partition}:events:${this.region}:${this.account}:event-bus/default`,
        Condition: {
          StringEquals: {
            'aws:PrincipalOrgID': props.organizationId!,
          },
        },
      },
    });

    const customEventBusRule = new events.CfnRule(this, 'CustomEventBusRule', {
      name: 'OrganizationalEventBusRule',
      eventBusName: customEventBus.ref,
      eventPattern: {
        source: [
          'my.custom.source',
        ],
      },
      targets: [
        {
          arn: `arn:${this.partition}:sns::${this.account}:MySNSTopic`,
          id: 'MySNSTarget',
        },
      ],
    });

    const organizationEventBusPolicyCustomBus = new events.CfnEventBusPolicy(this, 'OrganizationEventBusPolicyCustomBus', {
      eventBusName: customEventBus.ref,
      statementId: 'OrganizationalPutCustomBus',
      statement: {
        Effect: 'Allow',
        Principal: '*',
        Action: 'events:PutEvents',
        Resource: customEventBus.attrArn,
        Condition: {
          StringEquals: {
            'aws:PrincipalOrgID': props.organizationId!,
          },
        },
      },
    });
  }
}
