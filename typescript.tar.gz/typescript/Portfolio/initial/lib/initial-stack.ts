import * as cdk from 'aws-cdk-lib';
import * as servicecatalog from 'aws-cdk-lib/aws-servicecatalog';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * Please specify the target Environment. Used for tagging and resource names. Mandatory LOWER CASE.
   * @default 'dev'
   */
  readonly env?: string;
  /**
   * Please specify the Department. Used for tagging
   * @default '1234'
   */
  readonly dept?: string;
  /**
   * Please specify the User. Used for tagging
   * @default 'User'
   */
  readonly user?: string;
  /**
   * Please specify the Owner. Used for tagging
   * @default 'Owner'
   */
  readonly owner?: string;
  /**
   * Please specify the target Environment. Used for tagging and resource names. Mandatory LOWER CASE.
   * @default 'dev'
   */
  readonly productEnv?: string;
  /**
   * Please specify the Department. Used for tagging
   * @default '1234'
   */
  readonly productDept?: string;
  /**
   * Please specify the User. Used for tagging
   * @default 'User'
   */
  readonly productUser?: string;
  /**
   * Please specify the Owner. Used for tagging
   * @default 'Owner'
   */
  readonly productOwner?: string;
  /**
   * Please specify the Portfolio Provider Name.
   * @default 'IT Provider'
   */
  readonly portfolioProviderName?: string;
  /**
   * Please specify the Portfolio Description.
   * @default 'Service Catalog Portfolio for Business Unit (BU)'
   */
  readonly portfolioDescription?: string;
  /**
   * Please specify the Portfolio Description. Must satisfy regular expression pattern, (^[a-zA-Z0-9_\-]*)
   * @default 'Test_Portfolio'
   */
  readonly portfolioDisplayName?: string;
  /**
   * Activate Custom Tag Options? Used for portfolio tagging
   * @default 'true'
   */
  readonly activateProductTagOptions?: boolean;
  /**
   * Please specify if this Portfolio will be Shared with additonal accounts?
   * @default 'false'
   */
  readonly shareThisPortfolio?: boolean;
  /**
   * Please specify the Sub AWS Account ID.
   * @default '1234567890'
   */
  readonly accountIdOfChildAwsAccount?: string;
}

/**
 * CI/CD optimized AWS CloudFormation Sample Template for AWS Service Catalog Portfolio creation. ### Before deployment please make sure that all parameters are reviewed and updated according the specific use case. ### **WARNING** This template creates AWS Service Catalog Portfolio, please make sure you review billing costs for AWS Service Catalog.
 */
export class InitialStack extends cdk.Stack {
  public readonly serviceCatalogPortfolio;
  public readonly serviceCatalogPortfolioName;
  public readonly serviceCatalogProductTagOptionsDept;

  public constructor(scope: cdk.App, id: string, props: InitialStackProps = {}) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      env: props.env ?? 'dev',
      dept: props.dept ?? '1234',
      user: props.user ?? 'User',
      owner: props.owner ?? 'Owner',
      productEnv: props.productEnv ?? 'dev',
      productDept: props.productDept ?? '1234',
      productUser: props.productUser ?? 'User',
      productOwner: props.productOwner ?? 'Owner',
      portfolioProviderName: props.portfolioProviderName ?? 'IT Provider',
      portfolioDescription: props.portfolioDescription ?? 'Service Catalog Portfolio for Business Unit (BU)',
      portfolioDisplayName: props.portfolioDisplayName ?? 'Test_Portfolio',
      activateProductTagOptions: props.activateProductTagOptions ?? true,
      shareThisPortfolio: props.shareThisPortfolio ?? false,
      accountIdOfChildAwsAccount: props.accountIdOfChildAwsAccount ?? '1234567890',
    };

    // Conditions
    const conditionShareThisPortfolio = props.shareThisPortfolio! === 'true';

    // Resources
    const serviceCatalogPortfolio = new servicecatalog.CfnPortfolio(this, 'ServiceCatalogPortfolio', {
      providerName: props.portfolioProviderName!,
      description: props.portfolioDescription!,
      displayName: props.portfolioDisplayName!,
      tags: [
        {
          key: 'Name',
          value: `${props.portfolioDisplayName!}`,
        },
        {
          key: 'Dept',
          value: `${props.dept!}`,
        },
        {
          key: 'Env',
          value: `${props.env!}`,
        },
        {
          key: 'User',
          value: `${props.user!}`,
        },
        {
          key: 'Owner',
          value: `${props.owner!}`,
        },
      ],
    });

    const serviceCatalogProductTagOptionsDept = new servicecatalog.CfnTagOption(this, 'ServiceCatalogProductTagOptionsDept', {
      active: props.activateProductTagOptions!,
      key: 'Dept',
      value: `${props.productDept!}`,
    });

    const serviceCatalogProductTagOptionsEnv = new servicecatalog.CfnTagOption(this, 'ServiceCatalogProductTagOptionsEnv', {
      active: props.activateProductTagOptions!,
      key: 'Env',
      value: `${props.productEnv!}`,
    });

    const serviceCatalogProductTagOptionsOwner = new servicecatalog.CfnTagOption(this, 'ServiceCatalogProductTagOptionsOwner', {
      active: props.activateProductTagOptions!,
      key: 'Owner',
      value: `${props.productOwner!}`,
    });

    const serviceCatalogProductTagOptionsUser = new servicecatalog.CfnTagOption(this, 'ServiceCatalogProductTagOptionsUser', {
      active: props.activateProductTagOptions!,
      key: 'User',
      value: `${props.productUser!}`,
    });

    const serviceCatalogPortfolioShare = conditionShareThisPortfolio
      ? new servicecatalog.CfnPortfolioShare(this, 'ServiceCatalogPortfolioShare', {
          accountId: props.accountIdOfChildAwsAccount!,
          portfolioId: serviceCatalogPortfolio.ref,
        })
      : undefined;
    if (serviceCatalogPortfolioShare != null) {
    }

    // Outputs
    this.serviceCatalogPortfolio = serviceCatalogPortfolio.ref;
    new cdk.CfnOutput(this, 'CfnOutputServiceCatalogPortfolio', {
      key: 'ServiceCatalogPortfolio',
      exportName: `${this.stackName}-ServiceCatalogPortfolio`,
      value: this.serviceCatalogPortfolio!.toString(),
    });
    this.serviceCatalogPortfolioName = serviceCatalogPortfolio.attrPortfolioName;
    new cdk.CfnOutput(this, 'CfnOutputServiceCatalogPortfolioName', {
      key: 'ServiceCatalogPortfolioName',
      exportName: `${this.stackName}-ServiceCatalogPortfolioName`,
      value: this.serviceCatalogPortfolioName!.toString(),
    });
    this.serviceCatalogProductTagOptionsDept = serviceCatalogProductTagOptionsDept.ref;
    new cdk.CfnOutput(this, 'CfnOutputServiceCatalogProductTagOptionsDept', {
      key: 'ServiceCatalogProductTagOptionsDept',
      exportName: `${this.stackName}-ServiceCatalogProductTagOptionsDept`,
      value: this.serviceCatalogProductTagOptionsDept!.toString(),
    });
  }
}
