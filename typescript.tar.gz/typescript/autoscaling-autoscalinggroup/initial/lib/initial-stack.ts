import * as cdk from 'aws-cdk-lib';
import * as autoscaling from 'aws-cdk-lib/aws-autoscaling';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * Region specific image from the Parameter Store
   * @default '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2'
   */
  readonly latestAmiId?: string;
  /**
   * A VPC ID for the security group
   */
  readonly vpcId: string;
  /**
   * A list of subnets for the Auto Scaling group
   */
  readonly subnets: string[];
}

/**
 * This stack automates the creation of an AWS Auto Scaling group
 * using the latest EC2 AMI image using Amazon Linux 2. It also creates
 * the related resources like a launch template and security groups

 */
export class InitialStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      latestAmiId: new cdk.CfnParameter(this, 'LatestAmiId', {
        type: 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default: props.latestAmiId?.toString() ?? '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2',
        description: 'Region specific image from the Parameter Store',
      }).valueAsString,
      vpcId: new cdk.CfnParameter(this, 'VpcId', {
        type: 'AWS::EC2::VPC::Id',
        default: props.vpcId.toString(),
        description: 'A VPC ID for the security group',
      }).valueAsString,
      subnets: new cdk.CfnParameter(this, 'Subnets', {
        type: 'List<AWS::EC2::Subnet::Id>',
        default: props.subnets.join(','),
        description: 'A list of subnets for the Auto Scaling group',
      }).valueAsList,
    };

    // Resources
    const securityGroup = new ec2.CfnSecurityGroup(this, 'SecurityGroup', {
      groupDescription: 'Auto scaling group security group',
      vpcId: props.vpcId!,
    });

    const launchTemplate = new ec2.CfnLaunchTemplate(this, 'LaunchTemplate', {
      launchTemplateName: `${this.stackName}-launch-template`,
      launchTemplateData: {
        imageId: props.latestAmiId!,
        instanceType: 't3.micro',
        securityGroupIds: [
          securityGroup.attrGroupId,
        ],
        metadataOptions: {
          httpEndpoint: 'disabled',
        },
      },
    });

    const autoScalingGroup = new autoscaling.CfnAutoScalingGroup(this, 'AutoScalingGroup', {
      launchTemplate: {
        launchTemplateId: launchTemplate.ref,
        version: launchTemplate.attrLatestVersionNumber,
      },
      maxSize: '1',
      minSize: '0',
      desiredCapacity: '1',
      vpcZoneIdentifier: props.subnets!,
    });
  }
}
