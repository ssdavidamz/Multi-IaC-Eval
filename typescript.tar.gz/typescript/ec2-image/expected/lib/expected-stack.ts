import * as cdk from 'aws-cdk-lib';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as imagebuilder from 'aws-cdk-lib/aws-imagebuilder';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as sns from 'aws-cdk-lib/aws-sns';
import * as ssm from 'aws-cdk-lib/aws-ssm';

export interface ExpectedStackProps extends cdk.StackProps {
}

/**
 * This stack automates the creation of an EC2 AMI image using Amazon Linux 2.
 * It also creates the related resources such as roles and policies.

 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps = {}) {
    super(scope, id, props);

    // Resources
    const al2ssmImageRecipe = new imagebuilder.CfnImageRecipe(this, 'AL2SSMImageRecipe', {
      name: 'AL2-SSM',
      version: '0.0.1',
      parentImage: `arn:${this.partition}:imagebuilder:${this.region}:aws:image/amazon-linux-2-x86/x.x.x`,
      components: [
        {
          componentArn: `arn:${this.partition}:imagebuilder:${this.region}:aws:component/update-linux/x.x.x`,
        },
      ],
      additionalInstanceConfiguration: {
        userDataOverride: cdk.Fn.base64(`#!/bin/bash
        sudo yum install -y https://s3.${this.region}.${this.urlSuffix}/amazon-ssm-${this.region}/latest/linux_amd64/amazon-ssm-agent.rpm
        `),
      },
    });
    al2ssmImageRecipe.cfnOptions.metadata = {
      Comment: 'An image builder recipe to build the latest version of Amazon Linux 2 with SSM support',
    };

    const imageBuilderInstanceRole = new iam.CfnRole(this, 'ImageBuilderInstanceRole', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Action: [
              'sts:AssumeRole',
            ],
            Effect: 'Allow',
            Principal: {
              Service: [
                `ec2.${this.urlSuffix}`,
              ],
            },
          },
        ],
        Version: '2012-10-17',
      },
      path: '/imagebuilder/',
    });
    imageBuilderInstanceRole.cfnOptions.metadata = {
      Comment: 'Role to be used by instance during image build.',
    };

    const imageBuilderInstanceTopic = new sns.CfnTopic(this, 'ImageBuilderInstanceTopic', {
      topicName: 'ImageBuilderInstanceTopic',
    });

    const imageBuilderLogBucket = new s3.CfnBucket(this, 'ImageBuilderLogBucket', {
      bucketEncryption: {
        serverSideEncryptionConfiguration: [
          {
            serverSideEncryptionByDefault: {
              sseAlgorithm: 'AES256',
            },
          },
        ],
      },
      publicAccessBlockConfiguration: {
        blockPublicAcls: true,
        ignorePublicAcls: true,
        blockPublicPolicy: true,
        restrictPublicBuckets: true,
      },
      objectLockEnabled: false,
      versioningConfiguration: {
        status: 'Enabled',
      },
    });
    imageBuilderLogBucket.cfnOptions.metadata = {
      Comment: 'An S3 bucket to hold image builder logs',
      guard: {
        SuppressedRules: [
          'S3_BUCKET_DEFAULT_LOCK_ENABLED',
          'S3_BUCKET_REPLICATION_ENABLED',
          'S3_BUCKET_LOGGING_ENABLED',
        ],
      },
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_18',
            comment: 'This is a log bucket',
          },
        ],
      },
    };

    const imageBuilderLogGroup = new logs.CfnLogGroup(this, 'ImageBuilderLogGroup', {
      logGroupName: '/aws/imagebuilder/AL2-SSM',
      retentionInDays: 3,
    });
    imageBuilderLogGroup.cfnOptions.metadata = {
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_158',
            comment: 'Log groups are encrypted by default',
          },
        ],
      },
      guard: {
        SuppressedRules: [
          'CLOUDWATCH_LOG_GROUP_ENCRYPTED',
        ],
      },
    };
    imageBuilderLogGroup.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.DELETE;

    const imageBuilderInstancePolicy = new iam.CfnPolicy(this, 'ImageBuilderInstancePolicy', {
      policyName: 'imagebuilder',
      policyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Action: [
              'ssm:DescribeAssociation',
              'ssm:GetDeployablePatchSnapshotForInstance',
              'ssm:GetDocument',
              'ssm:DescribeDocument',
              'ssm:GetManifest',
              'ssm:GetParameter',
              'ssm:GetParameters',
              'ssm:ListAssociations',
              'ssm:ListInstanceAssociations',
              'ssm:PutInventory',
              'ssm:PutComplianceItems',
              'ssm:PutConfigurePackageResult',
              'ssm:UpdateAssociationStatus',
              'ssm:UpdateInstanceAssociationStatus',
              'ssm:UpdateInstanceInformation',
            ],
            Effect: 'Allow',
            Resource: '*',
          },
          {
            Action: [
              'ssmmessages:CreateControlChannel',
              'ssmmessages:CreateDataChannel',
              'ssmmessages:OpenControlChannel',
              'ssmmessages:OpenDataChannel',
            ],
            Effect: 'Allow',
            Resource: '*',
          },
          {
            Action: [
              'ec2messages:AcknowledgeMessage',
              'ec2messages:DeleteMessage',
              'ec2messages:FailMessage',
              'ec2messages:GetEndpoint',
              'ec2messages:GetMessages',
              'ec2messages:SendReply',
            ],
            Effect: 'Allow',
            Resource: '*',
          },
          {
            Effect: 'Allow',
            Action: [
              'imagebuilder:GetComponent',
            ],
            Resource: '*',
          },
          {
            Effect: 'Allow',
            Action: [
              'kms:Decrypt',
            ],
            Resource: '*',
            Condition: {
              'ForAnyValue:StringEquals': {
                'kms:EncryptionContextKeys': 'aws:imagebuilder:arn',
                'aws:CalledVia': [
                  'imagebuilder.amazonaws.com',
                ],
              },
            },
          },
          {
            Effect: 'Allow',
            Action: [
              's3:GetObject',
            ],
            Resource: 'arn:aws:s3:::ec2imagebuilder*',
          },
          {
            Effect: 'Allow',
            Action: [
              'logs:CreateLogStream',
              'logs:CreateLogGroup',
              'logs:PutLogEvents',
            ],
            Resource: 'arn:aws:logs:*:*:log-group:/aws/imagebuilder/*',
          },
        ],
      },
      roles: [
        imageBuilderInstanceRole.ref,
      ],
    });
    imageBuilderInstancePolicy.cfnOptions.metadata = {
      Comment: 'An IAM policy to give EC2 Image Builder and SSM permissions to build images.\nThis policy is based on AmazonSSMManagedInstanceCore and EC2InstanceProfileForImageBuilder.\n',
      cfn-lint: {
        config: {
          'ignore_checks': [
            'W3005',
          ],
        },
      },
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_111',
            comment: 'Resource Arns are not supported for ssmmessages and ec2messages',
          },
          {
            id: 'CKV_AWS_108',
            commment: 'Image builder does not allow specific resources to be named for creation',
          },
        ],
      },
    };
    imageBuilderInstancePolicy.addDependency(imageBuilderInstanceRole);

    const imageBuilderInstanceProfile = new iam.CfnInstanceProfile(this, 'ImageBuilderInstanceProfile', {
      path: '/imagebuilder/',
      roles: [
        imageBuilderInstanceRole.ref,
      ],
    });

    const imageBuilderInstanceSubscription = new sns.CfnSubscription(this, 'ImageBuilderInstanceSubscription', {
      protocol: 'email',
      endpoint: 'example@example.com',
      topicArn: imageBuilderInstanceTopic.ref,
    });

    const imageBuilderLogPolicy = new iam.CfnPolicy(this, 'ImageBuilderLogPolicy', {
      policyName: 'ImageBuilderLogBucketPolicy',
      roles: [
        imageBuilderInstanceRole.ref,
      ],
      policyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Action: [
              's3:PutObject',
            ],
            Effect: 'Allow',
            Resource: [
              `arn:${this.partition}:s3:::${imageBuilderLogBucket.ref}/*`,
            ],
          },
        ],
      },
    });
    imageBuilderLogPolicy.cfnOptions.metadata = {
      Comment: 'A policy to allow the instance to save log files to the log bucket',
    };

    const imageBuilderConfig = new imagebuilder.CfnInfrastructureConfiguration(this, 'ImageBuilderConfig', {
      name: 'AL2-SSM',
      instanceProfileName: imageBuilderInstanceProfile.ref,
      logging: {
        s3Logs: {
          s3BucketName: imageBuilderLogBucket.ref,
        },
      },
      terminateInstanceOnFailure: false,
    });

    const al2ssmImage = new imagebuilder.CfnImage(this, 'AL2SSMImage', {
      imageRecipeArn: al2ssmImageRecipe.ref,
      infrastructureConfigurationArn: imageBuilderConfig.ref,
    });
    al2ssmImage.cfnOptions.metadata = {
      Comment: 'An image builder image',
    };

    const al2ssmImageParameter = new ssm.CfnParameter(this, 'AL2SSMImageParameter', {
      description: 'AL2 with SSM image id',
      name: '/images/AL2SSMImageId',
      type: 'String',
      value: al2ssmImage.attrImageId,
    });
    al2ssmImageParameter.cfnOptions.metadata = {
      Comment: 'An SSM Parameter to store the image id',
    };

    const imageBuilderInstanceAlarm = new cloudwatch.CfnAlarm(this, 'ImageBuilderInstanceAlarm', {
      alarmName: 'ImageBuilderInstanceAlarm',
      alarmDescription: 'Alarm when average CPU utilization exceeds 80% for 5 minutes',
      metrics: [
        {
          id: 'm1',
          metricStat: {
            metric: {
              namespace: 'AWS/EC2',
              metricName: 'CPUUtilization',
              dimensions: [
                {
                  name: 'ImageId',
                  value: al2ssmImage.attrImageId,
                },
              ],
            },
            period: 300,
            stat: 'Average',
          },
        },
      ],
      comparisonOperator: 'GreaterThanThreshold',
      threshold: 80,
      evaluationPeriods: 1,
      treatMissingData: 'notBreaching',
      alarmActions: [
        imageBuilderInstanceTopic.ref,
      ],
    });
  }
}
