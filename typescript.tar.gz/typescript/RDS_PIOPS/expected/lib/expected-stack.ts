import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';

export interface ExpectedStackProps extends cdk.StackProps {
  /**
   * The database admin account username
   */
  readonly dbUser: string;
}

/**
 * AWS CloudFormation Sample Template RDS_PIOPS: Sample template showing how to create an Amazon RDS Database Instance with provisioned IOPs.**WARNING** This template creates an Amazon Relational Database Service database instance. You will be billed for the AWS resources used if you create a stack from this template.
 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps) {
    super(scope, id, props);

    // Resources
    const dbCredential = new secretsmanager.CfnSecret(this, 'DBCredential', {
      generateSecretString: {
        passwordLength: 16,
        excludeCharacters: '\"@/\\',
        requireEachIncludedType: true,
      },
    });

    const myDb = new rds.CfnDBInstance(this, 'myDB', {
      allocatedStorage: '100',
      dbInstanceClass: 'db.t3.small',
      backupRetentionPeriod: 7,
      engine: 'MySQL',
      iops: 1000,
      masterUsername: props.dbUser!,
      masterUserPassword: `{{resolve:secretsmanager:${dbCredential.ref}}}`,
      publiclyAccessible: false,
      storageEncrypted: true,
      multiAz: true,
    });
    myDb.addDependency(dbCredential);
  }
}
