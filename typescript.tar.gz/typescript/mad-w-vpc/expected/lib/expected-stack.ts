import * as cdk from 'aws-cdk-lib';
import * as directoryservice from 'aws-cdk-lib/aws-directoryservice';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';

export interface ExpectedStackProps extends cdk.StackProps {
}

/**
 * Create a VPC with 2 subnets for the AWS Managed Microsoft AD with a password stored in secrets manager and add an S3 bucket for storing AD logs

 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps = {}) {
    super(scope, id, props);

    // Resources
    const adLogsBucket = new s3.CfnBucket(this, 'ADLogsBucket', {
      bucketName: `ad-logs-${this.stackName}`,
      versioningConfiguration: {
        status: 'Enabled',
      },
      loggingConfiguration: {
        destinationBucketName: `ad-logs-destination-${this.stackName}`,
        logFilePrefix: 'ad-logs/',
      },
    });

    const awsManagedAdSecret = new secretsmanager.CfnSecret(this, 'AWSManagedADSecret', {
      description: 'Secret used for provisioning Managed AD',
      generateSecretString: {
        passwordLength: 24,
      },
    });
    awsManagedAdSecret.cfnOptions.metadata = {
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_149',
          },
        ],
      },
      guard: {
        SuppressedRules: [
          'SECRETSMANAGER_USING_CMK',
          'SECRETSMANAGER_ROTATION_ENABLED_CHECK',
        ],
      },
    };

    const vpc = new ec2.CfnVPC(this, 'VPC', {
      cidrBlock: '10.0.0.0/24',
      enableDnsHostnames: true,
      enableDnsSupport: true,
      instanceTenancy: 'default',
    });

    const vpcSubnet1 = new ec2.CfnSubnet(this, 'VPCSubnet1', {
      availabilityZone: cdk.Fn.select(0, cdk.Fn.getAzs(this.region)),
      cidrBlock: cdk.Fn.select(0, cdk.Fn.cidr(vpc.attrCidrBlock, 2, String(6))),
      mapPublicIpOnLaunch: false,
      vpcId: vpc.ref,
    });

    const vpcSubnet2 = new ec2.CfnSubnet(this, 'VPCSubnet2', {
      availabilityZone: cdk.Fn.select(1, cdk.Fn.getAzs(this.region)),
      cidrBlock: cdk.Fn.select(1, cdk.Fn.cidr(vpc.attrCidrBlock, 2, String(6))),
      mapPublicIpOnLaunch: false,
      vpcId: vpc.ref,
    });

    const managedAd = new directoryservice.CfnMicrosoftAD(this, 'ManagedAD', {
      createAlias: false,
      edition: 'Enterprise',
      enableSso: false,
      name: 'corp.example.com',
      password: `{{resolve:secretsmanager:${awsManagedAdSecret.ref}}}`,
      shortName: 'CORP',
      vpcSettings: {
        subnetIds: [
          vpcSubnet1.ref,
          vpcSubnet2.ref,
        ],
        vpcId: vpc.ref,
      },
    });
  }
}
