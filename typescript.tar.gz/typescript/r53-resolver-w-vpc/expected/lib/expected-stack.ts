import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as route53resolver from 'aws-cdk-lib/aws-route53resolver';
import * as s3 from 'aws-cdk-lib/aws-s3';

export interface ExpectedStackProps extends cdk.StackProps {
}

/**
 * Create a VPC with 2 subnets for Inbound and Outbound Route 53 Resolvers

 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps = {}) {
    super(scope, id, props);

    // Resources
    const logsBucket = new s3.CfnBucket(this, 'LogsBucket', {
      bucketName: 'r53-resolver-logs-bucket',
      versioningConfiguration: {
        status: 'Enabled',
      },
    });

    const vpc = new ec2.CfnVPC(this, 'VPC', {
      cidrBlock: '10.0.0.0/24',
      enableDnsHostnames: true,
      enableDnsSupport: true,
      instanceTenancy: 'default',
    });

    const r53sg = new ec2.CfnSecurityGroup(this, 'R53SG', {
      groupDescription: 'R53-Outbound-Resolver-Security-Group',
      groupName: 'R53-Outbound-Resolver-Security-Group',
      securityGroupEgress: [
        {
          description: 'DNS Access',
          fromPort: 53,
          ipProtocol: 'udp',
          cidrIp: '0.0.0.0/0',
          toPort: 53,
        },
        {
          description: 'DNS Access',
          fromPort: 53,
          ipProtocol: 'udp',
          cidrIp: '0.0.0.0/0',
          toPort: 53,
        },
      ],
      securityGroupIngress: [
        {
          description: 'DNS',
          fromPort: 53,
          ipProtocol: 'tcp',
          cidrIp: vpc.attrCidrBlock,
          toPort: 53,
        },
        {
          description: 'DNS',
          fromPort: 53,
          ipProtocol: 'udp',
          cidrIp: vpc.attrCidrBlock,
          toPort: 53,
        },
      ],
      vpcId: vpc.ref,
    });

    const vpcSubnet1 = new ec2.CfnSubnet(this, 'VPCSubnet1', {
      availabilityZone: cdk.Fn.select(0, cdk.Fn.getAzs(this.region)),
      cidrBlock: cdk.Fn.select(0, cdk.Fn.cidr(vpc.attrCidrBlock, 2, String(6))),
      mapPublicIpOnLaunch: false,
      vpcId: vpc.ref,
    });

    const vpcSubnet2 = new ec2.CfnSubnet(this, 'VPCSubnet2', {
      availabilityZone: cdk.Fn.select(1, cdk.Fn.getAzs(this.region)),
      cidrBlock: cdk.Fn.select(1, cdk.Fn.cidr(vpc.attrCidrBlock, 2, String(6))),
      mapPublicIpOnLaunch: false,
      vpcId: vpc.ref,
    });

    const r53rInbound = new route53resolver.CfnResolverEndpoint(this, 'R53RInbound', {
      direction: 'INBOUND',
      ipAddresses: [
        {
          subnetId: vpcSubnet1.ref,
        },
        {
          subnetId: vpcSubnet2.ref,
        },
      ],
      name: 'R53-Inbound-Resolver',
      securityGroupIds: [
        r53sg.ref,
      ],
    });

    const r53rrOutbound = new route53resolver.CfnResolverEndpoint(this, 'R53RROutbound', {
      direction: 'OUTBOUND',
      ipAddresses: [
        {
          subnetId: vpcSubnet1.ref,
        },
        {
          subnetId: vpcSubnet2.ref,
        },
      ],
      name: 'R53-Outbound-Resolver',
      securityGroupIds: [
        r53sg.ref,
      ],
    });

    const rr53RuleMad = new route53resolver.CfnResolverRule(this, 'RR53RuleMAD', {
      name: 'R53-Rule-Test',
      domainName: 'aws.amazon.com',
      resolverEndpointId: r53rrOutbound.ref,
      ruleType: 'FORWARD',
      targetIps: [
        {
          ip: '10.0.0.10',
        },
      ],
    });

    const rr53rrAssocMad = new route53resolver.CfnResolverRuleAssociation(this, 'RR53RRAssocMad', {
      resolverRuleId: rr53RuleMad.ref,
      vpcId: vpc.ref,
    });
  }
}
