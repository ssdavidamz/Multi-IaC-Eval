import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * The database name
   * @default 'MyDatabase'
   */
  readonly dbName?: string;
  /**
   * The database admin account username
   */
  readonly dbUser: string;
}

/**
 * Sample template showing how to create an Amazon RDS Database Instance with a
 * DBParameterGroup. **WARNING** This template creates an Amazon Relational
 * Database Service database instance. You will be billed for the AWS
 * resources used if you create a stack from this template.

 */
export class InitialStack extends cdk.Stack {
  /**
   * JDBC connection string for the database
   */
  public readonly jdbcConnectionString;

  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      dbName: props.dbName ?? 'MyDatabase',
    };

    // Resources
    const myRdsParamGroup = new rds.CfnDBParameterGroup(this, 'MyRDSParamGroup', {
      family: 'MySQL8.0',
      description: 'CloudFormation Sample Database Parameter Group',
      parameters: {
        autocommit: '1',
        'general_log': '1',
      },
    });

    const myDb = new rds.CfnDBInstance(this, 'MyDB', {
      dbName: props.dbName!,
      allocatedStorage: '5',
      dbInstanceClass: 'db.t3.small',
      backupRetentionPeriod: 7,
      engine: 'MySQL',
      engineVersion: '8.0.36',
      masterUsername: props.dbUser!,
      manageMasterUserPassword: true,
      dbParameterGroupName: myRdsParamGroup.ref,
      publiclyAccessible: false,
      storageEncrypted: true,
    });
    myDb.cfnOptions.deletionPolicy = cdk.CfnDeletionPolicy.SNAPSHOT;

    // Outputs
    this.jdbcConnectionString = [
      'jdbc:mysql://',
      myDb.attrEndpointAddress,
      ':',
      myDb.attrEndpointPort,
      '/',
      props.dbName!,
    ].join('');
    new cdk.CfnOutput(this, 'CfnOutputJDBCConnectionString', {
      key: 'JDBCConnectionString',
      description: 'JDBC connection string for the database',
      value: this.jdbcConnectionString!.toString(),
    });
  }
}
