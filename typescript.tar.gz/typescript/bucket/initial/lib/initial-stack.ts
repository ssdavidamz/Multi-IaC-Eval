import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';

export interface InitialStackProps extends cdk.StackProps {
  /**
   */
  readonly resourceNamePrefix: string;
}

/**
 * Create a secure bucket that passes security scanning checks.
 * Also create a bucket to store replicas, and an access log bucket.

 */
export class InitialStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Resources
    const logBucket = new s3.CfnBucket(this, 'LogBucket', {
      bucketName: `${props.resourceNamePrefix!}-logs-${this.region}-${this.account}`,
      versioningConfiguration: {
        status: 'Enabled',
      },
      bucketEncryption: {
        serverSideEncryptionConfiguration: [
          {
            serverSideEncryptionByDefault: {
              sseAlgorithm: 'AES256',
            },
          },
        ],
      },
      publicAccessBlockConfiguration: {
        blockPublicAcls: true,
        blockPublicPolicy: true,
        ignorePublicAcls: true,
        restrictPublicBuckets: true,
      },
      objectLockEnabled: true,
      objectLockConfiguration: {
        objectLockEnabled: 'Enabled',
        rule: {
          defaultRetention: {
            mode: 'COMPLIANCE',
            years: 1,
          },
        },
      },
    });
    logBucket.cfnOptions.metadata = {
      Comment: 'This bucket records access logs for MyBucket',
      cfn_nag: {
        'rules_to_suppress': [
          {
            id: 'W35',
            reason: 'This is the log bucket',
          },
          {
            id: 'W51',
            reason: 'Will be added by the consumer',
          },
        ],
      },
      guard: {
        SuppressedRules: [
          'S3_BUCKET_LOGGING_ENABLED',
          'S3_BUCKET_REPLICATION_ENABLED',
        ],
      },
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_18',
            comment: 'This is the log bucket',
          },
        ],
      },
    };

    const replicaBucket = new s3.CfnBucket(this, 'ReplicaBucket', {
      bucketName: `${props.resourceNamePrefix!}-replicas-${this.region}-${this.account}`,
      versioningConfiguration: {
        status: 'Enabled',
      },
      bucketEncryption: {
        serverSideEncryptionConfiguration: [
          {
            serverSideEncryptionByDefault: {
              sseAlgorithm: 'AES256',
            },
          },
        ],
      },
      publicAccessBlockConfiguration: {
        blockPublicAcls: true,
        blockPublicPolicy: true,
        ignorePublicAcls: true,
        restrictPublicBuckets: true,
      },
      objectLockEnabled: false,
    });
    replicaBucket.cfnOptions.metadata = {
      Comment: 'This bucket is used as a target for replicas from the main source bucket',
      guard: {
        SuppressedRules: [
          'S3_BUCKET_DEFAULT_LOCK_ENABLED',
          'S3_BUCKET_REPLICATION_ENABLED',
          'S3_BUCKET_LOGGING_ENABLED',
        ],
      },
      checkov: {
        skip: [
          {
            id: 'CKV_AWS_18',
            comment: 'This is the replica bucket',
          },
        ],
      },
    };

    const replicationRole = new iam.CfnRole(this, 'ReplicationRole', {
      assumeRolePolicyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                's3.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
    });
    replicationRole.cfnOptions.metadata = {
      Comment: 'An IAM role that is used for replication objects from one bucket to another',
    };

    const myBucket = new s3.CfnBucket(this, 'MyBucket', {
      bucketName: `${props.resourceNamePrefix!}-source-${this.region}-${this.account}`,
      versioningConfiguration: {
        status: 'Enabled',
      },
      loggingConfiguration: {
        destinationBucketName: logBucket.ref,
      },
      bucketEncryption: {
        serverSideEncryptionConfiguration: [
          {
            serverSideEncryptionByDefault: {
              sseAlgorithm: 'AES256',
            },
          },
        ],
      },
      publicAccessBlockConfiguration: {
        blockPublicAcls: true,
        blockPublicPolicy: true,
        ignorePublicAcls: true,
        restrictPublicBuckets: true,
      },
      objectLockEnabled: false,
      replicationConfiguration: {
        role: replicationRole.attrArn,
        rules: [
          {
            destination: {
              bucket: replicaBucket.attrArn,
            },
            status: 'Enabled',
          },
        ],
      },
    });
    myBucket.cfnOptions.metadata = {
      Comment: 'A secure bucket that passes security scanning checks',
      guard: {
        SuppressedRules: [
          'S3_BUCKET_DEFAULT_LOCK_ENABLED',
        ],
      },
    };

    const replicationPolicy = new iam.CfnPolicy(this, 'ReplicationPolicy', {
      policyName: 'bucket-replication-policy',
      roles: [
        replicationRole.ref,
      ],
      policyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Effect: 'Allow',
            Action: [
              's3:GetReplicationConfiguration',
              's3:ListBucket',
            ],
            Resource: `arn:aws:s3:::${props.resourceNamePrefix!}-source-${this.region}-${this.account}`,
          },
          {
            Effect: 'Allow',
            Action: [
              's3:GetObjectVersionForReplication',
              's3:GetObjectVersionAcl',
              's3:GetObjectVersionTagging',
            ],
            Resource: `arn:aws:s3:::${props.resourceNamePrefix!}-source-${this.region}-${this.account}/*`,
          },
          {
            Effect: 'Allow',
            Action: [
              's3:ReplicateObject',
              's3:ReplicateDelete',
              's3:ReplicationTags',
            ],
            Resource: `arn:aws:s3:::${props.resourceNamePrefix!}-replicas-${this.region}-${this.account}/*`,
          },
        ],
      },
    });
    replicationPolicy.cfnOptions.metadata = {
      Comment: 'An IAM policy to be used for bucket replication',
    };
  }
}
