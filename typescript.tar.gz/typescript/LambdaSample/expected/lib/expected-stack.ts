import * as cdk from 'aws-cdk-lib';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as sns from 'aws-cdk-lib/aws-sns';

export interface ExpectedStackProps extends cdk.StackProps {
  /**
   * Name of an environment. 'dev', 'staging', 'prod' and any name.
   */
  readonly envName: string;
  /**
   * Path of a Lambda Handler.
   */
  readonly lambdaHandlerPath: string;
}

/**
 * Template for Lambda Sample.
 */
export class ExpectedStack extends cdk.Stack {
  /**
   * Role for Lambda execution.
   */
  public readonly lambdaRoleArn;
  public readonly lambdaFunctionName;
  /**
   * Lambda function ARN.
   */
  public readonly lambdaFunctionArn;
  /**
   * ARN of the CloudWatch Alarm.
   */
  public readonly cloudWatchAlarmArn;
  /**
   * ARN of the SNS Topic.
   */
  public readonly snsTopicArn;

  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps) {
    super(scope, id, props);

    // Resources
    const lambdaRole = new iam.CfnRole(this, 'LambdaRole', {
      roleName: 'lambda-role',
      assumeRolePolicyDocument: {
        Statement: [
          {
            Action: [
              'sts:AssumeRole',
            ],
            Effect: 'Allow',
            Principal: {
              Service: [
                'lambda.amazonaws.com',
              ],
            },
          },
        ],
        Version: '2012-10-17',
      },
      managedPolicyArns: [
        'arn:aws:iam::aws:policy/AWSLambdaExecute',
        'arn:aws:iam::aws:policy/AmazonS3FullAccess',
        'arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess',
        'arn:aws:iam::aws:policy/AmazonKinesisFullAccess',
      ],
      path: '/',
    });

    const snsTopic = new sns.CfnTopic(this, 'SNSTopic', {
      topicName: `lambda-function-sns-topic-${props.envName!}`,
    });

    const lambdaFunction = new lambda.CfnFunction(this, 'LambdaFunction', {
      functionName: `lambda-function-${props.envName!}`,
      description: 'LambdaFunction using python3.12.',
      runtime: 'python3.12',
      code: {
        zipFile: 'import json\n\ndef lambda_handler(event, context):\n    print(json.dumps(event))\n    return {\n        \'statusCode\': 200,\n        \'body\': json.dumps(\'Hello from Lambda!\')\n    }\n',
      },
      handler: `${props.lambdaHandlerPath!}`,
      memorySize: 128,
      timeout: 10,
      role: lambdaRole.attrArn,
      environment: {
        variables: {
          ENV: props.envName!,
          TZ: 'UTC',
        },
      },
    });
    lambdaFunction.cfnOptions.metadata = {
      guard: {
        SuppressedRules: [
          'LAMBDA_INSIDE_VPC',
          'LAMBDA_FUNCTION_PUBLIC_ACCESS_PROHIBITED',
        ],
      },
    };

    const cloudWatchAlarm = new cloudwatch.CfnAlarm(this, 'CloudWatchAlarm', {
      alarmName: `lambda-function-alarm-${props.envName!}`,
      alarmDescription: 'Alarm when Lambda function errors occur',
      namespace: 'AWS/Lambda',
      metricName: 'Errors',
      dimensions: [
        {
          name: 'FunctionName',
          value: lambdaFunction.ref,
        },
      ],
      statistic: 'Sum',
      period: 300,
      evaluationPeriods: 1,
      threshold: 1,
      comparisonOperator: 'GreaterThanOrEqualToThreshold',
      alarmActions: [
        snsTopic.ref,
      ],
    });

    // Outputs
    this.lambdaRoleArn = lambdaRole.attrArn;
    new cdk.CfnOutput(this, 'CfnOutputLambdaRoleARN', {
      key: 'LambdaRoleARN',
      description: 'Role for Lambda execution.',
      exportName: 'LambdaRole',
      value: this.lambdaRoleArn!.toString(),
    });
    this.lambdaFunctionName = lambdaFunction.ref;
    new cdk.CfnOutput(this, 'CfnOutputLambdaFunctionName', {
      key: 'LambdaFunctionName',
      value: this.lambdaFunctionName!.toString(),
    });
    this.lambdaFunctionArn = lambdaFunction.attrArn;
    new cdk.CfnOutput(this, 'CfnOutputLambdaFunctionARN', {
      key: 'LambdaFunctionARN',
      description: 'Lambda function ARN.',
      exportName: `LambdaARN-${props.envName!}`,
      value: this.lambdaFunctionArn!.toString(),
    });
    this.cloudWatchAlarmArn = cloudWatchAlarm.attrArn;
    new cdk.CfnOutput(this, 'CfnOutputCloudWatchAlarmARN', {
      key: 'CloudWatchAlarmARN',
      description: 'ARN of the CloudWatch Alarm.',
      value: this.cloudWatchAlarmArn!.toString(),
    });
    this.snsTopicArn = snsTopic.ref;
    new cdk.CfnOutput(this, 'CfnOutputSNSTopicARN', {
      key: 'SNSTopicARN',
      description: 'ARN of the SNS Topic.',
      value: this.snsTopicArn!.toString(),
    });
  }
}
