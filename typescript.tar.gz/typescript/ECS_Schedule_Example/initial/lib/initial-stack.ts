import * as cdk from 'aws-cdk-lib';
import * as applicationautoscaling from 'aws-cdk-lib/aws-applicationautoscaling';
import * as autoscaling from 'aws-cdk-lib/aws-autoscaling';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as elasticloadbalancingv2 from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as events from 'aws-cdk-lib/aws-events';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as logs from 'aws-cdk-lib/aws-logs';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * Name of an existing EC2 KeyPair to enable SSH access to the ECS instances.
   */
  readonly keyName: string;
  /**
   * Select a VPC that allows instances to access the Internet.
   */
  readonly vpcId: string;
  /**
   * Select at two subnets in your selected VPC.
   */
  readonly subnetId: string[];
  /**
   * Number of instances to launch in your ECS cluster.
   * @default 1
   */
  readonly desiredCapacity?: string;
  /**
   * Maximum number of instances that can be launched in your ECS cluster.
   * @default 1
   */
  readonly maxSize?: string;
  /**
   * Maximum number of Tasks that you want to the Scheduler to run
   * @default 1
   */
  readonly schedulerTasksCount?: string;
  /**
   * Choose to use a cron expression or a rate expression you want to use.
   * @default 'cron'
   */
  readonly cronOrRate?: string;
  /**
   * This defines the Schedule at which to run the. Cron Expressions - http://docs.aws.amazon.com/AmazonCloudWatch/latest/events/ScheduledEvents.html#CronExpressions
   * @default 'cron(00 11 ? * * *)'
   */
  readonly cronSchedule?: string;
  /**
   * This defines the Schedule at which to run the. Rate Expressions - http://docs.aws.amazon.com/AmazonCloudWatch/latest/events/ScheduledEvents.html#RateExpressions
   * @default 'rate(1 day)'
   */
  readonly rateSchedule?: string;
  /**
   * EC2 instance type
   * @default 't2.micro'
   */
  readonly instanceType?: string;
  /**
   * @default '/aws/service/ecs/optimized-ami/amazon-linux-2023/recommended/image_id'
   */
  readonly latestAmiId?: string;
}

/**
 * Amazon ECS Time and Event-Based Task Scheduling with CloudFormation. This will let you run tasks on a regular, scheduled basis and in response to CloudWatch Events. It easier to launch and stop container services that you need to run only at certain times. For example a backup/cleanup task.
 */
export class InitialStack extends cdk.Stack {
  public readonly ecsService;
  public readonly ecsCluster;
  public readonly ecsTaskDef;
  /**
   * Your ALB DNS URL
   */
  public readonly ecsalb;

  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      keyName: new cdk.CfnParameter(this, 'KeyName', {
        type: 'AWS::EC2::KeyPair::KeyName',
        default: props.keyName.toString(),
        description: 'Name of an existing EC2 KeyPair to enable SSH access to the ECS instances.',
      }).valueAsString,
      vpcId: new cdk.CfnParameter(this, 'VpcId', {
        type: 'AWS::EC2::VPC::Id',
        default: props.vpcId.toString(),
        description: 'Select a VPC that allows instances to access the Internet.',
      }).valueAsString,
      subnetId: new cdk.CfnParameter(this, 'SubnetId', {
        type: 'List<AWS::EC2::Subnet::Id>',
        default: props.subnetId.join(','),
        description: 'Select at two subnets in your selected VPC.',
      }).valueAsList,
      desiredCapacity: props.desiredCapacity ?? 1,
      maxSize: props.maxSize ?? 1,
      schedulerTasksCount: props.schedulerTasksCount ?? 1,
      cronOrRate: props.cronOrRate ?? 'cron',
      cronSchedule: props.cronSchedule ?? 'cron(00 11 ? * * *)',
      rateSchedule: props.rateSchedule ?? 'rate(1 day)',
      instanceType: props.instanceType ?? 't2.micro',
      latestAmiId: new cdk.CfnParameter(this, 'LatestAmiId', {
        type: 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default: props.latestAmiId?.toString() ?? '/aws/service/ecs/optimized-ami/amazon-linux-2023/recommended/image_id',
      }).valueAsString,
    };

    // Conditions
    const cronRate = props.cronOrRate! === 'cron';

    // Resources
    const autoscalingRole = new iam.CfnRole(this, 'AutoscalingRole', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'application-autoscaling.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
      policies: [
        {
          policyName: 'service-autoscaling',
          policyDocument: {
            Statement: [
              {
                Effect: 'Allow',
                Action: [
                  'application-autoscaling:*',
                  'cloudwatch:DescribeAlarms',
                  'cloudwatch:PutMetricAlarm',
                  'ecs:DescribeServices',
                  'ecs:UpdateService',
                ],
                Resource: '*',
              },
            ],
          },
        },
      ],
    });

    const ec2Role = new iam.CfnRole(this, 'EC2Role', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'ec2.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
      policies: [
        {
          policyName: 'ecs-service',
          policyDocument: {
            Statement: [
              {
                Effect: 'Allow',
                Action: [
                  'ecs:CreateCluster',
                  'ecs:DeregisterContainerInstance',
                  'ecs:DiscoverPollEndpoint',
                  'ecs:Poll',
                  'ecs:RegisterContainerInstance',
                  'ecs:StartTelemetrySession',
                  'ecs:Submit*',
                  'logs:CreateLogStream',
                  'logs:PutLogEvents',
                ],
                Resource: '*',
              },
            ],
          },
        },
      ],
    });

    const ecsCluster = new ecs.CfnCluster(this, 'ECSCluster', {
    });

    const ecsEventRole = new iam.CfnRole(this, 'ECSEventRole', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'events.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
      policies: [
        {
          policyName: 'ecs-service',
          policyDocument: {
            Statement: [
              {
                Effect: 'Allow',
                Action: [
                  'ecs:RunTask',
                ],
                Resource: '*',
              },
            ],
          },
        },
      ],
    });

    const ecsServiceRole = new iam.CfnRole(this, 'ECSServiceRole', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'ecs.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
      policies: [
        {
          policyName: 'ecs-service',
          policyDocument: {
            Statement: [
              {
                Effect: 'Allow',
                Action: [
                  'elasticloadbalancing:DeregisterInstancesFromLoadBalancer',
                  'elasticloadbalancing:DeregisterTargets',
                  'elasticloadbalancing:Describe*',
                  'elasticloadbalancing:RegisterInstancesWithLoadBalancer',
                  'elasticloadbalancing:RegisterTargets',
                  'ec2:Describe*',
                  'ec2:AuthorizeSecurityGroupIngress',
                ],
                Resource: '*',
              },
            ],
          },
        },
      ],
    });

    const ecsSecurityGroup = new ec2.CfnSecurityGroup(this, 'EcsSecurityGroup', {
      groupDescription: 'ECS Security Group',
      vpcId: props.vpcId!,
    });

    const logsKmsKey = new kms.CfnKey(this, 'LogsKmsKey', {
      description: 'ECS Logs Encryption Key',
      enableKeyRotation: true,
    });

    const cloudwatchLogsGroup = new logs.CfnLogGroup(this, 'CloudwatchLogsGroup', {
      logGroupName: [
        'ECSLogGroup',
        this.stackName,
      ].join('-'),
      retentionInDays: 14,
      kmsKeyId: logsKmsKey.ref,
    });

    const ec2InstanceProfile = new iam.CfnInstanceProfile(this, 'EC2InstanceProfile', {
      path: '/',
      roles: [
        ec2Role.ref,
      ],
    });

    const ecsalb = new elasticloadbalancingv2.CfnLoadBalancer(this, 'ECSALB', {
      name: 'ECSALB',
      scheme: 'internet-facing',
      loadBalancerAttributes: [
        {
          key: 'idle_timeout.timeout_seconds',
          value: '30',
        },
      ],
      subnets: props.subnetId!,
      securityGroups: [
        ecsSecurityGroup.ref,
      ],
    });

    const ecsSecurityGroupAlBports = new ec2.CfnSecurityGroupIngress(this, 'EcsSecurityGroupALBports', {
      groupId: ecsSecurityGroup.ref,
      ipProtocol: 'tcp',
      fromPort: 31000,
      toPort: 61000,
      sourceSecurityGroupId: ecsSecurityGroup.ref,
    });

    const ecsSecurityGroupHttPinbound = new ec2.CfnSecurityGroupIngress(this, 'EcsSecurityGroupHTTPinbound', {
      groupId: ecsSecurityGroup.ref,
      ipProtocol: 'tcp',
      fromPort: 80,
      toPort: 80,
      cidrIp: '0.0.0.0/0',
    });

    const ecsSecurityGroupSsHinbound = new ec2.CfnSecurityGroupIngress(this, 'EcsSecurityGroupSSHinbound', {
      groupId: ecsSecurityGroup.ref,
      ipProtocol: 'tcp',
      fromPort: 22,
      toPort: 22,
      cidrIp: '192.168.1.0/0',
    });

    const containerInstances = new autoscaling.CfnLaunchConfiguration(this, 'ContainerInstances', {
      imageId: props.latestAmiId!,
      securityGroups: [
        ecsSecurityGroup.ref,
      ],
      instanceType: props.instanceType!,
      iamInstanceProfile: ec2InstanceProfile.ref,
      keyName: props.keyName!,
      userData: cdk.Fn.base64(`#!/bin/bash -xe
      echo ECS_CLUSTER=${ecsCluster.ref} >> /etc/ecs/ecs.config
      yum install -y aws-cfn-bootstrap
      /opt/aws/bin/cfn-signal -e $? --stack ${this.stackName} \
          --resource ECSAutoScalingGroup \
          --region ${this.region}
      `),
    });

    const ecstg = new elasticloadbalancingv2.CfnTargetGroup(this, 'ECSTG', {
      healthCheckIntervalSeconds: 10,
      healthCheckPath: '/',
      healthCheckProtocol: 'HTTP',
      healthCheckTimeoutSeconds: 5,
      healthyThresholdCount: 2,
      name: 'ECSTG',
      port: 80,
      protocol: 'HTTP',
      unhealthyThresholdCount: 2,
      vpcId: props.vpcId!,
    });
    ecstg.addDependency(ecsalb);

    const taskDefinition = new ecs.CfnTaskDefinition(this, 'TaskDefinition', {
      family: [
        this.stackName,
        '-ecs-demo-app',
      ].join(''),
      containerDefinitions: [
        {
          name: 'simple-app',
          cpu: 10,
          essential: true,
          image: 'httpd:2.4',
          memory: 300,
          logConfiguration: {
            logDriver: 'awslogs',
            options: {
              'awslogs-group': cloudwatchLogsGroup.ref,
              'awslogs-region': this.region,
              'awslogs-stream-prefix': 'ecs-demo-app',
            },
          },
          mountPoints: [
            {
              containerPath: '/usr/local/apache2/htdocs',
              sourceVolume: 'my-vol',
            },
          ],
          portMappings: [
            {
              containerPort: 80,
            },
          ],
        },
        {
          name: 'busybox',
          cpu: 10,
          command: [
            '/bin/sh -c \"while true; do echo \'<html> <head> <title>Amazon ECS Sample App</title> <style>body {margin-top: 40px; background-color: #333;} </style> </head><body> <div style=color:white;text-align:center> <h1>Amazon ECS Sample App</h1> <h2>Congratulations!</h2> <p>Your application is now running on a container in Amazon ECS.</p>\' > top; /bin/date > date ; echo \'</div></body></html>\' > bottom; cat top date bottom > /usr/local/apache2/htdocs/index.html ; sleep 1; done\"',
          ],
          entryPoint: [
            'sh',
            '-c',
          ],
          essential: false,
          image: 'busybox',
          memory: 200,
          logConfiguration: {
            logDriver: 'awslogs',
            options: {
              'awslogs-group': cloudwatchLogsGroup.ref,
              'awslogs-region': this.region,
              'awslogs-stream-prefix': 'ecs-demo-app',
            },
          },
          volumesFrom: [
            {
              sourceContainer: 'simple-app',
            },
          ],
        },
      ],
      volumes: [
        {
          name: 'my-vol',
        },
      ],
    });

    const albListener = new elasticloadbalancingv2.CfnListener(this, 'ALBListener', {
      defaultActions: [
        {
          type: 'forward',
          targetGroupArn: ecstg.ref,
        },
      ],
      loadBalancerArn: ecsalb.ref,
      port: 80,
      protocol: 'HTTP',
    });
    albListener.addDependency(ecsServiceRole);

    const ecsAutoScalingGroup = new autoscaling.CfnAutoScalingGroup(this, 'ECSAutoScalingGroup', {
      vpcZoneIdentifier: props.subnetId!,
      launchConfigurationName: containerInstances.ref,
      minSize: '1',
      maxSize: props.maxSize!,
      desiredCapacity: props.desiredCapacity!,
    });
    ecsAutoScalingGroup.cfnOptions.updatePolicy = {
      AutoScalingReplacingUpdate: {
        WillReplace: true,
      },
    };
    const ecsScheduledTask = new events.CfnRule(this, 'ECSScheduledTask', {
      description: 'Creating a Schedule with CloudFormation as an example',
      scheduleExpression: cronRate ? props.cronSchedule! : props.rateSchedule!,
      state: 'ENABLED',
      targets: [
        {
          arn: ecsCluster.attrArn,
          id: 'Target1',
          roleArn: ecsEventRole.attrArn,
          ecsParameters: {
            taskCount: props.schedulerTasksCount!,
            taskDefinitionArn: taskDefinition.ref,
          },
        },
      ],
    });
    ecsScheduledTask.addDependency(ecsEventRole);

    const ecsalbListenerRule = new elasticloadbalancingv2.CfnListenerRule(this, 'ECSALBListenerRule', {
      actions: [
        {
          type: 'forward',
          targetGroupArn: ecstg.ref,
        },
      ],
      conditions: [
        {
          field: 'path-pattern',
          values: [
            '/',
          ],
        },
      ],
      listenerArn: albListener.ref,
      priority: 1,
    });
    ecsalbListenerRule.addDependency(albListener);

    const service = new ecs.CfnService(this, 'Service', {
      cluster: ecsCluster.ref,
      desiredCount: 1,
      loadBalancers: [
        {
          containerName: 'simple-app',
          containerPort: 80,
          targetGroupArn: ecstg.ref,
        },
      ],
      role: ecsServiceRole.ref,
      taskDefinition: taskDefinition.ref,
    });
    service.addDependency(albListener);

    const serviceScalingTarget = new applicationautoscaling.CfnScalableTarget(this, 'ServiceScalingTarget', {
      maxCapacity: 2,
      minCapacity: 1,
      resourceId: [
        'service/',
        ecsCluster.ref,
        '/',
        service.attrName,
      ].join(''),
      roleArn: autoscalingRole.attrArn,
      scalableDimension: 'ecs:service:DesiredCount',
      serviceNamespace: 'ecs',
    });
    serviceScalingTarget.addDependency(service);

    const serviceScalingPolicy = new applicationautoscaling.CfnScalingPolicy(this, 'ServiceScalingPolicy', {
      policyName: 'AStepPolicy',
      policyType: 'StepScaling',
      scalingTargetId: serviceScalingTarget.ref,
      stepScalingPolicyConfiguration: {
        adjustmentType: 'PercentChangeInCapacity',
        cooldown: 60,
        metricAggregationType: 'Average',
        stepAdjustments: [
          {
            metricIntervalLowerBound: 0,
            scalingAdjustment: 200,
          },
        ],
      },
    });

    const alb500sAlarmScaleUp = new cloudwatch.CfnAlarm(this, 'ALB500sAlarmScaleUp', {
      evaluationPeriods: 1,
      statistic: 'Average',
      threshold: 10,
      alarmDescription: 'Alarm if our ALB generates too many HTTP 500s.',
      period: 60,
      alarmActions: [
        serviceScalingPolicy.ref,
      ],
      namespace: 'AWS/ApplicationELB',
      dimensions: [
        {
          name: 'ECSService',
          value: service.ref,
        },
      ],
      comparisonOperator: 'GreaterThanThreshold',
      metricName: 'HTTPCode_ELB_5XX_Count',
    });

    // Outputs
    this.ecsService = service.ref;
    new cdk.CfnOutput(this, 'CfnOutputEcsService', {
      key: 'EcsService',
      value: this.ecsService!.toString(),
    });
    this.ecsCluster = ecsCluster.ref;
    new cdk.CfnOutput(this, 'CfnOutputEcsCluster', {
      key: 'EcsCluster',
      value: this.ecsCluster!.toString(),
    });
    this.ecsTaskDef = taskDefinition.ref;
    new cdk.CfnOutput(this, 'CfnOutputEcsTaskDef', {
      key: 'EcsTaskDef',
      value: this.ecsTaskDef!.toString(),
    });
    this.ecsalb = [
      ecsalb.attrDnsName,
    ].join('');
    new cdk.CfnOutput(this, 'CfnOutputECSALB', {
      key: 'ECSALB',
      description: 'Your ALB DNS URL',
      value: this.ecsalb!.toString(),
    });
  }
}
