import * as cdk from 'aws-cdk-lib';
import * as emr from 'aws-cdk-lib/aws-emr';
import * as iam from 'aws-cdk-lib/aws-iam';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * Name of the cluster
   * @default 'emrcluster'
   */
  readonly emrClusterName?: string;
  /**
   * Must be an existing Keyname
   */
  readonly keyName: string;
  /**
   * Instance type to be used for the master instance.
   * @default 'm3.xlarge'
   */
  readonly masterInstanceType?: string;
  /**
   * Instance type to be used for core instances.
   * @default 'm3.xlarge'
   */
  readonly coreInstanceType?: string;
  /**
   * Must be a valid number
   * @default 2
   */
  readonly numberOfCoreInstances?: string;
  /**
   * Must be Valid public subnet ID
   * @default 'subnet-dba430ad'
   */
  readonly subnetId?: string;
  /**
   * Must be a valid S3 URL
   * @default 's3://emrclusterlogbucket/'
   */
  readonly logUri?: string;
  /**
   * Must be a valid S3 bucket URL 
   * @default 's3://emrclusterdatabucket/'
   */
  readonly s3DataUri?: string;
  /**
   * Must be a valid EMR release  version
   * @default 'emr-5.7.0'
   */
  readonly releaseLabel?: string;
  /**
   * Please select which application will be installed on the cluster this would be either Ganglia and spark, or Ganglia and s3 acked Hbase
   */
  readonly applications: string;
}

/**
 * Best Practice EMR Cluster for Spark or S3 backed Hbase
 */
export class InitialStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      emrClusterName: props.emrClusterName ?? 'emrcluster',
      masterInstanceType: props.masterInstanceType ?? 'm3.xlarge',
      coreInstanceType: props.coreInstanceType ?? 'm3.xlarge',
      numberOfCoreInstances: props.numberOfCoreInstances ?? 2,
      subnetId: props.subnetId ?? 'subnet-dba430ad',
      logUri: props.logUri ?? 's3://emrclusterlogbucket/',
      s3DataUri: props.s3DataUri ?? 's3://emrclusterdatabucket/',
      releaseLabel: props.releaseLabel ?? 'emr-5.7.0',
    };

    // Conditions
    const hbase = props.applications! === 'Hbase';
    const spark = props.applications! === 'Spark';

    // Resources
    const emrClusterServiceRole = new iam.CfnRole(this, 'EMRClusterServiceRole', {
      assumeRolePolicyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'elasticmapreduce.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      managedPolicyArns: [
        'arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceRole',
      ],
      path: '/',
    });

    const emrClusterinstanceProfileRole = new iam.CfnRole(this, 'EMRClusterinstanceProfileRole', {
      assumeRolePolicyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'ec2.amazonaws.com',
              ],
            },
            Action: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      managedPolicyArns: [
        'arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceforEC2Role',
      ],
      path: '/',
    });

    const emrClusterinstanceProfile = new iam.CfnInstanceProfile(this, 'EMRClusterinstanceProfile', {
      path: '/',
      roles: [
        emrClusterinstanceProfileRole.ref,
      ],
    });

    const emrCluster = new emr.CfnCluster(this, 'EMRCluster', {
      applications: [
        {
          name: 'Ganglia',
        },
        spark ? {
          name: 'Spark',
        } : undefined,
        hbase ? {
          name: 'Hbase',
        } : undefined,
      ],
      configurations: [
        {
          classification: 'hbase-site',
          configurationProperties: {
            'hbase.rootdir': props.s3DataUri!,
          },
        },
        {
          classification: 'hbase',
          configurationProperties: {
            'hbase.emr.storageMode': 's3',
          },
        },
      ],
      instances: {
        ec2KeyName: props.keyName!,
        ec2SubnetId: props.subnetId!,
        masterInstanceGroup: {
          instanceCount: 1,
          instanceType: props.masterInstanceType!,
          market: 'ON_DEMAND',
          name: 'Master',
        },
        coreInstanceGroup: {
          instanceCount: props.numberOfCoreInstances!,
          instanceType: props.coreInstanceType!,
          market: 'ON_DEMAND',
          name: 'Core',
        },
        terminationProtected: false,
      },
      visibleToAllUsers: true,
      jobFlowRole: emrClusterinstanceProfile.ref,
      releaseLabel: props.releaseLabel!,
      logUri: props.logUri!,
      name: props.emrClusterName!,
      autoScalingRole: 'EMR_AutoScaling_DefaultRole',
      serviceRole: emrClusterServiceRole.ref,
    });
    emrCluster.addDependency(emrClusterServiceRole);
    emrCluster.addDependency(emrClusterinstanceProfileRole);
    emrCluster.addDependency(emrClusterinstanceProfile);
  }
}
