import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

export interface ExpectedStackProps extends cdk.StackProps {
}

/**
 * This stack automates the creation of EC2 DHCP options

 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps = {}) {
    super(scope, id, props);

    // Conditions
    const isUsEast1 = this.region === 'us-east-1';

    // Resources
    const iamRole = new ec2.CfnDHCPOptions(this, 'IamRole', {
      domainName: isUsEast1 ? 'ec2.internal' : `${this.region}.compute.internal`,
      domainNameServers: [
        'AmazonProvidedDNS',
      ],
      netbiosNodeType: 2,
      ntpServers: [
        '0.amazon.pool.ntp.org',
        '1.amazon.pool.ntp.org',
      ],
    });
  }
}
