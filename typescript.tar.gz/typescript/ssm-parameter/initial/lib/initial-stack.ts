import * as cdk from 'aws-cdk-lib';
import * as ssm from 'aws-cdk-lib/aws-ssm';

export interface InitialStackProps extends cdk.StackProps {
}

/**
 * This stack creates SSM parameters of string
 * and a list of strings

 */
export class InitialStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: InitialStackProps = {}) {
    super(scope, id, props);

    // Resources
    const parameterList = new ssm.CfnParameter(this, 'ParameterList', {
      name: 'KeyList',
      description: 'SSM Parameter for storing a list of strings',
      type: 'StringList',
      value: 'Value1,Value2',
      tier: 'Standard',
    });

    const parameterString = new ssm.CfnParameter(this, 'ParameterString', {
      name: 'Key',
      description: 'SSM Parameter for storing a string',
      type: 'String',
      value: 'Value',
      tier: 'Standard',
    });
  }
}
