import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

export interface InitialStackProps extends cdk.StackProps {
  /**
   * Name of an existing EC2 KeyPair to enable SSH access to the instance
   */
  readonly keyName: string;
  /**
   * WebServer EC2 instance type
   * @default 't3.micro'
   */
  readonly instanceType?: string;
  /**
   * VpcId of your existing Virtual Private Cloud (VPC)
   */
  readonly vpcId: string;
  /**
   * SubnetId of an existing subnet (for the primary network) in your Virtual Private Cloud (VPC)
   */
  readonly subnetId: string;
  /**
   * Primary private IP. This must be a valid IP address for Subnet
   */
  readonly primaryIpAddress: string;
  /**
   * Secondary private IP. This ust be a valid IP address for Subnet
   */
  readonly secondaryIpAddress: string;
  /**
   * The IP address range that can be used to SSH to the EC2 instances
   * @default '0.0.0.0/0'
   */
  readonly sshLocation?: string;
  /**
   * @default '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2'
   */
  readonly latestAmi?: string;
}

/**
 * Sample template showing how to create an instance with a single network
 * interface and multiple static IP addresses in an existing VPC. It assumes you
 * have already created a VPC.  **WARNING** This template creates an Amazon EC2
 * instance. You will be billed for the AWS resources used if you create a stack
 * from this template.

 */
export class InitialStack extends cdk.Stack {
  /**
   * Instance Id of newly created instance
   */
  public readonly instanceId;
  /**
   * Primary public IP of Eth0
   */
  public readonly eip1;
  /**
   * Primary private IP address of Eth0
   */
  public readonly primaryPrivateIpAddress;
  /**
   * Secondary private IP address of Eth0
   */
  public readonly secondaryPrivateIpAddresses;

  public constructor(scope: cdk.App, id: string, props: InitialStackProps) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      keyName: new cdk.CfnParameter(this, 'KeyName', {
        type: 'AWS::EC2::KeyPair::KeyName',
        default: props.keyName.toString(),
        description: 'Name of an existing EC2 KeyPair to enable SSH access to the instance',
      }).valueAsString,
      instanceType: props.instanceType ?? 't3.micro',
      vpcId: new cdk.CfnParameter(this, 'VpcId', {
        type: 'AWS::EC2::VPC::Id',
        default: props.vpcId.toString(),
        description: 'VpcId of your existing Virtual Private Cloud (VPC)',
      }).valueAsString,
      subnetId: new cdk.CfnParameter(this, 'SubnetId', {
        type: 'AWS::EC2::Subnet::Id',
        default: props.subnetId.toString(),
        description: 'SubnetId of an existing subnet (for the primary network) in your Virtual Private Cloud (VPC)',
      }).valueAsString,
      sshLocation: props.sshLocation ?? '0.0.0.0/0',
      latestAmi: new cdk.CfnParameter(this, 'LatestAmi', {
        type: 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default: props.latestAmi?.toString() ?? '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2',
      }).valueAsString,
    };

    // Resources
    const eip1 = new ec2.CfnEIP(this, 'EIP1', {
      domain: 'vpc',
    });

    const sshSecurityGroup = new ec2.CfnSecurityGroup(this, 'SSHSecurityGroup', {
      vpcId: props.vpcId!,
      groupDescription: 'Enable SSH access via port 22',
      securityGroupIngress: [
        {
          ipProtocol: 'tcp',
          fromPort: 22,
          toPort: 22,
          cidrIp: props.sshLocation!,
        },
      ],
    });

    const eth0 = new ec2.CfnNetworkInterface(this, 'Eth0', {
      description: 'eth0',
      groupSet: [
        sshSecurityGroup.ref,
      ],
      privateIpAddresses: [
        {
          privateIpAddress: props.primaryIpAddress!,
          primary: true,
        },
        {
          privateIpAddress: props.secondaryIpAddress!,
          primary: false,
        },
      ],
      sourceDestCheck: true,
      subnetId: props.subnetId!,
      tags: [
        {
          key: 'Name',
          value: 'Interface 0',
        },
        {
          key: 'Interface',
          value: 'eth0',
        },
      ],
    });

    const ec2Instance = new ec2.CfnInstance(this, 'EC2Instance', {
      imageId: props.latestAmi!,
      instanceType: props.instanceType!,
      keyName: props.keyName!,
      networkInterfaces: [
        {
          networkInterfaceId: eth0.ref,
          deviceIndex: '0',
        },
      ],
      tags: [
        {
          key: 'Name',
          value: 'myInstance',
        },
      ],
    });
    ec2Instance.cfnOptions.metadata = {
      guard: {
        SuppressedRules: [
          'EC2_INSTANCES_IN_VPC',
        ],
      },
    };

    const eipAssoc1 = new ec2.CfnEIPAssociation(this, 'EIPAssoc1', {
      networkInterfaceId: eth0.ref,
      allocationId: eip1.attrAllocationId,
    });

    // Outputs
    this.instanceId = ec2Instance.ref;
    new cdk.CfnOutput(this, 'CfnOutputInstanceId', {
      key: 'InstanceId',
      description: 'Instance Id of newly created instance',
      value: this.instanceId!.toString(),
    });
    this.eip1 = [
      'IP address',
      eip1.ref,
      'on subnet',
      props.subnetId!,
    ].join(' ');
    new cdk.CfnOutput(this, 'CfnOutputEIP1', {
      key: 'EIP1',
      description: 'Primary public IP of Eth0',
      value: this.eip1!.toString(),
    });
    this.primaryPrivateIpAddress = [
      'IP address',
      eth0.attrPrimaryPrivateIpAddress,
      'on subnet',
      props.subnetId!,
    ].join(' ');
    new cdk.CfnOutput(this, 'CfnOutputPrimaryPrivateIPAddress', {
      key: 'PrimaryPrivateIPAddress',
      description: 'Primary private IP address of Eth0',
      value: this.primaryPrivateIpAddress!.toString(),
    });
    this.secondaryPrivateIpAddresses = [
      'IP address',
      cdk.Fn.select(0, eth0.attrSecondaryPrivateIpAddresses),
      'on subnet',
      props.subnetId!,
    ].join(' ');
    new cdk.CfnOutput(this, 'CfnOutputSecondaryPrivateIPAddresses', {
      key: 'SecondaryPrivateIPAddresses',
      description: 'Secondary private IP address of Eth0',
      value: this.secondaryPrivateIpAddresses!.toString(),
    });
  }
}
