import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

export interface ExpectedStackProps extends cdk.StackProps {
  /**
   * Please enter the IP range (CIDR notation) for this VPC
   * @default '10.192.0.0/16'
   */
  readonly vpcCidr?: string;
  /**
   * Please enter the IP range (CIDR notation) for the public subnet in the first Availability Zone
   * @default '10.192.10.0/24'
   */
  readonly publicSubnet1Cidr?: string;
  /**
   * Please enter the IP range (CIDR notation) for the public subnet in the second Availability Zone
   * @default '10.192.11.0/24'
   */
  readonly publicSubnet2Cidr?: string;
  /**
   * Please enter the IP range (CIDR notation) for the private subnet in the first Availability Zone
   * @default '10.192.20.0/24'
   */
  readonly privateSubnet1Cidr?: string;
  /**
   * Please enter the IP range (CIDR notation) for the private subnet in the second Availability Zone
   * @default '10.192.21.0/24'
   */
  readonly privateSubnet2Cidr?: string;
}

/**
 * This template deploys a VPC, with a pair of public and private subnets spread across two Availability Zones. It uses a static AZ Mapping known as RegionMap to ensure that your resources persist in a given Availability Zone if we add or remove zones
 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps = {}) {
    super(scope, id, props);

    // Applying default props
    props = {
      ...props,
      vpcCidr: props.vpcCidr ?? '10.192.0.0/16',
      publicSubnet1Cidr: props.publicSubnet1Cidr ?? '10.192.10.0/24',
      publicSubnet2Cidr: props.publicSubnet2Cidr ?? '10.192.11.0/24',
      privateSubnet1Cidr: props.privateSubnet1Cidr ?? '10.192.20.0/24',
      privateSubnet2Cidr: props.privateSubnet2Cidr ?? '10.192.21.0/24',
    };

    // Mappings
    const regionMap: Record<string, Record<string, readonly string[]>> = {
      'us-east-1': {
        'AZs': ['us-east-1a','us-east-1b','us-east-1c'],
      },
      'us-west-2': {
        'AZs': ['us-west-2a','us-west-2b','us-west-2c'],
      },
    };

    // Resources
    const internetGateway = new ec2.CfnInternetGateway(this, 'InternetGateway', {
    });

    const vpc = new ec2.CfnVPC(this, 'VPC', {
      cidrBlock: props.vpcCidr!,
      enableDnsSupport: true,
      enableDnsHostnames: true,
    });

    const internetGatewayAttachment = new ec2.CfnVPCGatewayAttachment(this, 'InternetGatewayAttachment', {
      internetGatewayId: internetGateway.ref,
      vpcId: vpc.ref,
    });

    const noIngressSecurityGroup = new ec2.CfnSecurityGroup(this, 'NoIngressSecurityGroup', {
      groupName: 'no-ingress-sg',
      groupDescription: 'Security group with no ingress rule',
      vpcId: vpc.ref,
    });

    const privateRouteTable1 = new ec2.CfnRouteTable(this, 'PrivateRouteTable1', {
      vpcId: vpc.ref,
    });

    const privateRouteTable2 = new ec2.CfnRouteTable(this, 'PrivateRouteTable2', {
      vpcId: vpc.ref,
    });

    const privateSubnet1 = new ec2.CfnSubnet(this, 'PrivateSubnet1', {
      vpcId: vpc.ref,
      availabilityZone: cdk.Fn.select(0, regionMap[this.region]['AZs']),
      cidrBlock: props.privateSubnet1Cidr!,
      mapPublicIpOnLaunch: false,
    });

    const privateSubnet2 = new ec2.CfnSubnet(this, 'PrivateSubnet2', {
      vpcId: vpc.ref,
      availabilityZone: cdk.Fn.select(1, regionMap[this.region]['AZs']),
      cidrBlock: props.privateSubnet2Cidr!,
      mapPublicIpOnLaunch: false,
    });

    const publicRouteTable = new ec2.CfnRouteTable(this, 'PublicRouteTable', {
      vpcId: vpc.ref,
    });

    const publicSubnet1 = new ec2.CfnSubnet(this, 'PublicSubnet1', {
      vpcId: vpc.ref,
      availabilityZone: cdk.Fn.select(0, regionMap[this.region]['AZs']),
      cidrBlock: props.publicSubnet1Cidr!,
      mapPublicIpOnLaunch: true,
    });

    const publicSubnet2 = new ec2.CfnSubnet(this, 'PublicSubnet2', {
      vpcId: vpc.ref,
      availabilityZone: cdk.Fn.select(1, regionMap[this.region]['AZs']),
      cidrBlock: props.publicSubnet2Cidr!,
      mapPublicIpOnLaunch: true,
    });

    const bastionHost = new ec2.CfnInstance(this, 'BastionHost', {
      imageId: 'ami-0c55b159cbfafe1f0',
      instanceType: 't2.micro',
      keyName: 'MyKeyPair',
      subnetId: publicSubnet1.ref,
      securityGroupIds: [
        noIngressSecurityGroup.ref,
      ],
      userData: cdk.Fn.base64(`#!/bin/bash
      echo "Hello, World" > index.html
      nohup python3 -m http.server 80 &
      `),
    });

    const defaultPublicRoute = new ec2.CfnRoute(this, 'DefaultPublicRoute', {
      routeTableId: publicRouteTable.ref,
      destinationCidrBlock: '0.0.0.0/0',
      gatewayId: internetGateway.ref,
    });
    defaultPublicRoute.addDependency(internetGatewayAttachment);

    const natGateway1Eip = new ec2.CfnEIP(this, 'NatGateway1EIP', {
      domain: 'vpc',
    });
    natGateway1Eip.addDependency(internetGatewayAttachment);

    const natGateway2Eip = new ec2.CfnEIP(this, 'NatGateway2EIP', {
      domain: 'vpc',
    });
    natGateway2Eip.addDependency(internetGatewayAttachment);

    const privateSubnet1RouteTableAssociation = new ec2.CfnSubnetRouteTableAssociation(this, 'PrivateSubnet1RouteTableAssociation', {
      routeTableId: privateRouteTable1.ref,
      subnetId: privateSubnet1.ref,
    });

    const privateSubnet2RouteTableAssociation = new ec2.CfnSubnetRouteTableAssociation(this, 'PrivateSubnet2RouteTableAssociation', {
      routeTableId: privateRouteTable2.ref,
      subnetId: privateSubnet2.ref,
    });

    const publicSubnet1RouteTableAssociation = new ec2.CfnSubnetRouteTableAssociation(this, 'PublicSubnet1RouteTableAssociation', {
      routeTableId: publicRouteTable.ref,
      subnetId: publicSubnet1.ref,
    });

    const publicSubnet2RouteTableAssociation = new ec2.CfnSubnetRouteTableAssociation(this, 'PublicSubnet2RouteTableAssociation', {
      routeTableId: publicRouteTable.ref,
      subnetId: publicSubnet2.ref,
    });

    const natGateway1 = new ec2.CfnNatGateway(this, 'NatGateway1', {
      allocationId: natGateway1Eip.attrAllocationId,
      subnetId: publicSubnet1.ref,
    });

    const natGateway2 = new ec2.CfnNatGateway(this, 'NatGateway2', {
      allocationId: natGateway2Eip.attrAllocationId,
      subnetId: publicSubnet2.ref,
    });

    const defaultPrivateRoute1 = new ec2.CfnRoute(this, 'DefaultPrivateRoute1', {
      routeTableId: privateRouteTable1.ref,
      destinationCidrBlock: '0.0.0.0/0',
      natGatewayId: natGateway1.ref,
    });

    const defaultPrivateRoute2 = new ec2.CfnRoute(this, 'DefaultPrivateRoute2', {
      routeTableId: privateRouteTable2.ref,
      destinationCidrBlock: '0.0.0.0/0',
      natGatewayId: natGateway2.ref,
    });
  }
}
