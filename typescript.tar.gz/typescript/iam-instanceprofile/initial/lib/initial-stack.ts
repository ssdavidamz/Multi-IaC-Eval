import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';

export interface InitialStackProps extends cdk.StackProps {
}

/**
 * This stack automates the creation of an IAM instance profile

 */
export class InitialStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: InitialStackProps = {}) {
    super(scope, id, props);

    // Resources
    const iamRole = new iam.CfnRole(this, 'IamRole', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'ec2.amazonaws.com',
              ],
            },
            Actions: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
    });

    const iamProfile = new iam.CfnInstanceProfile(this, 'IamProfile', {
      roles: [
        iamRole.ref,
      ],
      path: '/',
    });
  }
}
