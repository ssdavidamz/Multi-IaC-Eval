import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';

export interface ExpectedStackProps extends cdk.StackProps {
}

/**
 * This stack automates the creation of an IAM instance profile with additional S3 access permissions

 */
export class ExpectedStack extends cdk.Stack {
  public constructor(scope: cdk.App, id: string, props: ExpectedStackProps = {}) {
    super(scope, id, props);

    // Resources
    const iamRole = new iam.CfnRole(this, 'IamRole', {
      assumeRolePolicyDocument: {
        Statement: [
          {
            Effect: 'Allow',
            Principal: {
              Service: [
                'ec2.amazonaws.com',
              ],
            },
            Actions: [
              'sts:AssumeRole',
            ],
          },
        ],
      },
      path: '/',
      policies: [
        {
          policyName: 'S3AccessPolicy',
          policyDocument: {
            Statement: [
              {
                Effect: 'Allow',
                Action: [
                  's3:GetObject',
                  's3:PutObject',
                ],
                Resource: 'arn:aws:s3:::my-important-bucket/*',
              },
            ],
          },
        },
      ],
    });

    const iamProfile = new iam.CfnInstanceProfile(this, 'IamProfile', {
      roles: [
        iamRole.ref,
      ],
      path: '/',
    });
  }
}
