from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_events as events
from constructs import Construct

"""
  This stack will create different event bus policies

"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    customEventBus = events.CfnEventBus(self, 'CustomEventBus',
          name = 'OrganizationalEventBus',
        )

    oneAccountEventBusPolicy = events.CfnEventBusPolicy(self, 'OneAccountEventBusPolicy',
          statement_id = 'OneAccountPut',
          statement = {
            'Effect': 'Allow',
            'Principal': {
              'AWS': f"""arn:{self.partition}:iam::{self.account}:root""",
            },
            'Action': 'events:PutEvents',
            'Resource': f"""arn:{self.partition}:events:{self.region}:{self.account}:event-bus/default""",
          },
        )

    organizationEventBusPolicy = events.CfnEventBusPolicy(self, 'OrganizationEventBusPolicy',
          statement_id = 'OrganizationalPut',
          statement = {
            'Effect': 'Allow',
            'Principal': '*',
            'Action': 'events:PutEvents',
            'Resource': f"""arn:{self.partition}:events:{self.region}:{self.account}:event-bus/default""",
            'Condition': {
              'StringEquals': {
                'aws:PrincipalOrgID': props['organizationId'],
              },
            },
          },
        )

    organizationEventBusPolicyCustomBus = events.CfnEventBusPolicy(self, 'OrganizationEventBusPolicyCustomBus',
          event_bus_name = customEventBus.ref,
          statement_id = 'OrganizationalPutCustomBus',
          statement = {
            'Effect': 'Allow',
            'Principal': '*',
            'Action': 'events:PutEvents',
            'Resource': customEventBus.attr_arn,
            'Condition': {
              'StringEquals': {
                'aws:PrincipalOrgID': props['organizationId'],
              },
            },
          },
        )


