from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_cloudwatch as cloudwatch
import aws_cdk.aws_dynamodb as dynamodb
from constructs import Construct

"""
  Create a DynamoDB table using on demand billing and add a CloudWatch alarm to monitor the table's consumed read capacity.

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    customerTable = dynamodb.CfnTable(self, 'CustomerTable',
          billing_mode = 'PAY_PER_REQUEST',
          attribute_definitions = [
            {
              'attributeName': 'pk',
              'attributeType': 'S',
            },
          ],
          key_schema = [
            {
              'attributeName': 'pk',
              'keyType': 'HASH',
            },
          ],
          point_in_time_recovery_specification = {
            'pointInTimeRecoveryEnabled': True,
          },
          sse_specification = {
            'sseEnabled': True,
            'sseType': 'KMS',
          },
        )
    customerTable.cfn_options.metadata = {
      'Comment': 'A simple table that passes security scanner checks',
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_119',
            'comment': 'SSEType KMS stores the key in the customer account',
          },
        ],
      },
      'guard': {
        'SuppressedRules': [
          'DYNAMODB_TABLE_ENCRYPTED_KMS',
        ],
      },
    }

    readCapacityAlarm = cloudwatch.CfnAlarm(self, 'ReadCapacityAlarm',
          alarm_description = 'Alarm when DynamoDB table read capacity is high',
          metric_name = 'ConsumedReadCapacityUnits',
          namespace = 'AWS/DynamoDB',
          dimensions = [
            {
              'name': 'TableName',
              'value': customerTable.ref,
            },
          ],
          statistic = 'Sum',
          period = 300,
          evaluation_periods = 1,
          threshold = 80,
          comparison_operator = 'GreaterThanThreshold',
          alarm_actions = [
            'arn:aws:sns:REGION:ACCOUNT_ID:YOUR_SNS_TOPIC',
          ],
        )


