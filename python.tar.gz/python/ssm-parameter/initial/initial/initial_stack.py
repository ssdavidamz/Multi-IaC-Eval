from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_ssm as ssm
from constructs import Construct

"""
  This stack creates SSM parameters of string
  and a list of strings

"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    parameterList = ssm.CfnParameter(self, 'ParameterList',
          name = 'KeyList',
          description = 'SSM Parameter for storing a list of strings',
          type = 'StringList',
          value = 'Value1,Value2',
          tier = 'Standard',
        )

    parameterString = ssm.CfnParameter(self, 'ParameterString',
          name = 'Key',
          description = 'SSM Parameter for storing a string',
          type = 'String',
          value = 'Value',
          tier = 'Standard',
        )


