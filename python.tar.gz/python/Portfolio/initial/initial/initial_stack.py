from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_servicecatalog as servicecatalog
from constructs import Construct

"""
  CI/CD optimized AWS CloudFormation Sample Template for AWS Service Catalog Portfolio creation. ### Before deployment please make sure that all parameters are reviewed and updated according the specific use case. ### **WARNING** This template creates AWS Service Catalog Portfolio, please make sure you review billing costs for AWS Service Catalog.
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'env': kwargs.get('env', 'dev'),
      'dept': kwargs.get('dept', '1234'),
      'user': kwargs.get('user', 'User'),
      'owner': kwargs.get('owner', 'Owner'),
      'productEnv': kwargs.get('productEnv', 'dev'),
      'productDept': kwargs.get('productDept', '1234'),
      'productUser': kwargs.get('productUser', 'User'),
      'productOwner': kwargs.get('productOwner', 'Owner'),
      'portfolioProviderName': kwargs.get('portfolioProviderName', 'IT Provider'),
      'portfolioDescription': kwargs.get('portfolioDescription', 'Service Catalog Portfolio for Business Unit (BU)'),
      'portfolioDisplayName': kwargs.get('portfolioDisplayName', 'Test_Portfolio'),
      'activateProductTagOptions': kwargs.get('activateProductTagOptions', True),
      'shareThisPortfolio': kwargs.get('shareThisPortfolio', False),
      'accountIdOfChildAwsAccount': kwargs.get('accountIdOfChildAwsAccount', '1234567890'),
    }

    # Conditions
    condition_share_this_portfolio = props['shareThisPortfolio'] == 'true'

    # Resources
    serviceCatalogPortfolio = servicecatalog.CfnPortfolio(self, 'ServiceCatalogPortfolio',
          provider_name = props['portfolioProviderName'],
          description = props['portfolioDescription'],
          display_name = props['portfolioDisplayName'],
          tags = [
            {
              'key': 'Name',
              'value': f"""{props['portfolioDisplayName']}""",
            },
            {
              'key': 'Dept',
              'value': f"""{props['dept']}""",
            },
            {
              'key': 'Env',
              'value': f"""{props['env']}""",
            },
            {
              'key': 'User',
              'value': f"""{props['user']}""",
            },
            {
              'key': 'Owner',
              'value': f"""{props['owner']}""",
            },
          ],
        )

    serviceCatalogProductTagOptionsDept = servicecatalog.CfnTagOption(self, 'ServiceCatalogProductTagOptionsDept',
          active = props['activateProductTagOptions'],
          key = 'Dept',
          value = f"""{props['productDept']}""",
        )

    serviceCatalogProductTagOptionsEnv = servicecatalog.CfnTagOption(self, 'ServiceCatalogProductTagOptionsEnv',
          active = props['activateProductTagOptions'],
          key = 'Env',
          value = f"""{props['productEnv']}""",
        )

    serviceCatalogProductTagOptionsOwner = servicecatalog.CfnTagOption(self, 'ServiceCatalogProductTagOptionsOwner',
          active = props['activateProductTagOptions'],
          key = 'Owner',
          value = f"""{props['productOwner']}""",
        )

    serviceCatalogProductTagOptionsUser = servicecatalog.CfnTagOption(self, 'ServiceCatalogProductTagOptionsUser',
          active = props['activateProductTagOptions'],
          key = 'User',
          value = f"""{props['productUser']}""",
        )

    serviceCatalogPortfolioShare = servicecatalog.CfnPortfolioShare(self, 'ServiceCatalogPortfolioShare',
          account_id = props['accountIdOfChildAwsAccount'],
          portfolio_id = serviceCatalogPortfolio.ref,
        ) if condition_share_this_portfolio else None
    if (serviceCatalogPortfolioShare is not None):

    # Outputs
    self.service_catalog_portfolio = serviceCatalogPortfolio.ref
    cdk.CfnOutput(self, 'CfnOutputServiceCatalogPortfolio', 
      key = 'ServiceCatalogPortfolio',
      export_name = f"""{self.stack_name}-ServiceCatalogPortfolio""",
      value = str(self.service_catalog_portfolio),
    )

    self.service_catalog_portfolio_name = serviceCatalogPortfolio.attr_portfolio_name
    cdk.CfnOutput(self, 'CfnOutputServiceCatalogPortfolioName', 
      key = 'ServiceCatalogPortfolioName',
      export_name = f"""{self.stack_name}-ServiceCatalogPortfolioName""",
      value = str(self.service_catalog_portfolio_name),
    )

    self.service_catalog_product_tag_options_dept = serviceCatalogProductTagOptionsDept.ref
    cdk.CfnOutput(self, 'CfnOutputServiceCatalogProductTagOptionsDept', 
      key = 'ServiceCatalogProductTagOptionsDept',
      export_name = f"""{self.stack_name}-ServiceCatalogProductTagOptionsDept""",
      value = str(self.service_catalog_product_tag_options_dept),
    )



