from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_emr as emr
import aws_cdk.aws_iam as iam
from constructs import Construct

"""
  Best Practice EMR Cluster for Spark or S3 backed Hbase
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'emrClusterName': kwargs.get('emrClusterName', 'emrcluster'),
      'masterInstanceType': kwargs.get('masterInstanceType', 'm3.xlarge'),
      'coreInstanceType': kwargs.get('coreInstanceType', 'm3.xlarge'),
      'numberOfCoreInstances': kwargs.get('numberOfCoreInstances', 2),
      'logUri': kwargs.get('logUri', 's3://emrclusterlogbucket/'),
      's3DataUri': kwargs.get('s3DataUri', 's3://emrclusterdatabucket/'),
      'releaseLabel': kwargs.get('releaseLabel', 'emr-5.7.0'),
    }

    # Conditions
    hbase = props['applications'] == 'Hbase'
    spark = props['applications'] == 'Spark'

    # Resources
    emrClusterServiceRole = iam.CfnRole(self, 'EMRClusterServiceRole',
          assume_role_policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'elasticmapreduce.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          managed_policy_arns = [
            'arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceRole',
          ],
          path = '/',
        )

    emrClusterinstanceProfileRole = iam.CfnRole(self, 'EMRClusterinstanceProfileRole',
          assume_role_policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'ec2.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          managed_policy_arns = [
            'arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceforEC2Role',
          ],
          path = '/',
        )

    emrClusterinstanceProfile = iam.CfnInstanceProfile(self, 'EMRClusterinstanceProfile',
          path = '/',
          roles = [
            emrClusterinstanceProfileRole.ref,
          ],
        )

    emrCluster = emr.CfnCluster(self, 'EMRCluster',
          applications = [
            {
              'name': 'Ganglia',
            },
            {
              'name': 'Spark',
            } if spark else None,
            {
              'name': 'Hbase',
            } if hbase else None,
          ],
          configurations = [
            {
              'classification': 'hbase-site',
              'configurationProperties': {
                'hbase.rootdir': props['s3DataUri'],
              },
            },
            {
              'classification': 'hbase',
              'configurationProperties': {
                'hbase.emr.storageMode': 's3',
              },
            },
          ],
          instances = {
            'ec2KeyName': props['keyName'],
            'ec2SubnetId': props['subnetId'],
            'additionalMasterSecurityGroups': props['additionalPrimaryNodeSecurityGroups'],
            'additionalSlaveSecurityGroups': props['additionalCoreNodeSecurityGroups'],
            'masterInstanceGroup': {
              'instanceCount': 1,
              'instanceType': props['masterInstanceType'],
              'market': 'ON_DEMAND',
              'name': 'Master',
            },
            'coreInstanceGroup': {
              'instanceCount': props['numberOfCoreInstances'],
              'instanceType': props['coreInstanceType'],
              'market': 'ON_DEMAND',
              'name': 'Core',
            },
            'terminationProtected': False,
          },
          visible_to_all_users = True,
          job_flow_role = emrClusterinstanceProfile.ref,
          release_label = props['releaseLabel'],
          log_uri = props['logUri'],
          name = props['emrClusterName'],
          auto_scaling_role = 'EMR_AutoScaling_DefaultRole',
          service_role = emrClusterServiceRole.ref,
        )
    emrCluster.add_dependency(emrClusterServiceRole)
    emrCluster.add_dependency(emrClusterinstanceProfileRole)
    emrCluster.add_dependency(emrClusterinstanceProfile)


