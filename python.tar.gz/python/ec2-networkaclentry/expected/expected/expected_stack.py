from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_ec2 as ec2
from constructs import Construct

"""
  This stack automates the creation of an EC2 Network Acl and
  its entries

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Conditions
    is_us_east1 = self.region == 'us-east-1'

    # Resources
    dhcpOptions = ec2.CfnDHCPOptions(self, 'DhcpOptions',
          domain_name = 'ec2.internal' if is_us_east1 else f"""{self.region}.compute.internal""",
          domain_name_servers = [
            'AmazonProvidedDNS',
          ],
          netbios_node_type = 2,
        )

    vpc = ec2.CfnVPC(self, 'Vpc',
          cidr_block = '10.0.0.0/24',
        )

    networkAcl = ec2.CfnNetworkAcl(self, 'NetworkAcl',
          vpc_id = vpc.ref,
        )

    securityGroup = ec2.CfnSecurityGroup(self, 'SecurityGroup',
          group_description = 'Security group for additional control',
          vpc_id = vpc.ref,
          security_group_ingress = [
            {
              'ipProtocol': 'tcp',
              'fromPort': 80,
              'toPort': 80,
              'cidrIp': '0.0.0.0/0',
            },
            {
              'ipProtocol': 'tcp',
              'fromPort': 3389,
              'toPort': 3389,
              'cidrIp': '0.0.0.0/0',
            },
          ],
          security_group_egress = [
            {
              'ipProtocol': -1,
              'cidrIp': '0.0.0.0/0',
            },
          ],
        )

    subnet1 = ec2.CfnSubnet(self, 'Subnet1',
          availability_zone = cdk.Fn.select(0, cdk.Fn.get_azs('us-east-1')),
          cidr_block = cdk.Fn.select(0, cdk.Fn.cidr(vpc.attr_cidr_block, 2, str(6))),
          map_public_ip_on_launch = False,
          vpc_id = vpc.ref,
        )

    vpcDhcpOptions = ec2.CfnVPCDHCPOptionsAssociation(self, 'VpcDhcpOptions',
          dhcp_options_id = dhcpOptions.attr_dhcp_options_id,
          vpc_id = vpc.ref,
        )

    inboundHttpsRule = ec2.CfnNetworkAclEntry(self, 'InboundHTTPSRule',
          network_acl_id = networkAcl.ref,
          rule_number = 100,
          protocol = 6,
          rule_action = 'allow',
          cidr_block = vpc.attr_cidr_block,
          port_range = {
            'from': 443,
            'to': 443,
          },
        )

    inboundSshRule = ec2.CfnNetworkAclEntry(self, 'InboundSSHRule',
          network_acl_id = networkAcl.ref,
          rule_number = 101,
          protocol = 6,
          rule_action = 'allow',
          cidr_block = vpc.attr_cidr_block,
          port_range = {
            'from': 22,
            'to': 22,
          },
        )

    outboundRule = ec2.CfnNetworkAclEntry(self, 'OutboundRule',
          network_acl_id = networkAcl.ref,
          rule_number = 100,
          protocol = -1,
          egress = True,
          rule_action = 'allow',
          cidr_block = '0.0.0.0/0',
        )

    subnet1NetworkAcl = ec2.CfnSubnetNetworkAclAssociation(self, 'Subnet1NetworkAcl',
          subnet_id = subnet1.attr_subnet_id,
          network_acl_id = networkAcl.attr_id,
        )


