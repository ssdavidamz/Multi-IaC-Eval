from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_applicationautoscaling as applicationautoscaling
import aws_cdk.aws_autoscaling as autoscaling
import aws_cdk.aws_cloudwatch as cloudwatch
import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_ecs as ecs
import aws_cdk.aws_elasticloadbalancingv2 as elasticloadbalancingv2
import aws_cdk.aws_events as events
import aws_cdk.aws_iam as iam
import aws_cdk.aws_kms as kms
import aws_cdk.aws_logs as logs
import aws_cdk.aws_s3 as s3
from constructs import Construct

"""
  Amazon ECS Time and Event-Based Task Scheduling with CloudFormation. This will let you run tasks on a regular, scheduled basis and in response to CloudWatch Events. It easier to launch and stop container services that you need to run only at certain times. For example a backup/cleanup task.
"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'keyName': cdk.CfnParameter(self, 'keyName', 
        type = 'AWS::EC2::KeyPair::KeyName',
        default = str(kwargs.get('keyName')),
        description = 'Name of an existing EC2 KeyPair to enable SSH access to the ECS instances.',
      ),
      'vpcId': cdk.CfnParameter(self, 'vpcId', 
        type = 'AWS::EC2::VPC::Id',
        default = str(kwargs.get('vpcId')),
        description = 'Select a VPC that allows instances to access the Internet.',
      ),
      'subnetId': cdk.CfnParameter(self, 'subnetId', 
        type = 'List<AWS::EC2::Subnet::Id>',
        default = str(kwargs.get('subnetId')),
        description = 'Select at two subnets in your selected VPC.',
      ),
      'desiredCapacity': kwargs.get('desiredCapacity', 1),
      'maxSize': kwargs.get('maxSize', 1),
      'schedulerTasksCount': kwargs.get('schedulerTasksCount', 1),
      'cronOrRate': kwargs.get('cronOrRate', 'cron'),
      'cronSchedule': kwargs.get('cronSchedule', 'cron(00 11 ? * * *)'),
      'rateSchedule': kwargs.get('rateSchedule', 'rate(1 day)'),
      'instanceType': kwargs.get('instanceType', 't2.micro'),
      'latestAmiId': cdk.CfnParameter(self, 'latestAmiId', 
        type = 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default = str(kwargs.get('latestAmiId', '/aws/service/ecs/optimized-ami/amazon-linux-2023/recommended/image_id')),
      ),
    }

    # Conditions
    cron_rate = props['cronOrRate'] == 'cron'

    # Resources
    autoscalingRole = iam.CfnRole(self, 'AutoscalingRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'application-autoscaling.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          path = '/',
          policies = [
            {
              'policyName': 'service-autoscaling',
              'policyDocument': {
                'Statement': [
                  {
                    'Effect': 'Allow',
                    'Action': [
                      'application-autoscaling:*',
                      'cloudwatch:DescribeAlarms',
                      'cloudwatch:PutMetricAlarm',
                      'ecs:DescribeServices',
                      'ecs:UpdateService',
                    ],
                    'Resource': '*',
                  },
                ],
              },
            },
          ],
        )

    ec2Role = iam.CfnRole(self, 'EC2Role',
          assume_role_policy_document = {
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'ec2.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          path = '/',
          policies = [
            {
              'policyName': 'ecs-service',
              'policyDocument': {
                'Statement': [
                  {
                    'Effect': 'Allow',
                    'Action': [
                      'ecs:CreateCluster',
                      'ecs:DeregisterContainerInstance',
                      'ecs:DiscoverPollEndpoint',
                      'ecs:Poll',
                      'ecs:RegisterContainerInstance',
                      'ecs:StartTelemetrySession',
                      'ecs:Submit*',
                      'logs:CreateLogStream',
                      'logs:PutLogEvents',
                    ],
                    'Resource': '*',
                  },
                ],
              },
            },
          ],
        )

    ecsCluster = ecs.CfnCluster(self, 'ECSCluster',
        )

    ecsEventRole = iam.CfnRole(self, 'ECSEventRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'events.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          path = '/',
          policies = [
            {
              'policyName': 'ecs-service',
              'policyDocument': {
                'Statement': [
                  {
                    'Effect': 'Allow',
                    'Action': [
                      'ecs:RunTask',
                    ],
                    'Resource': '*',
                  },
                ],
              },
            },
          ],
        )

    ecsServiceRole = iam.CfnRole(self, 'ECSServiceRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'ecs.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          path = '/',
          policies = [
            {
              'policyName': 'ecs-service',
              'policyDocument': {
                'Statement': [
                  {
                    'Effect': 'Allow',
                    'Action': [
                      'elasticloadbalancing:DeregisterInstancesFromLoadBalancer',
                      'elasticloadbalancing:DeregisterTargets',
                      'elasticloadbalancing:Describe*',
                      'elasticloadbalancing:RegisterInstancesWithLoadBalancer',
                      'elasticloadbalancing:RegisterTargets',
                      'ec2:Describe*',
                      'ec2:AuthorizeSecurityGroupIngress',
                    ],
                    'Resource': '*',
                  },
                ],
              },
            },
          ],
        )

    ecsSecurityGroup = ec2.CfnSecurityGroup(self, 'EcsSecurityGroup',
          group_description = 'ECS Security Group',
          vpc_id = props['vpcId'],
        )

    logsKmsKey = kms.CfnKey(self, 'LogsKmsKey',
          description = 'ECS Logs Encryption Key',
          enable_key_rotation = True,
        )

    s3Bucket = s3.CfnBucket(self, 'S3Bucket',
          bucket_name = f"""{self.stack_name}-logs""",
          versioning_configuration = {
            'status': 'Enabled',
          },
        )

    cloudwatchLogsGroup = logs.CfnLogGroup(self, 'CloudwatchLogsGroup',
          log_group_name = '-'.join([
            'ECSLogGroup',
            self.stack_name,
          ]),
          retention_in_days = 14,
          kms_key_id = logsKmsKey.ref,
        )

    ec2InstanceProfile = iam.CfnInstanceProfile(self, 'EC2InstanceProfile',
          path = '/',
          roles = [
            ec2Role.ref,
          ],
        )

    ecsalb = elasticloadbalancingv2.CfnLoadBalancer(self, 'ECSALB',
          name = 'ECSALB',
          scheme = 'internet-facing',
          load_balancer_attributes = [
            {
              'key': 'idle_timeout.timeout_seconds',
              'value': '30',
            },
          ],
          subnets = props['subnetId'],
          security_groups = [
            ecsSecurityGroup.ref,
          ],
        )

    ecsSecurityGroupAlBports = ec2.CfnSecurityGroupIngress(self, 'EcsSecurityGroupALBports',
          group_id = ecsSecurityGroup.ref,
          ip_protocol = 'tcp',
          from_port = 31000,
          to_port = 61000,
          source_security_group_id = ecsSecurityGroup.ref,
        )

    ecsSecurityGroupHttPinbound = ec2.CfnSecurityGroupIngress(self, 'EcsSecurityGroupHTTPinbound',
          group_id = ecsSecurityGroup.ref,
          ip_protocol = 'tcp',
          from_port = 80,
          to_port = 80,
          cidr_ip = '0.0.0.0/0',
        )

    ecsSecurityGroupSsHinbound = ec2.CfnSecurityGroupIngress(self, 'EcsSecurityGroupSSHinbound',
          group_id = ecsSecurityGroup.ref,
          ip_protocol = 'tcp',
          from_port = 22,
          to_port = 22,
          cidr_ip = '192.168.1.0/0',
        )

    s3BucketPolicy = s3.CfnBucketPolicy(self, 'S3BucketPolicy',
          bucket = s3Bucket.ref,
          policy_document = {
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': '*',
                'Action': 's3:GetObject',
                'Resource': f"""arn:aws:s3:::{self.stack_name}-logs/*""",
              },
            ],
          },
        )

    containerInstances = autoscaling.CfnLaunchConfiguration(self, 'ContainerInstances',
          image_id = props['latestAmiId'],
          security_groups = [
            ecsSecurityGroup.ref,
          ],
          instance_type = props['instanceType'],
          iam_instance_profile = ec2InstanceProfile.ref,
          key_name = props['keyName'],
          user_data = cdk.Fn.base64(f"""#!/bin/bash -xe
          echo ECS_CLUSTER={ecsCluster.ref} >> /etc/ecs/ecs.config
          yum install -y aws-cfn-bootstrap
          /opt/aws/bin/cfn-signal -e $? --stack {self.stack_name} \
              --resource ECSAutoScalingGroup \
              --region {self.region}
          """),
        )

    ecstg = elasticloadbalancingv2.CfnTargetGroup(self, 'ECSTG',
          health_check_interval_seconds = 10,
          health_check_path = '/',
          health_check_protocol = 'HTTP',
          health_check_timeout_seconds = 5,
          healthy_threshold_count = 2,
          name = 'ECSTG',
          port = 80,
          protocol = 'HTTP',
          unhealthy_threshold_count = 2,
          vpc_id = props['vpcId'],
        )
    ecstg.add_dependency(ecsalb)

    taskDefinition = ecs.CfnTaskDefinition(self, 'TaskDefinition',
          family = ''.join([
            self.stack_name,
            '-ecs-demo-app',
          ]),
          container_definitions = [
            {
              'name': 'simple-app',
              'cpu': 10,
              'essential': True,
              'image': 'httpd:2.4',
              'memory': 300,
              'logConfiguration': {
                'logDriver': 'awslogs',
                'options': {
                  'awslogs-group': cloudwatchLogsGroup.ref,
                  'awslogs-region': self.region,
                  'awslogs-stream-prefix': 'ecs-demo-app',
                },
              },
              'mountPoints': [
                {
                  'containerPath': '/usr/local/apache2/htdocs',
                  'sourceVolume': 'my-vol',
                },
              ],
              'portMappings': [
                {
                  'containerPort': 80,
                },
              ],
            },
            {
              'name': 'busybox',
              'cpu': 10,
              'command': [
                '/bin/sh -c \"while true; do echo \'<html> <head> <title>Amazon ECS Sample App</title> <style>body {margin-top: 40px; background-color: #333;} </style> </head><body> <div style=color:white;text-align:center> <h1>Amazon ECS Sample App</h1> <h2>Congratulations!</h2> <p>Your application is now running on a container in Amazon ECS.</p>\' > top; /bin/date > date ; echo \'</div></body></html>\' > bottom; cat top date bottom > /usr/local/apache2/htdocs/index.html ; sleep 1; done\"',
              ],
              'entryPoint': [
                'sh',
                '-c',
              ],
              'essential': False,
              'image': 'busybox',
              'memory': 200,
              'logConfiguration': {
                'logDriver': 'awslogs',
                'options': {
                  'awslogs-group': cloudwatchLogsGroup.ref,
                  'awslogs-region': self.region,
                  'awslogs-stream-prefix': 'ecs-demo-app',
                },
              },
              'volumesFrom': [
                {
                  'sourceContainer': 'simple-app',
                },
              ],
            },
          ],
          volumes = [
            {
              'name': 'my-vol',
            },
          ],
        )

    albListener = elasticloadbalancingv2.CfnListener(self, 'ALBListener',
          default_actions = [
            {
              'type': 'forward',
              'targetGroupArn': ecstg.ref,
            },
          ],
          load_balancer_arn = ecsalb.ref,
          port = 80,
          protocol = 'HTTP',
        )
    albListener.add_dependency(ecsServiceRole)

    ecsAutoScalingGroup = autoscaling.CfnAutoScalingGroup(self, 'ECSAutoScalingGroup',
          vpc_zone_identifier = props['subnetId'],
          launch_configuration_name = containerInstances.ref,
          min_size = '1',
          max_size = props['maxSize'],
          desired_capacity = props['desiredCapacity'],
        )
    ecsAutoScalingGroup.cfn_options.update_policy = {
      'AutoScalingReplacingUpdate': {
        'WillReplace': True,
      },
    }
    ecsScheduledTask = events.CfnRule(self, 'ECSScheduledTask',
          description = 'Creating a Schedule with CloudFormation as an example',
          schedule_expression = props['cronSchedule'] if cron_rate else props['rateSchedule'],
          state = 'ENABLED',
          targets = [
            {
              'arn': ecsCluster.attr_arn,
              'id': 'Target1',
              'roleArn': ecsEventRole.attr_arn,
              'ecsParameters': {
                'taskCount': props['schedulerTasksCount'],
                'taskDefinitionArn': taskDefinition.ref,
              },
            },
          ],
        )
    ecsScheduledTask.add_dependency(ecsEventRole)

    ecsalbListenerRule = elasticloadbalancingv2.CfnListenerRule(self, 'ECSALBListenerRule',
          actions = [
            {
              'type': 'forward',
              'targetGroupArn': ecstg.ref,
            },
          ],
          conditions = [
            {
              'field': 'path-pattern',
              'values': [
                '/',
              ],
            },
          ],
          listener_arn = albListener.ref,
          priority = 1,
        )
    ecsalbListenerRule.add_dependency(albListener)

    service = ecs.CfnService(self, 'Service',
          cluster = ecsCluster.ref,
          desired_count = 1,
          load_balancers = [
            {
              'containerName': 'simple-app',
              'containerPort': 80,
              'targetGroupArn': ecstg.ref,
            },
          ],
          role = ecsServiceRole.ref,
          task_definition = taskDefinition.ref,
        )
    service.add_dependency(albListener)

    serviceScalingTarget = applicationautoscaling.CfnScalableTarget(self, 'ServiceScalingTarget',
          max_capacity = 2,
          min_capacity = 1,
          resource_id = ''.join([
            'service/',
            ecsCluster.ref,
            '/',
            service.attr_name,
          ]),
          role_arn = autoscalingRole.attr_arn,
          scalable_dimension = 'ecs:service:DesiredCount',
          service_namespace = 'ecs',
        )
    serviceScalingTarget.add_dependency(service)

    serviceScalingPolicy = applicationautoscaling.CfnScalingPolicy(self, 'ServiceScalingPolicy',
          policy_name = 'AStepPolicy',
          policy_type = 'StepScaling',
          scaling_target_id = serviceScalingTarget.ref,
          step_scaling_policy_configuration = {
            'adjustmentType': 'PercentChangeInCapacity',
            'cooldown': 60,
            'metricAggregationType': 'Average',
            'stepAdjustments': [
              {
                'metricIntervalLowerBound': 0,
                'scalingAdjustment': 200,
              },
            ],
          },
        )

    alb500sAlarmScaleUp = cloudwatch.CfnAlarm(self, 'ALB500sAlarmScaleUp',
          evaluation_periods = 1,
          statistic = 'Average',
          threshold = 10,
          alarm_description = 'Alarm if our ALB generates too many HTTP 500s.',
          period = 60,
          alarm_actions = [
            serviceScalingPolicy.ref,
          ],
          namespace = 'AWS/ApplicationELB',
          dimensions = [
            {
              'name': 'ECSService',
              'value': service.ref,
            },
          ],
          comparison_operator = 'GreaterThanThreshold',
          metric_name = 'HTTPCode_ELB_5XX_Count',
        )

    # Outputs
    self.ecs_service = service.ref
    cdk.CfnOutput(self, 'CfnOutputEcsService', 
      key = 'EcsService',
      value = str(self.ecs_service),
    )

    self.ecs_cluster = ecsCluster.ref
    cdk.CfnOutput(self, 'CfnOutputEcsCluster', 
      key = 'EcsCluster',
      value = str(self.ecs_cluster),
    )

    self.ecs_task_def = taskDefinition.ref
    cdk.CfnOutput(self, 'CfnOutputEcsTaskDef', 
      key = 'EcsTaskDef',
      value = str(self.ecs_task_def),
    )

    """
      Your ALB DNS URL
    """
    self.ecsalb = ''.join([
      ecsalb.attr_dns_name,
    ])
    cdk.CfnOutput(self, 'CfnOutputECSALB', 
      key = 'ECSALB',
      description = 'Your ALB DNS URL',
      value = str(self.ecsalb),
    )

    """
      S3 Bucket for storing application logs
    """
    self.s3_bucket = s3Bucket.ref
    cdk.CfnOutput(self, 'CfnOutputS3Bucket', 
      key = 'S3Bucket',
      description = 'S3 Bucket for storing application logs',
      value = str(self.s3_bucket),
    )



