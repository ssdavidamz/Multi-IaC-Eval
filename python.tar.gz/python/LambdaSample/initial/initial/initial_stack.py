from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_iam as iam
import aws_cdk.aws_lambda as aws_lambda
from constructs import Construct

"""
  Template for Lambda Sample.
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    lambdaRole = iam.CfnRole(self, 'LambdaRole',
          role_name = 'lambda-role',
          assume_role_policy_document = {
            'Statement': [
              {
                'Action': [
                  'sts:AssumeRole',
                ],
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'lambda.amazonaws.com',
                  ],
                },
              },
            ],
            'Version': '2012-10-17',
          },
          managed_policy_arns = [
            'arn:aws:iam::aws:policy/AWSLambdaExecute',
            'arn:aws:iam::aws:policy/AmazonS3FullAccess',
            'arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess',
            'arn:aws:iam::aws:policy/AmazonKinesisFullAccess',
          ],
          path = '/',
        )

    lambdaFunction = aws_lambda.CfnFunction(self, 'LambdaFunction',
          function_name = f"""lambda-function-{props['envName']}""",
          description = 'LambdaFunction using python3.12.',
          runtime = 'python3.12',
          code = {
            'zipFile': 'import json\n\ndef lambda_handler(event, context):\n    print(json.dumps(event))\n    return {\n        \'statusCode\': 200,\n        \'body\': json.dumps(\'Hello from Lambda!\')\n    }\n',
          },
          handler = f"""{props['lambdaHandlerPath']}""",
          memory_size = 128,
          timeout = 10,
          role = lambdaRole.attr_arn,
          environment = {
            'variables': {
              'ENV': props['envName'],
              'TZ': 'UTC',
            },
          },
        )
    lambdaFunction.cfn_options.metadata = {
      'guard': {
        'SuppressedRules': [
          'LAMBDA_INSIDE_VPC',
          'LAMBDA_FUNCTION_PUBLIC_ACCESS_PROHIBITED',
        ],
      },
    }

    # Outputs
    """
      Role for Lambda execution.
    """
    self.lambda_role_arn = lambdaRole.attr_arn
    cdk.CfnOutput(self, 'CfnOutputLambdaRoleARN', 
      key = 'LambdaRoleARN',
      description = 'Role for Lambda execution.',
      export_name = 'LambdaRole',
      value = str(self.lambda_role_arn),
    )

    self.lambda_function_name = lambdaFunction.ref
    cdk.CfnOutput(self, 'CfnOutputLambdaFunctionName', 
      key = 'LambdaFunctionName',
      value = str(self.lambda_function_name),
    )

    """
      Lambda function ARN.
    """
    self.lambda_function_arn = lambdaFunction.attr_arn
    cdk.CfnOutput(self, 'CfnOutputLambdaFunctionARN', 
      key = 'LambdaFunctionARN',
      description = 'Lambda function ARN.',
      export_name = f"""LambdaARN-{props['envName']}""",
      value = str(self.lambda_function_arn),
    )



