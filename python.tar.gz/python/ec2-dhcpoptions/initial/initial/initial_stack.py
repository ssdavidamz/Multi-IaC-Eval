from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_ec2 as ec2
from constructs import Construct

"""
  This stack automates the creation of EC2 DHCP options

"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Conditions
    is_us_east1 = self.region == 'us-east-1'

    # Resources
    iamRole = ec2.CfnDHCPOptions(self, 'IamRole',
          domain_name = 'ec2.internal' if is_us_east1 else f"""{self.region}.compute.internal""",
          domain_name_servers = [
            'AmazonProvidedDNS',
          ],
          netbios_node_type = 2,
        )


