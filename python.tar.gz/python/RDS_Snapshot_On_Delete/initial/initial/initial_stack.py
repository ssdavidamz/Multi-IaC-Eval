from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_rds as rds
from constructs import Construct

"""
  AWS CloudFormation Sample Template RDS_Snapshot_On_Delete: Sample template showing how to create an RDS DBInstance that is snapshotted on stack deletion. **WARNING** This template creates an Amazon RDS database instance. When the stack is deleted a database snapshot will be left in your account. You will be billed for the AWS resources used if you create a stack from this template.
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    myDb = rds.CfnDBInstance(self, 'MyDB',
          db_name = 'MyDatabase',
          allocated_storage = '5',
          db_instance_class = 'db.t3.small',
          backup_retention_period = 7,
          engine = 'MySQL',
          master_username = 'myName',
          manage_master_user_password = True,
          publicly_accessible = False,
          storage_encrypted = True,
        )
    myDb.cfn_options.deletion_policy = cdk.CfnDeletionPolicy.SNAPSHOT

    # Outputs
    """
      JDBC connection string for the database
    """
    self.jdbc_connection_string = ''.join([
      'jdbc:mysql://',
      myDb.attr_endpoint_address,
      ':',
      myDb.attr_endpoint_port,
      '/MyDatabase',
    ])
    cdk.CfnOutput(self, 'CfnOutputJDBCConnectionString', 
      key = 'JDBCConnectionString',
      description = 'JDBC connection string for the database',
      value = str(self.jdbc_connection_string),
    )



