from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_directoryservice as directoryservice
import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_s3 as s3
import aws_cdk.aws_secretsmanager as secretsmanager
from constructs import Construct

"""
  Create a VPC with 2 subnets for the AWS Managed Microsoft AD with a password stored in secrets manager and add an S3 bucket for storing AD logs

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    adLogsBucket = s3.CfnBucket(self, 'ADLogsBucket',
          bucket_name = f"""ad-logs-{self.stack_name}""",
          versioning_configuration = {
            'status': 'Enabled',
          },
          logging_configuration = {
            'destinationBucketName': f"""ad-logs-destination-{self.stack_name}""",
            'logFilePrefix': 'ad-logs/',
          },
        )

    awsManagedAdSecret = secretsmanager.CfnSecret(self, 'AWSManagedADSecret',
          description = 'Secret used for provisioning Managed AD',
          generate_secret_string = {
            'passwordLength': 24,
          },
        )
    awsManagedAdSecret.cfn_options.metadata = {
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_149',
          },
        ],
      },
      'guard': {
        'SuppressedRules': [
          'SECRETSMANAGER_USING_CMK',
          'SECRETSMANAGER_ROTATION_ENABLED_CHECK',
        ],
      },
    }

    vpc = ec2.CfnVPC(self, 'VPC',
          cidr_block = '10.0.0.0/24',
          enable_dns_hostnames = True,
          enable_dns_support = True,
          instance_tenancy = 'default',
        )

    vpcSubnet1 = ec2.CfnSubnet(self, 'VPCSubnet1',
          availability_zone = cdk.Fn.select(0, cdk.Fn.get_azs(self.region)),
          cidr_block = cdk.Fn.select(0, cdk.Fn.cidr(vpc.attr_cidr_block, 2, str(6))),
          map_public_ip_on_launch = False,
          vpc_id = vpc.ref,
        )

    vpcSubnet2 = ec2.CfnSubnet(self, 'VPCSubnet2',
          availability_zone = cdk.Fn.select(1, cdk.Fn.get_azs(self.region)),
          cidr_block = cdk.Fn.select(1, cdk.Fn.cidr(vpc.attr_cidr_block, 2, str(6))),
          map_public_ip_on_launch = False,
          vpc_id = vpc.ref,
        )

    managedAd = directoryservice.CfnMicrosoftAD(self, 'ManagedAD',
          create_alias = False,
          edition = 'Enterprise',
          enable_sso = False,
          name = 'corp.example.com',
          password = f"""{{{{resolve:secretsmanager:{awsManagedAdSecret.ref}}}}}""",
          short_name = 'CORP',
          vpc_settings = {
            'subnetIds': [
              vpcSubnet1.ref,
              vpcSubnet2.ref,
            ],
            'vpcId': vpc.ref,
          },
        )


