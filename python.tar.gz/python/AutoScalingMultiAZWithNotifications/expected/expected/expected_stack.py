from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_autoscaling as autoscaling
import aws_cdk.aws_cloudwatch as cloudwatch
import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_elasticloadbalancingv2 as elasticloadbalancingv2
import aws_cdk.aws_logs as logs
import aws_cdk.aws_sns as sns
from constructs import Construct

"""
  Create a multi-az, load balanced and Auto Scaled sample web site running on
  an Apache Web Server. The application is configured to span all
  Availability Zones in the region and is Auto-Scaled based on the CPU
  utilization of the web servers. Notifications will be sent to the operator
  email address on scaling events. The instances are load balanced with a
  simple health check against the default web page. **WARNING** This template
  creates one or more Amazon EC2 instances and an Elastic Load Balancer. You
  will be billed for the AWS resources used if you create a stack from this
  template.

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'instanceType': kwargs.get('instanceType', 't4g.micro'),
      'keyName': cdk.CfnParameter(self, 'keyName', 
        type = 'AWS::EC2::KeyPair::KeyName',
        default = str(kwargs.get('keyName')),
        description = 'The EC2 Key Pair to allow SSH access to the instances',
      ),
      'sshLocation': kwargs.get('sshLocation', '192.168.1.0/24'),
      'latestAmiId': cdk.CfnParameter(self, 'latestAmiId', 
        type = 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default = str(kwargs.get('latestAmiId', '/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-6.1-arm64')),
      ),
      'securityGroups': cdk.CfnParameter(self, 'securityGroups', 
        type = 'List<AWS::EC2::SecurityGroup::Id>',
        default = str(kwargs.get('securityGroups')),
        description = 'Security Groups to be used',
      ),
      'subnets': cdk.CfnParameter(self, 'subnets', 
        type = 'List<AWS::EC2::Subnet::Id>',
        default = str(kwargs.get('subnets')),
        description = 'Subnets to be used',
      ),
      'aZs': cdk.CfnParameter(self, 'aZs', 
        type = 'List<AWS::EC2::AvailabilityZone::Name>',
        default = str(kwargs.get('aZs')),
        description = 'Availability Zones to be used',
      ),
      'vpc': cdk.CfnParameter(self, 'vpc', 
        type = 'AWS::EC2::VPC::Id',
        default = str(kwargs.get('vpc')),
        description = 'VPC to be used',
      ),
    }

    # Mappings
    region2Examples = {
      'us-east-1': {
        'Examples': 'https://s3.amazonaws.com/cloudformation-examples-us-east-1',
      },
      'us-west-2': {
        'Examples': 'https://s3-us-west-2.amazonaws.com/cloudformation-examples-us-west-2',
      },
      'us-west-1': {
        'Examples': 'https://s3-us-west-1.amazonaws.com/cloudformation-examples-us-west-1',
      },
      'eu-west-1': {
        'Examples': 'https://s3-eu-west-1.amazonaws.com/cloudformation-examples-eu-west-1',
      },
      'eu-central-1': {
        'Examples': 'https://s3-eu-central-1.amazonaws.com/cloudformation-examples-eu-central-1',
      },
      'ap-southeast-1': {
        'Examples': 'https://s3-ap-southeast-1.amazonaws.com/cloudformation-examples-ap-southeast-1',
      },
      'ap-northeast-1': {
        'Examples': 'https://s3-ap-northeast-1.amazonaws.com/cloudformation-examples-ap-northeast-1',
      },
      'ap-northeast-2': {
        'Examples': 'https://s3-ap-northeast-2.amazonaws.com/cloudformation-examples-ap-northeast-2',
      },
      'ap-southeast-2': {
        'Examples': 'https://s3-ap-southeast-2.amazonaws.com/cloudformation-examples-ap-southeast-2',
      },
      'ap-south-1': {
        'Examples': 'https://s3-ap-south-1.amazonaws.com/cloudformation-examples-ap-south-1',
      },
      'us-east-2': {
        'Examples': 'https://s3-us-east-2.amazonaws.com/cloudformation-examples-us-east-2',
      },
      'sa-east-1': {
        'Examples': 'https://s3-sa-east-1.amazonaws.com/cloudformation-examples-sa-east-1',
      },
      'cn-north-1': {
        'Examples': 'https://s3.cn-north-1.amazonaws.com.cn/cloudformation-examples-cn-north-1',
      },
    }

    # Resources
    cloudWatchLogGroup = logs.CfnLogGroup(self, 'CloudWatchLogGroup',
          log_group_name = f"""{self.stack_name}-WebServerLogs""",
          retention_in_days = 7,
        )

    launchTemplate = ec2.CfnLaunchTemplate(self, 'LaunchTemplate',
          launch_template_name = f"""{self.stack_name}-LaunchTemplate""",
          launch_template_data = {
            'imageId': props['latestAmiId'],
            'instanceType': props['instanceType'],
            'securityGroupIds': props['securityGroups'],
            'keyName': props['keyName'],
            'blockDeviceMappings': [
              {
                'deviceName': '/dev/sda1',
                'ebs': {
                  'volumeSize': 32,
                },
              },
            ],
            'userData': cdk.Fn.base64(f"""#!/bin/bash
            /opt/aws/bin/cfn-init -v --stack {self.stack_name} --resource LaunchTemplate --region {self.region}
            /opt/aws/bin/cfn-signal -e $? --stack {self.stack_name} --resource WebServerGroup --region {self.region}
            """),
            'tagSpecifications': [
              {
                'resourceType': 'instance',
                'tags': [
                  {
                    'key': 'Name',
                    'value': f"""{self.stack_name}-Instance""",
                  },
                ],
              },
            ],
          },
        )
    launchTemplate.cfn_options.metadata = {
      'AWS::CloudFormation::Init': {
        'config': {
          'packages': {
            'yum': {
              'httpd': [
              ],
            },
          },
          'files': {
            '/var/www/html/index.html': {
              'content': ''.join([
                '<img src=\"',
                region2Examples[self.region]['Examples'],
                '/cloudformation_graphic.png\" alt=\"AWS CloudFormation Logo\"/>',
                '<h1>Congratulations, you have successfully launched the AWS CloudFormation sample.</h1>',
              ]),
              'mode': '000644',
              'owner': 'root',
              'group': 'root',
            },
            '/etc/cfn/cfn-hup.conf': {
              'content': f"""[main]
              stack={self.stack_id}
              region={self.region}
              """,
              'mode': '000400',
              'owner': 'root',
              'group': 'root',
            },
            '/etc/cfn/hooks.d/cfn-auto-reloader.conf': {
              'content': f"""[cfn-auto-reloader-hook]
              triggers=post.update
              path=Resources.LaunchTemplate.Metadata.AWS::CloudFormation::Init
              action=/opt/aws/bin/cfn-init -v --stack {self.stack_name} --resource LaunchTemplate --region {self.region}
              runas=root
              """,
            },
          },
          'services': {
            'sysvinit': {
              'httpd': {
                'enabled': True,
                'ensureRunning': True,
              },
              'cfn-hup': {
                'enabled': True,
                'ensureRunning': True,
                'files': [
                  '/etc/cfn/cfn-hup.conf',
                  '/etc/cfn/hooks.d/cfn-auto-reloader.conf',
                ],
              },
            },
          },
        },
      },
    }

    loadBalancerSecurityGroup = ec2.CfnSecurityGroup(self, 'LoadBalancerSecurityGroup',
          group_description = 'Allows inbound traffic on port 443',
          security_group_ingress = [
            {
              'ipProtocol': 'tcp',
              'fromPort': 443,
              'toPort': 443,
              'cidrIp': '0.0.0.0/0',
            },
          ],
          vpc_id = props['vpc'],
        )

    notificationTopic = sns.CfnTopic(self, 'NotificationTopic',
          display_name = f"""{self.stack_name}-NotificationTopic""",
          subscription = [
            {
              'endpoint': props['operatorEMail'],
              'protocol': 'email',
            },
          ],
          kms_master_key_id = props['kmsKeyArn'],
        )

    targetGroup = elasticloadbalancingv2.CfnTargetGroup(self, 'TargetGroup',
          health_check_path = '/',
          name = 'MyTargetGroup',
          port = 80,
          protocol = 'HTTP',
          target_type = 'instance',
          vpc_id = props['vpc'],
        )

    elasticLoadBalancer = elasticloadbalancingv2.CfnLoadBalancer(self, 'ElasticLoadBalancer',
          scheme = 'internet-facing',
          security_groups = [
            loadBalancerSecurityGroup.ref,
          ],
          subnets = props['subnets'],
          type = 'application',
        )

    instanceSecurityGroup = ec2.CfnSecurityGroup(self, 'InstanceSecurityGroup',
          group_description = 'Enable SSH access and HTTP from the load balancer only',
          security_group_ingress = [
            {
              'ipProtocol': 'tcp',
              'fromPort': 22,
              'toPort': 22,
              'cidrIp': props['sshLocation'],
            },
            {
              'ipProtocol': 'tcp',
              'fromPort': 80,
              'toPort': 80,
              'sourceSecurityGroupId': loadBalancerSecurityGroup.ref,
            },
          ],
        )
    instanceSecurityGroup.cfn_options.metadata = {
      'guard': {
        'SuppressedRules': [
          'INCOMING_SSH_DISABLED',
        ],
      },
    }

    webServerGroup = autoscaling.CfnAutoScalingGroup(self, 'WebServerGroup',
          availability_zones = props['aZs'],
          launch_template = {
            'launchTemplateId': launchTemplate.ref,
            'version': launchTemplate.attr_latest_version_number,
          },
          min_size = '1',
          max_size = '3',
          target_group_ar_ns = [
            targetGroup.ref,
          ],
          notification_configurations = [
            {
              'topicArn': notificationTopic.ref,
              'notificationTypes': [
                'autoscaling:EC2_INSTANCE_LAUNCH',
                'autoscaling:EC2_INSTANCE_LAUNCH_ERROR',
                'autoscaling:EC2_INSTANCE_TERMINATE',
                'autoscaling:EC2_INSTANCE_TERMINATE_ERROR',
              ],
            },
          ],
          health_check_type = 'ELB',
          vpc_zone_identifier = props['subnets'],
        )
    webServerGroup.cfn_options.metadata = {
      'cfn-lint': {
        'config': {
          'ignore_checks': [
            'E3014',
          ],
        },
      },
    }
    webServerGroup.cfn_options.update_policy = {
      'AutoScalingRollingUpdate': {
        'MinInstancesInService': 1,
        'MaxBatchSize': 1,
        'PauseTime': 'PT5M',
        'WaitOnResourceSignals': True,
      },
    }
    loadBalancerListener = elasticloadbalancingv2.CfnListener(self, 'LoadBalancerListener',
          default_actions = [
            {
              'type': 'forward',
              'targetGroupArn': targetGroup.ref,
            },
          ],
          load_balancer_arn = elasticLoadBalancer.ref,
          port = 443,
          protocol = 'HTTPS',
          ssl_policy = 'ELBSecurityPolicy-2016-08',
          certificates = [
            {
              'certificateArn': props['certificateArn'],
            },
          ],
        )

    webServerScaleDownPolicy = autoscaling.CfnScalingPolicy(self, 'WebServerScaleDownPolicy',
          adjustment_type = 'ChangeInCapacity',
          auto_scaling_group_name = webServerGroup.ref,
          cooldown = '60',
          scaling_adjustment = -1,
        )

    webServerScaleUpPolicy = autoscaling.CfnScalingPolicy(self, 'WebServerScaleUpPolicy',
          adjustment_type = 'ChangeInCapacity',
          auto_scaling_group_name = webServerGroup.ref,
          cooldown = '60',
          scaling_adjustment = 1,
        )

    cpuAlarmHigh = cloudwatch.CfnAlarm(self, 'CPUAlarmHigh',
          alarm_description = 'Scale-up if CPU > 90% for 10 minutes',
          metric_name = 'CPUUtilization',
          namespace = 'AWS/EC2',
          statistic = 'Average',
          period = 300,
          evaluation_periods = 2,
          threshold = 90,
          alarm_actions = [
            webServerScaleUpPolicy.ref,
          ],
          dimensions = [
            {
              'name': 'AutoScalingGroupName',
              'value': webServerGroup.ref,
            },
          ],
          comparison_operator = 'GreaterThanThreshold',
        )

    cpuAlarmLow = cloudwatch.CfnAlarm(self, 'CPUAlarmLow',
          alarm_description = 'Scale-down if CPU < 70% for 10 minutes',
          metric_name = 'CPUUtilization',
          namespace = 'AWS/EC2',
          statistic = 'Average',
          period = 300,
          evaluation_periods = 2,
          threshold = 70,
          alarm_actions = [
            webServerScaleDownPolicy.ref,
          ],
          dimensions = [
            {
              'name': 'AutoScalingGroupName',
              'value': webServerGroup.ref,
            },
          ],
          comparison_operator = 'LessThanThreshold',
        )

    # Outputs
    """
      The URL of the website
    """
    self.url = ''.join([
      'https://',
      elasticLoadBalancer.attr_dns_name,
    ])
    cdk.CfnOutput(self, 'CfnOutputURL', 
      key = 'URL',
      description = 'The URL of the website',
      value = str(self.url),
    )



