import aws_cdk as core
import aws_cdk.assertions as assertions

from expected.expected_stack import ExpectedStack

# example tests. To run these tests, uncomment this file along with the example
# resource in expected/expected_stack.py
def test_sqs_queue_created():
    app = core.App()
    stack = ExpectedStack(app, "expected")
    template = assertions.Template.from_stack(stack)

#     template.has_resource_properties("AWS::SQS::Queue", {
#         "VisibilityTimeout": 300
#     })
