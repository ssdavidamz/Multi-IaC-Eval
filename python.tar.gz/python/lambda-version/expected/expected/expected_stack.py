from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_iam as iam
import aws_cdk.aws_lambda as aws_lambda
from constructs import Construct

"""
  This template will create a lambda function and an associated lambda
  version

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    lambdaRole = iam.CfnRole(self, 'LambdaRole',
          role_name = 'LambdaRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': 'lambda.amazonaws.com',
                },
                'Action': 'sts:AssumeRole',
              },
            ],
          },
        )

    function = aws_lambda.CfnFunction(self, 'Function',
          handler = 'index.handler',
          role = lambdaRole.attr_arn,
          reserved_concurrent_executions = 20,
          code = {
            'zipFile': 'def handler(event, context):\n  return \'Hello World!\'\n',
          },
          runtime = 'python3.10',
          tracing_config = {
            'mode': 'Active',
          },
          environment = {
            'variables': {
              'CUSTOM_VARIABLE': 'example_value',
            },
          },
        )
    function.cfn_options.metadata = {
      'Comment': 'A lambda function that implements REST API endpoints',
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_116',
            'comment': 'This function is not called async',
          },
          {
            'id': 'CKV_AWS_117',
            'comment': 'This example does not run in a VPC',
          },
        ],
      },
      'guard': {
        'SuppressedRules': [
          'LAMBDA_INSIDE_VPC',
          'LAMBDA_DLQ_CHECK',
        ],
        'Comments': [
          'This example does not run in a VPC',
          'The function is not called async so a DLQ is not necessary',
        ],
      },
    }

    version = aws_lambda.CfnVersion(self, 'Version',
          function_name = function.ref,
          description = 'v1',
          provisioned_concurrency_config = {
            'provisionedConcurrentExecutions': 20,
          },
        )


