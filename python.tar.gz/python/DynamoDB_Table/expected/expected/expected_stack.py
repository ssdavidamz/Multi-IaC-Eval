from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_dynamodb as dynamodb
from constructs import Construct

"""
  AWS CloudFormation Sample Template DynamoDB_Table: This template demonstrates the creation of a DynamoDB table.  **WARNING** This template creates an Amazon DynamoDB table. You will be billed for the AWS resources used if you create a stack from this template.
"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'hashKeyElementType': kwargs.get('hashKeyElementType', 'S'),
      'readCapacityUnits': kwargs.get('readCapacityUnits', 5),
      'writeCapacityUnits': kwargs.get('writeCapacityUnits', 10),
    }

    # Resources
    myDynamoDbTable = dynamodb.CfnTable(self, 'myDynamoDBTable',
          attribute_definitions = [
            {
              'attributeName': props['hashKeyElementName'],
              'attributeType': props['hashKeyElementType'],
            },
          ],
          key_schema = [
            {
              'attributeName': props['hashKeyElementName'],
              'keyType': 'HASH',
            },
          ],
          provisioned_throughput = {
            'readCapacityUnits': props['readCapacityUnits'],
            'writeCapacityUnits': props['writeCapacityUnits'],
          },
          point_in_time_recovery_specification = {
            'pointInTimeRecoveryEnabled': True,
          },
          global_secondary_indexes = [
            {
              'indexName': 'GSI-1',
              'keySchema': [
                {
                  'attributeName': 'GSIHashKey',
                  'keyType': 'HASH',
                },
              ],
              'projection': {
                'projectionType': 'ALL',
              },
              'provisionedThroughput': {
                'readCapacityUnits': 5,
                'writeCapacityUnits': 5,
              },
            },
          ],
        )

    # Outputs
    """
      Table name of the newly created DynamoDB table
    """
    self.table_name = myDynamoDbTable.ref
    cdk.CfnOutput(self, 'CfnOutputTableName', 
      key = 'TableName',
      description = 'Table name of the newly created DynamoDB table',
      value = str(self.table_name),
    )



