from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_iam as iam
from constructs import Construct

"""
  This stack automates the creation of an IAM instance profile

"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    iamRole = iam.CfnRole(self, 'IamRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'ec2.amazonaws.com',
                  ],
                },
                'Actions': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          path = '/',
        )

    iamProfile = iam.CfnInstanceProfile(self, 'IamProfile',
          roles = [
            iamRole.ref,
          ],
          path = '/',
        )


