from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_cloudwatch as cloudwatch
import aws_cdk.aws_sqs as sqs
from constructs import Construct

"""
  This stack creates a SQS queue using KMS encryption
  with a SQS policy allowing the account that the 
  queue is deployed into the ability to read and write
  from the queue

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    queue = sqs.CfnQueue(self, 'Queue',
          delay_seconds = 0,
          fifo_queue = False,
          kms_data_key_reuse_period_seconds = 300,
          kms_master_key_id = props['kmsKey'],
          maximum_message_size = 262144,
          message_retention_period = 345600,
          receive_message_wait_time_seconds = 0,
          visibility_timeout = 30,
        )
    queue.cfn_options.deletion_policy = cdk.CfnDeletionPolicy.RETAIN

    cloudWatchAlarm = cloudwatch.CfnAlarm(self, 'CloudWatchAlarm',
          alarm_description = 'Alarm when there are more than 100 messages in the queue',
          metric_name = 'ApproximateNumberOfMessagesVisible',
          namespace = 'AWS/SQS',
          statistic = 'Average',
          period = 300,
          evaluation_periods = 1,
          threshold = 100,
          comparison_operator = 'GreaterThanThreshold',
          actions_enabled = False,
          alarm_actions = [
            'arn:aws:sns:REGION:ACCOUNT_ID:YOUR_SNS_TOPIC_ARN',
          ],
          dimensions = [
            {
              'name': 'QueueName',
              'value': queue.attr_queue_name,
            },
          ],
        )

    queuePolicy = sqs.CfnQueuePolicy(self, 'QueuePolicy',
          queues = [
            queue.attr_queue_url,
          ],
          policy_document = {
            'Statement': [
              {
                'Action': [
                  'SQS:SendMessage',
                  'SQS:ReceiveMessage',
                ],
                'Effect': 'Allow',
                'Resource': queue.attr_arn,
                'Principal': {
                  'AWS': [
                    self.account,
                  ],
                },
              },
            ],
          },
        )


