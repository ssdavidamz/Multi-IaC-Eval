from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_autoscaling as autoscaling
import aws_cdk.aws_cloudwatch as cloudwatch
import aws_cdk.aws_ec2 as ec2
from constructs import Construct

"""
  This stack automates the creation of an AWS Auto Scaling group
  using the latest EC2 AMI image using Amazon Linux 2. It also creates
  the related resources like a launch template and security groups

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'latestAmiId': cdk.CfnParameter(self, 'latestAmiId', 
        type = 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default = str(kwargs.get('latestAmiId', '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2')),
        description = 'Region specific image from the Parameter Store',
      ),
      'vpcId': cdk.CfnParameter(self, 'vpcId', 
        type = 'AWS::EC2::VPC::Id',
        default = str(kwargs.get('vpcId')),
        description = 'A VPC ID for the security group',
      ),
      'subnets': cdk.CfnParameter(self, 'subnets', 
        type = 'List<AWS::EC2::Subnet::Id>',
        default = str(kwargs.get('subnets')),
        description = 'A list of subnets for the Auto Scaling group',
      ),
    }

    # Resources
    securityGroup = ec2.CfnSecurityGroup(self, 'SecurityGroup',
          group_description = 'Auto scaling group security group',
          vpc_id = props['vpcId'],
        )

    launchTemplate = ec2.CfnLaunchTemplate(self, 'LaunchTemplate',
          launch_template_name = f"""{self.stack_name}-launch-template""",
          launch_template_data = {
            'imageId': props['latestAmiId'],
            'instanceType': 't3.micro',
            'securityGroupIds': [
              securityGroup.attr_group_id,
            ],
            'metadataOptions': {
              'httpEndpoint': 'disabled',
            },
          },
        )

    autoScalingGroup = autoscaling.CfnAutoScalingGroup(self, 'AutoScalingGroup',
          launch_template = {
            'launchTemplateId': launchTemplate.ref,
            'version': launchTemplate.attr_latest_version_number,
          },
          max_size = '1',
          min_size = '0',
          desired_capacity = '1',
          vpc_zone_identifier = props['subnets'],
        )

    autoScalingGroupScaleDownPolicy = autoscaling.CfnScalingPolicy(self, 'AutoScalingGroupScaleDownPolicy',
          auto_scaling_group_name = autoScalingGroup.ref,
          adjustment_type = 'ChangeInCapacity',
          scaling_adjustment = -1,
          cooldown = '300',
        )

    autoScalingGroupScaleUpPolicy = autoscaling.CfnScalingPolicy(self, 'AutoScalingGroupScaleUpPolicy',
          auto_scaling_group_name = autoScalingGroup.ref,
          adjustment_type = 'ChangeInCapacity',
          scaling_adjustment = 1,
          cooldown = '300',
        )

    autoScalingGroupAlarm = cloudwatch.CfnAlarm(self, 'AutoScalingGroupAlarm',
          alarm_name = f"""{self.stack_name}-alarm""",
          comparison_operator = 'GreaterThanOrEqualToThreshold',
          evaluation_periods = 2,
          metric_name = 'CPUUtilization',
          namespace = 'AWS/EC2',
          period = 300,
          statistic = 'Average',
          threshold = 50,
          actions_enabled = True,
          alarm_actions = [
            autoScalingGroupScaleUpPolicy.ref,
          ],
          dimensions = [
            {
              'name': 'AutoScalingGroupName',
              'value': autoScalingGroup.ref,
            },
          ],
        )


