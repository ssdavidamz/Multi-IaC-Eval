from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_autoscaling as autoscaling
import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_elasticloadbalancing as elasticloadbalancing
import aws_cdk.aws_rds as rds
from constructs import Construct

"""
  AWS CloudFormation Sample Template ELBWithLockedDownAutoScaledInstances: Create a load balanced, Auto Scaled sample website where the instances are locked down to only accept traffic from the load balancer. This example creates an Auto Scaling group behind a load balancer with a simple health check. The web site is available on port 80, however, the instances can be configured to listen on any port (8888 by default). **WARNING** This template creates one or more Amazon EC2 instances and an Elastic Load Balancer. You will be billed for the AWS resources used if you create a stack from this template.
"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'instanceType': kwargs.get('instanceType', 't2.small'),
      'keyName': cdk.CfnParameter(self, 'keyName', 
        type = 'AWS::EC2::KeyPair::KeyName',
        default = str(kwargs.get('keyName')),
        description = 'Name of an existing EC2 KeyPair to enable SSH access to the instances',
      ),
      'sshLocation': kwargs.get('sshLocation', '0.0.0.0/0'),
      'latestAmiId': cdk.CfnParameter(self, 'latestAmiId', 
        type = 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default = str(kwargs.get('latestAmiId', '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2')),
      ),
    }

    # Mappings
    region2Examples = {
      'us-east-1': {
        'Examples': 'https://s3.amazonaws.com/cloudformation-examples-us-east-1',
      },
      'us-west-2': {
        'Examples': 'https://s3-us-west-2.amazonaws.com/cloudformation-examples-us-west-2',
      },
      'us-west-1': {
        'Examples': 'https://s3-us-west-1.amazonaws.com/cloudformation-examples-us-west-1',
      },
      'eu-west-1': {
        'Examples': 'https://s3-eu-west-1.amazonaws.com/cloudformation-examples-eu-west-1',
      },
      'eu-central-1': {
        'Examples': 'https://s3-eu-central-1.amazonaws.com/cloudformation-examples-eu-central-1',
      },
      'ap-southeast-1': {
        'Examples': 'https://s3-ap-southeast-1.amazonaws.com/cloudformation-examples-ap-southeast-1',
      },
      'ap-northeast-1': {
        'Examples': 'https://s3-ap-northeast-1.amazonaws.com/cloudformation-examples-ap-northeast-1',
      },
      'ap-northeast-2': {
        'Examples': 'https://s3-ap-northeast-2.amazonaws.com/cloudformation-examples-ap-northeast-2',
      },
      'ap-southeast-2': {
        'Examples': 'https://s3-ap-southeast-2.amazonaws.com/cloudformation-examples-ap-southeast-2',
      },
      'ap-south-1': {
        'Examples': 'https://s3-ap-south-1.amazonaws.com/cloudformation-examples-ap-south-1',
      },
      'us-east-2': {
        'Examples': 'https://s3-us-east-2.amazonaws.com/cloudformation-examples-us-east-2',
      },
      'sa-east-1': {
        'Examples': 'https://s3-sa-east-1.amazonaws.com/cloudformation-examples-sa-east-1',
      },
      'cn-north-1': {
        'Examples': 'https://s3.cn-north-1.amazonaws.com.cn/cloudformation-examples-cn-north-1',
      },
    }

    # Resources
    databaseInstance = rds.CfnDBInstance(self, 'DatabaseInstance',
          db_instance_identifier = 'mydbinstance',
          allocated_storage = 20,
          db_instance_class = 'db.t2.micro',
          engine = 'MySQL',
          master_username = 'myusername',
          master_user_password = 'mypassword',
        )

    elasticLoadBalancer = elasticloadbalancing.CfnLoadBalancer(self, 'ElasticLoadBalancer',
          availability_zones = cdk.Fn.get_azs(None),
          cross_zone = True,
          listeners = [
            {
              'loadBalancerPort': '80',
              'instancePort': '80',
              'protocol': 'HTTP',
            },
          ],
          health_check = {
            'target': 'HTTP:80/',
            'healthyThreshold': '3',
            'unhealthyThreshold': '5',
            'interval': '30',
            'timeout': '5',
          },
        )

    instanceSecurityGroup = ec2.CfnSecurityGroup(self, 'InstanceSecurityGroup',
          group_description = 'Enable SSH access and HTTP access on the inbound port',
          security_group_ingress = [
            {
              'ipProtocol': 'tcp',
              'fromPort': 80,
              'toPort': 80,
              'sourceSecurityGroupOwnerId': elasticLoadBalancer.attr_source_security_group_owner_alias,
              'sourceSecurityGroupName': elasticLoadBalancer.attr_source_security_group_group_name,
            },
            {
              'ipProtocol': 'tcp',
              'fromPort': 22,
              'toPort': 22,
              'cidrIp': props['sshLocation'],
            },
          ],
        )

    launchConfig = autoscaling.CfnLaunchConfiguration(self, 'LaunchConfig',
          image_id = props['latestAmiId'],
          security_groups = [
            instanceSecurityGroup.ref,
          ],
          instance_type = props['instanceType'],
          key_name = props['keyName'],
          user_data = cdk.Fn.base64(f"""#!/bin/bash -xe          
          yum update -y aws-cfn-bootstrap 
          /opt/aws/bin/cfn-init -v --stack {self.stack_name} \
                   --resource LaunchConfig \
                   --region {self.region}

          /opt/aws/bin/cfn-signal -e $? --stack {self.stack_name} \
                   --resource WebServerGroup \
                   --region {self.region} 
          """),
        )
    launchConfig.cfn_options.metadata = {
      'Comment': 'Install a simple application',
      'AWS::CloudFormation::Init': {
        'config': {
          'packages': {
            'yum': {
              'httpd': [
              ],
            },
          },
          'files': {
            '/var/www/html/index.html': {
              'content': ''.join([
                '<img src=\"',
                region2Examples[self.region]['Examples'],
                '/cloudformation_graphic.png\" alt=\"AWS CloudFormation Logo\"/>',
                '<h1>Congratulations, you have successfully launched the AWS CloudFormation sample.</h1>',
              ]),
              'mode': '000644',
              'owner': 'root',
              'group': 'root',
            },
            '/etc/cfn/cfn-hup.conf': {
              'content': ''.join([
                '[main] ',
                'stack=',
                self.stack_id,
                ' ',
                'region=',
                self.region,
                ' ',
              ]),
              'mode': '000400',
              'owner': 'root',
              'group': 'root',
            },
            '/etc/cfn/hooks.d/cfn-auto-reloader.conf': {
              'content': ''.join([
                '[cfn-auto-reloader-hook] ',
                'triggers=post.update ',
                'path=Resources.LaunchConfig.Metadata.AWS::CloudFormation::Init ',
                'action=/opt/aws/bin/cfn-init -v ',
                '         --stack ',
                self.stack_name,
                '         --resource LaunchConfig ',
                '         --region ',
                self.region,
                ' ',
                'runas=root ',
              ]),
            },
          },
          'services': {
            'sysvinit': {
              'httpd': {
                'enabled': 'true',
                'ensureRunning': 'true',
              },
              'cfn-hup': {
                'enabled': 'true',
                'ensureRunning': 'true',
                'files': [
                  '/etc/cfn/cfn-hup.conf',
                  '/etc/cfn/hooks.d/cfn-auto-reloader.conf',
                ],
              },
            },
          },
        },
      },
    }

    webServerGroup = autoscaling.CfnAutoScalingGroup(self, 'WebServerGroup',
          availability_zones = cdk.Fn.get_azs(None),
          launch_configuration_name = launchConfig.ref,
          min_size = '2',
          max_size = '2',
          load_balancer_names = [
            elasticLoadBalancer.ref,
          ],
        )
    webServerGroup.cfn_options.update_policy = {
      'AutoScalingRollingUpdate': {
        'MinInstancesInService': 1,
        'MaxBatchSize': 1,
        'PauseTime': 'PT15M',
        'WaitOnResourceSignals': True,
      },
    }
    # Outputs
    """
      URL of the website
    """
    self.url = ''.join([
      'http://',
      elasticLoadBalancer.attr_dns_name,
    ])
    cdk.CfnOutput(self, 'CfnOutputURL', 
      key = 'URL',
      description = 'URL of the website',
      value = str(self.url),
    )



