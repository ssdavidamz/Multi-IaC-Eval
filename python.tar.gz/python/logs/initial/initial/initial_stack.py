from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_cloudwatch as cloudwatch
import aws_cdk.aws_logs as logs
from constructs import Construct

"""
  Create all resources associated with CloudWatch logs
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    accountPolicy = logs.CfnAccountPolicy(self, 'AccountPolicy',
          policy_name = 'account-policy',
          policy_type = 'DATA_PROTECTION_POLICY',
          policy_document = '{}',
        )

    anomalyDetector = cloudwatch.CfnAnomalyDetector(self, 'AnomalyDetector',
          metric_name = 'Errors',
          namespace = 'AWS/Lambda',
          stat = 'Sum',
          dimensions = [
            {
              'name': 'FunctionName',
              'value': 'my-function',
            },
          ],
        )

    dashboard = cloudwatch.CfnDashboard(self, 'Dashboard',
          dashboard_name = 'my-dashboard',
          dashboard_body = f"""{{
            "widgets": [
              {{
                "type": "metric",
                "x": 0,
                "y": 0,
                "width": 20,
                "height": 10,
                "properties": {{
                  "view": "timeSeries",
                  "stacked": false,
                  "metrics": [
                    ["AWS/Lambda", "Invocations", "FunctionName", "my-function", {{
                      "period": 3000,
                      "stat": "Sum"
                    }}]
                  ],
                  "region": "{self.region}",
                  "yAxis": {{
                    "left": {{
                      "min": 0
                    }}
                  }}
                }}
              }}
            ]
          }}
          """,
        )

    deliveryDestination = logs.CfnDeliveryDestination(self, 'DeliveryDestination',
          name = 'delivery-dest',
        )

    deliverySource = logs.CfnDeliverySource(self, 'DeliverySource',
          name = 'delivery-source',
        )

    destination = logs.CfnDestination(self, 'Destination',
          destination_name = 'dest1',
          target_arn = 'STRING',
          role_arn = 'STRING',
        )

    durationAlarm = cloudwatch.CfnAlarm(self, 'DurationAlarm',
          alarm_name = 'lambda-alarm',
          alarm_description = 'Alarm if function duration goes over 5s',
          metric_name = 'Duration',
          namespace = 'AWS/Lambda',
          dimensions = [
            {
              'name': 'FunctionName',
              'value': 'my-function',
            },
          ],
          statistic = 'Average',
          period = 600,
          evaluation_periods = 1,
          threshold = 5000,
          comparison_operator = 'GreaterThanThreshold',
        )

    errorAlarm = cloudwatch.CfnAlarm(self, 'ErrorAlarm',
          alarm_name = 'FiveErrors',
          alarm_description = 'Alarm if we see 5 errors in 5 minutes',
          metric_name = 'Errors',
          namespace = 'AWS/Lambda',
          dimensions = [
            {
              'name': 'FunctionName',
              'value': 'my-function',
            },
          ],
          statistic = 'Sum',
          period = 300,
          evaluation_periods = 1,
          threshold = 0,
          comparison_operator = 'GreaterThanThreshold',
        )

    logGroup = logs.CfnLogGroup(self, 'LogGroup',
          log_group_name = 'my-log-group-1',
        )

    metricStream = cloudwatch.CfnMetricStream(self, 'MetricStream',
          firehose_arn = f"""arn:aws:firehose:{self.region}:{self.account}:deliverystream/name""",
          role_arn = f"""arn:aws:iam::{self.account}:role/roleName""",
          output_format = 'json',
        )

    queryDefinition = logs.CfnQueryDefinition(self, 'QueryDefinition',
          name = 'query-1',
          query_string = '@timestamp',
        )

    resourcePolicy = logs.CfnResourcePolicy(self, 'ResourcePolicy',
          policy_name = 'resource-policy-1',
          policy_document = '{}',
        )

    compositeAlarm = cloudwatch.CfnCompositeAlarm(self, 'CompositeAlarm',
          alarm_rule = f"""ALARM({errorAlarm.ref}) AND ALARM({durationAlarm.ref})""",
          alarm_actions = [
            f"""arn:aws:sns:{self.region}:{self.account}:my-alarm-topic""",
          ],
        )

    delivery = logs.CfnDelivery(self, 'Delivery',
          delivery_source_name = deliverySource.ref,
          delivery_destination_arn = deliveryDestination.attr_arn,
        )

    insightRule = cloudwatch.CfnInsightRule(self, 'InsightRule',
          rule_state = 'ENABLED',
          rule_body = f"""{{
            "Schema": {{
                "Name": "CloudWatchLogRule",
                "Version": 1
            }},
            "LogGroupNames": [
              "{logGroup.ref}"
            ],
            "LogFormat": "JSON",
            "Contribution": {{
                "Keys": [
                    "$.ip"
                ],
                "ValueOf": "$.requestBytes",
                "Filters": [
                    {{
                        "Match": "$.httpMethod",
                        "In": [
                            "PUT"
                        ]
                    }}
                ]
            }},
            "AggregateOn": "Sum"
          }}
          """,
          rule_name = 'rule-1',
        )

    logAnomalyDetector = logs.CfnLogAnomalyDetector(self, 'LogAnomalyDetector',
          anomaly_visibility_time = 30,
          evaluation_frequency = 'ONE_HOUR',
          log_group_arn_list = [
            logGroup.attr_arn,
          ],
        )

    logStream = logs.CfnLogStream(self, 'LogStream',
          log_group_name = logGroup.ref,
        )

    metricFilter = logs.CfnMetricFilter(self, 'MetricFilter',
          log_group_name = logGroup.ref,
          filter_pattern = '[..., maxMemoryLabel=\"Used:\", maxMemory, maxMemoryUnit=GB]',
          metric_transformations = [
            {
              'metricValue': '$maxMemory',
              'metricNamespace': 'lambda-function',
              'metricName': 'MaxMemoryUsedGB',
            },
          ],
        )

    subscriptionFilter = logs.CfnSubscriptionFilter(self, 'SubscriptionFilter',
          destination_arn = 'STRING',
          filter_pattern = 'STRING',
          log_group_name = logGroup.ref,
        )


