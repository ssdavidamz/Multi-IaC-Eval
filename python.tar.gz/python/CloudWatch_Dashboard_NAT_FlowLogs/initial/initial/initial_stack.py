from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_cloudwatch as cloudwatch
from constructs import Construct

"""
  Creates a CloudWatch Dashboard with four CloudWatch Logs Insights log widgets that query VPC flow logs for NAT Gateway, related to https://repost.aws/knowledge-center/vpc-find-traffic-sources-nat-gateway
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    cloudWatchDashboard = cloudwatch.CfnDashboard(self, 'CloudWatchDashboard',
          dashboard_name = f"""{props['natGatewayId']}-Traffic-Dashboard""",
          dashboard_body = f"""{{
            "widgets": [
              {{
                "type": "log",
                "x": 0,
                "y": 0,
                "width": 12,
                "height": 9,
                "properties": {{
                  "query": "SOURCE '{props['logGroupName']}' | fields @timestamp, @message | filter (dstAddr like '{props['natGatewayPrivateIp']}' and isIpv4InSubnet(srcAddr, '{props['vpcCidr']}')) | stats sum(bytes) as bytesTransferred by srcAddr, dstAddr | sort bytesTransferred desc | limit 10",
                  "region": "{self.region}",
                  "stacked": false,
                  "title": "Top 10 - Instances sending most traffic through NAT gateway {props['natGatewayId']}", 
                  "view": "table"
                }}
              }},
              {{
                "type": "log",
                "x": 12,
                "y": 0,
                "width": 12,
                "height": 9,
                "properties": {{
                  "query": "SOURCE '{props['logGroupName']}' | fields @timestamp, @message | filter (dstAddr like '{props['natGatewayPrivateIp']}' and isIpv4InSubnet(srcAddr, '{props['vpcCidr']}')) or (srcAddr like '{props['natGatewayPrivateIp']}' and isIpv4InSubnet(dstAddr, '{props['vpcCidr']}'))| stats sum(bytes) as bytesTransferred by srcAddr, dstAddr | sort bytesTransferred desc | limit 10",
                  "region": "{self.region}",
                  "stacked": false,
                  "title": "Top 10 - Traffic To and from NAT gateway {props['natGatewayId']}",
                  "view": "table"
                }}
              }},
              {{
                "type": "log",
                "x": 0,
                "y": 9,
                "width": 12,
                "height": 9,
                "properties": {{
                  "query": "SOURCE '{props['logGroupName']}' | fields @timestamp, @message | filter (srcAddr like '{props['natGatewayPrivateIp']}' and not isIpv4InSubnet(dstAddr, '{props['vpcCidr']}')) | stats sum(bytes) as bytesTransferred by srcAddr, dstAddr | sort bytesTransferred desc | limit 10",
                  "region": "{self.region}",
                  "stacked": false,
                  "title": "Top 10 - Most often upload communication destinations through NAT Gateway {props['natGatewayId']}",
                  "view": "table"
                }}
              }},
              {{
                "type": "log",
                "x": 12,
                "y": 9,
                "width": 12,
                "height": 9,
                "properties": {{
                  "query": "SOURCE '{props['logGroupName']}' | fields @timestamp, @message | filter (dstAddr like '{props['natGatewayPrivateIp']}' and not isIpv4InSubnet(srcAddr, '{props['vpcCidr']}')) | stats sum(bytes) as bytesTransferred by srcAddr, dstAddr | sort bytesTransferred desc | limit 10",
                  "region": "{self.region}",
                  "stacked": false,
                  "title": "Top 10 - Most often download communication destinations through NAT Gateway {props['natGatewayId']}",
                  "view": "table"
                }}
              }}
            ]
          }}
          """,
        )

    # Outputs
    """
      ARN of the created CloudWatch Dashboard
    """
    self.dashboard_arn = cloudWatchDashboard.ref
    cdk.CfnOutput(self, 'CfnOutputDashboardArn', 
      key = 'DashboardArn',
      description = 'ARN of the created CloudWatch Dashboard',
      value = str(self.dashboard_arn),
    )



