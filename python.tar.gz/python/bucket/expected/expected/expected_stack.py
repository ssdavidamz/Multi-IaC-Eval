from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_iam as iam
import aws_cdk.aws_s3 as s3
from constructs import Construct

"""
  Create a secure bucket that passes security scanning checks.
  Also create a bucket to store replicas, and an access log bucket.

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    logBucket = s3.CfnBucket(self, 'LogBucket',
          bucket_name = f"""{props['resourceNamePrefix']}-logs-{self.region}-{self.account}""",
          versioning_configuration = {
            'status': 'Enabled',
          },
          bucket_encryption = {
            'serverSideEncryptionConfiguration': [
              {
                'serverSideEncryptionByDefault': {
                  'sseAlgorithm': 'AES256',
                },
              },
            ],
          },
          public_access_block_configuration = {
            'blockPublicAcls': True,
            'blockPublicPolicy': True,
            'ignorePublicAcls': True,
            'restrictPublicBuckets': True,
          },
          object_lock_enabled = True,
          object_lock_configuration = {
            'objectLockEnabled': 'Enabled',
            'rule': {
              'defaultRetention': {
                'mode': 'COMPLIANCE',
                'days': 30,
              },
            },
          },
        )
    logBucket.cfn_options.metadata = {
      'Comment': 'This bucket records access logs for MyBucket',
      'cfn_nag': {
        'rules_to_suppress': [
          {
            'id': 'W35',
            'reason': 'This is the log bucket',
          },
          {
            'id': 'W51',
            'reason': 'Will be added by the consumer',
          },
        ],
      },
      'guard': {
        'SuppressedRules': [
          'S3_BUCKET_LOGGING_ENABLED',
          'S3_BUCKET_REPLICATION_ENABLED',
        ],
      },
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_18',
            'comment': 'This is the log bucket',
          },
        ],
      },
    }

    replicaBucket = s3.CfnBucket(self, 'ReplicaBucket',
          bucket_name = f"""{props['resourceNamePrefix']}-replicas-{self.region}-{self.account}""",
          versioning_configuration = {
            'status': 'Enabled',
          },
          bucket_encryption = {
            'serverSideEncryptionConfiguration': [
              {
                'serverSideEncryptionByDefault': {
                  'sseAlgorithm': 'AES256',
                },
              },
            ],
          },
          public_access_block_configuration = {
            'blockPublicAcls': True,
            'blockPublicPolicy': True,
            'ignorePublicAcls': True,
            'restrictPublicBuckets': True,
          },
          object_lock_enabled = False,
        )
    replicaBucket.cfn_options.metadata = {
      'Comment': 'This bucket is used as a target for replicas from the main source bucket',
      'guard': {
        'SuppressedRules': [
          'S3_BUCKET_DEFAULT_LOCK_ENABLED',
          'S3_BUCKET_REPLICATION_ENABLED',
          'S3_BUCKET_LOGGING_ENABLED',
        ],
      },
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_18',
            'comment': 'This is the replica bucket',
          },
        ],
      },
    }

    replicationRole = iam.CfnRole(self, 'ReplicationRole',
          assume_role_policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    's3.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          path = '/',
        )
    replicationRole.cfn_options.metadata = {
      'Comment': 'An IAM role that is used for replication objects from one bucket to another',
    }

    myBucket = s3.CfnBucket(self, 'MyBucket',
          bucket_name = f"""{props['resourceNamePrefix']}-source-{self.region}-{self.account}""",
          versioning_configuration = {
            'status': 'Enabled',
          },
          logging_configuration = {
            'destinationBucketName': logBucket.ref,
          },
          bucket_encryption = {
            'serverSideEncryptionConfiguration': [
              {
                'serverSideEncryptionByDefault': {
                  'sseAlgorithm': 'AES256',
                },
              },
            ],
          },
          public_access_block_configuration = {
            'blockPublicAcls': True,
            'blockPublicPolicy': True,
            'ignorePublicAcls': True,
            'restrictPublicBuckets': True,
          },
          object_lock_enabled = False,
          replication_configuration = {
            'role': replicationRole.attr_arn,
            'rules': [
              {
                'destination': {
                  'bucket': replicaBucket.attr_arn,
                },
                'status': 'Enabled',
              },
            ],
          },
        )
    myBucket.cfn_options.metadata = {
      'Comment': 'A secure bucket that passes security scanning checks',
      'guard': {
        'SuppressedRules': [
          'S3_BUCKET_DEFAULT_LOCK_ENABLED',
        ],
      },
    }

    replicationPolicy = iam.CfnPolicy(self, 'ReplicationPolicy',
          policy_name = 'bucket-replication-policy',
          roles = [
            replicationRole.ref,
          ],
          policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Effect': 'Allow',
                'Action': [
                  's3:GetReplicationConfiguration',
                  's3:ListBucket',
                ],
                'Resource': f"""arn:aws:s3:::{props['resourceNamePrefix']}-source-{self.region}-{self.account}""",
              },
              {
                'Effect': 'Allow',
                'Action': [
                  's3:GetObjectVersionForReplication',
                  's3:GetObjectVersionAcl',
                  's3:GetObjectVersionTagging',
                ],
                'Resource': f"""arn:aws:s3:::{props['resourceNamePrefix']}-source-{self.region}-{self.account}/*""",
              },
              {
                'Effect': 'Allow',
                'Action': [
                  's3:ReplicateObject',
                  's3:ReplicateDelete',
                  's3:ReplicationTags',
                ],
                'Resource': f"""arn:aws:s3:::{props['resourceNamePrefix']}-replicas-{self.region}-{self.account}/*""",
              },
            ],
          },
        )
    replicationPolicy.cfn_options.metadata = {
      'Comment': 'An IAM policy to be used for bucket replication',
    }


