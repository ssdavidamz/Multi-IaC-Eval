from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_route53resolver as route53resolver
import aws_cdk.aws_s3 as s3
from constructs import Construct

"""
  Create a VPC with 2 subnets for Inbound and Outbound Route 53 Resolvers

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    logsBucket = s3.CfnBucket(self, 'LogsBucket',
          bucket_name = 'r53-resolver-logs-bucket',
          versioning_configuration = {
            'status': 'Enabled',
          },
        )

    vpc = ec2.CfnVPC(self, 'VPC',
          cidr_block = '10.0.0.0/24',
          enable_dns_hostnames = True,
          enable_dns_support = True,
          instance_tenancy = 'default',
        )

    r53sg = ec2.CfnSecurityGroup(self, 'R53SG',
          group_description = 'R53-Outbound-Resolver-Security-Group',
          group_name = 'R53-Outbound-Resolver-Security-Group',
          security_group_egress = [
            {
              'description': 'DNS Access',
              'fromPort': 53,
              'ipProtocol': 'udp',
              'cidrIp': '0.0.0.0/0',
              'toPort': 53,
            },
            {
              'description': 'DNS Access',
              'fromPort': 53,
              'ipProtocol': 'udp',
              'cidrIp': '0.0.0.0/0',
              'toPort': 53,
            },
          ],
          security_group_ingress = [
            {
              'description': 'DNS',
              'fromPort': 53,
              'ipProtocol': 'tcp',
              'cidrIp': vpc.attr_cidr_block,
              'toPort': 53,
            },
            {
              'description': 'DNS',
              'fromPort': 53,
              'ipProtocol': 'udp',
              'cidrIp': vpc.attr_cidr_block,
              'toPort': 53,
            },
          ],
          vpc_id = vpc.ref,
        )

    vpcSubnet1 = ec2.CfnSubnet(self, 'VPCSubnet1',
          availability_zone = cdk.Fn.select(0, cdk.Fn.get_azs(self.region)),
          cidr_block = cdk.Fn.select(0, cdk.Fn.cidr(vpc.attr_cidr_block, 2, str(6))),
          map_public_ip_on_launch = False,
          vpc_id = vpc.ref,
        )

    vpcSubnet2 = ec2.CfnSubnet(self, 'VPCSubnet2',
          availability_zone = cdk.Fn.select(1, cdk.Fn.get_azs(self.region)),
          cidr_block = cdk.Fn.select(1, cdk.Fn.cidr(vpc.attr_cidr_block, 2, str(6))),
          map_public_ip_on_launch = False,
          vpc_id = vpc.ref,
        )

    r53rInbound = route53resolver.CfnResolverEndpoint(self, 'R53RInbound',
          direction = 'INBOUND',
          ip_addresses = [
            {
              'subnetId': vpcSubnet1.ref,
            },
            {
              'subnetId': vpcSubnet2.ref,
            },
          ],
          name = 'R53-Inbound-Resolver',
          security_group_ids = [
            r53sg.ref,
          ],
        )

    r53rrOutbound = route53resolver.CfnResolverEndpoint(self, 'R53RROutbound',
          direction = 'OUTBOUND',
          ip_addresses = [
            {
              'subnetId': vpcSubnet1.ref,
            },
            {
              'subnetId': vpcSubnet2.ref,
            },
          ],
          name = 'R53-Outbound-Resolver',
          security_group_ids = [
            r53sg.ref,
          ],
        )

    rr53RuleMad = route53resolver.CfnResolverRule(self, 'RR53RuleMAD',
          name = 'R53-Rule-Test',
          domain_name = 'aws.amazon.com',
          resolver_endpoint_id = r53rrOutbound.ref,
          rule_type = 'FORWARD',
          target_ips = [
            {
              'ip': '10.0.0.10',
            },
          ],
        )

    rr53rrAssocMad = route53resolver.CfnResolverRuleAssociation(self, 'RR53RRAssocMad',
          resolver_rule_id = rr53RuleMad.ref,
          vpc_id = vpc.ref,
        )


