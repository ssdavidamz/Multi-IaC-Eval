from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_ec2 as ec2
from constructs import Construct

"""
  This template deploys a VPC, with a pair of public and private subnets spread across two Availability Zones. It uses a static AZ Mapping known as RegionMap to ensure that your resources persist in a given Availability Zone if we add or remove zones
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'vpcCidr': kwargs.get('vpcCidr', '10.192.0.0/16'),
      'publicSubnet1Cidr': kwargs.get('publicSubnet1Cidr', '10.192.10.0/24'),
      'publicSubnet2Cidr': kwargs.get('publicSubnet2Cidr', '10.192.11.0/24'),
      'privateSubnet1Cidr': kwargs.get('privateSubnet1Cidr', '10.192.20.0/24'),
      'privateSubnet2Cidr': kwargs.get('privateSubnet2Cidr', '10.192.21.0/24'),
    }

    # Mappings
    regionMap = {
      'us-east-1': {
        'AZs': ['us-east-1a','us-east-1b','us-east-1c'],
      },
      'us-west-2': {
        'AZs': ['us-west-2a','us-west-2b','us-west-2c'],
      },
    }

    # Resources
    internetGateway = ec2.CfnInternetGateway(self, 'InternetGateway',
        )

    vpc = ec2.CfnVPC(self, 'VPC',
          cidr_block = props['vpcCidr'],
          enable_dns_support = True,
          enable_dns_hostnames = True,
        )

    internetGatewayAttachment = ec2.CfnVPCGatewayAttachment(self, 'InternetGatewayAttachment',
          internet_gateway_id = internetGateway.ref,
          vpc_id = vpc.ref,
        )

    noIngressSecurityGroup = ec2.CfnSecurityGroup(self, 'NoIngressSecurityGroup',
          group_name = 'no-ingress-sg',
          group_description = 'Security group with no ingress rule',
          vpc_id = vpc.ref,
        )

    privateRouteTable1 = ec2.CfnRouteTable(self, 'PrivateRouteTable1',
          vpc_id = vpc.ref,
        )

    privateRouteTable2 = ec2.CfnRouteTable(self, 'PrivateRouteTable2',
          vpc_id = vpc.ref,
        )

    privateSubnet1 = ec2.CfnSubnet(self, 'PrivateSubnet1',
          vpc_id = vpc.ref,
          availability_zone = cdk.Fn.select(0, regionMap[self.region]['AZs']),
          cidr_block = props['privateSubnet1Cidr'],
          map_public_ip_on_launch = False,
        )

    privateSubnet2 = ec2.CfnSubnet(self, 'PrivateSubnet2',
          vpc_id = vpc.ref,
          availability_zone = cdk.Fn.select(1, regionMap[self.region]['AZs']),
          cidr_block = props['privateSubnet2Cidr'],
          map_public_ip_on_launch = False,
        )

    publicRouteTable = ec2.CfnRouteTable(self, 'PublicRouteTable',
          vpc_id = vpc.ref,
        )

    publicSubnet1 = ec2.CfnSubnet(self, 'PublicSubnet1',
          vpc_id = vpc.ref,
          availability_zone = cdk.Fn.select(0, regionMap[self.region]['AZs']),
          cidr_block = props['publicSubnet1Cidr'],
          map_public_ip_on_launch = True,
        )

    publicSubnet2 = ec2.CfnSubnet(self, 'PublicSubnet2',
          vpc_id = vpc.ref,
          availability_zone = cdk.Fn.select(1, regionMap[self.region]['AZs']),
          cidr_block = props['publicSubnet2Cidr'],
          map_public_ip_on_launch = True,
        )

    defaultPublicRoute = ec2.CfnRoute(self, 'DefaultPublicRoute',
          route_table_id = publicRouteTable.ref,
          destination_cidr_block = '0.0.0.0/0',
          gateway_id = internetGateway.ref,
        )
    defaultPublicRoute.add_dependency(internetGatewayAttachment)

    natGateway1Eip = ec2.CfnEIP(self, 'NatGateway1EIP',
          domain = 'vpc',
        )
    natGateway1Eip.add_dependency(internetGatewayAttachment)

    natGateway2Eip = ec2.CfnEIP(self, 'NatGateway2EIP',
          domain = 'vpc',
        )
    natGateway2Eip.add_dependency(internetGatewayAttachment)

    privateSubnet1RouteTableAssociation = ec2.CfnSubnetRouteTableAssociation(self, 'PrivateSubnet1RouteTableAssociation',
          route_table_id = privateRouteTable1.ref,
          subnet_id = privateSubnet1.ref,
        )

    privateSubnet2RouteTableAssociation = ec2.CfnSubnetRouteTableAssociation(self, 'PrivateSubnet2RouteTableAssociation',
          route_table_id = privateRouteTable2.ref,
          subnet_id = privateSubnet2.ref,
        )

    publicSubnet1RouteTableAssociation = ec2.CfnSubnetRouteTableAssociation(self, 'PublicSubnet1RouteTableAssociation',
          route_table_id = publicRouteTable.ref,
          subnet_id = publicSubnet1.ref,
        )

    publicSubnet2RouteTableAssociation = ec2.CfnSubnetRouteTableAssociation(self, 'PublicSubnet2RouteTableAssociation',
          route_table_id = publicRouteTable.ref,
          subnet_id = publicSubnet2.ref,
        )

    natGateway1 = ec2.CfnNatGateway(self, 'NatGateway1',
          allocation_id = natGateway1Eip.attr_allocation_id,
          subnet_id = publicSubnet1.ref,
        )

    natGateway2 = ec2.CfnNatGateway(self, 'NatGateway2',
          allocation_id = natGateway2Eip.attr_allocation_id,
          subnet_id = publicSubnet2.ref,
        )

    defaultPrivateRoute1 = ec2.CfnRoute(self, 'DefaultPrivateRoute1',
          route_table_id = privateRouteTable1.ref,
          destination_cidr_block = '0.0.0.0/0',
          nat_gateway_id = natGateway1.ref,
        )

    defaultPrivateRoute2 = ec2.CfnRoute(self, 'DefaultPrivateRoute2',
          route_table_id = privateRouteTable2.ref,
          destination_cidr_block = '0.0.0.0/0',
          nat_gateway_id = natGateway2.ref,
        )


