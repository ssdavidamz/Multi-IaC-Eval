from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_dms as dms
import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_iam as iam
import aws_cdk.aws_rds as rds
import aws_cdk.aws_s3 as s3
from constructs import Construct

"""
  This CloudFormation sample template DMSAuroraToS3FullLoadAndOngoingReplication creates an Aurora RDS instance and DMS instance in a VPC, and an S3 bucket. The Aurora RDS instance is configured as the DMS Source Endpoint and the S3 bucket is configured as the DMS Target Endpoint. A DMS task is created and configured to migrate existing data and replicate ongoing changes from the source endpoint to the target endpoint. You will be billed for the AWS resources used if you create a stack from this template.
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'clientIp': kwargs.get('clientIp', '0.0.0.0/0'),
      'existsDmsvpcRole': kwargs.get('existsDmsvpcRole', 'N'),
      'existsDmsCloudwatchRole': kwargs.get('existsDmsCloudwatchRole', 'N'),
      'snapshotIdentifier': kwargs.get('snapshotIdentifier', 'arn:aws:rds:us-east-1:01234567890123:cluster-snapshot:dms-sampledb-snapshot'),
    }

    # Conditions
    not_exists_dms_cloudwatch_role = props['existsDmsCloudwatchRole'] == 'N'
    not_exists_dmsvpc_role = props['existsDmsvpcRole'] == 'N'

    # Resources
    dmsCloudwatchRole = iam.CfnRole(self, 'DMSCloudwatchRole',
          role_name = 'dms-cloudwatch-logs-role',
          assume_role_policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'dms.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          managed_policy_arns = [
            'arn:aws:iam::aws:policy/service-role/AmazonDMSCloudWatchLogsRole',
          ],
          path = '/',
        ) if not_exists_dms_cloudwatch_role else None
    if (dmsCloudwatchRole is not None):

    dmsVpcRole = iam.CfnRole(self, 'DMSVpcRole',
          role_name = 'dms-vpc-role',
          assume_role_policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'dms.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          managed_policy_arns = [
            'arn:aws:iam::aws:policy/service-role/AmazonDMSVPCManagementRole',
          ],
          path = '/',
        ) if not_exists_dmsvpc_role else None
    if (dmsVpcRole is not None):

    internetGateway = ec2.CfnInternetGateway(self, 'InternetGateway',
          tags = [
            {
              'key': 'Application',
              'value': self.stack_id,
            },
          ],
        )

    s3Bucket = s3.CfnBucket(self, 'S3Bucket',
          bucket_encryption = {
            'serverSideEncryptionConfiguration': [
              {
                'serverSideEncryptionByDefault': {
                  'sseAlgorithm': 'AES256',
                },
              },
            ],
          },
          public_access_block_configuration = {
            'blockPublicAcls': True,
            'blockPublicPolicy': True,
            'ignorePublicAcls': True,
            'restrictPublicBuckets': True,
          },
        )
    s3Bucket.cfn_options.metadata = {
      'guard': {
        'SuppressedRules': [
          'S3_BUCKET_DEFAULT_LOCK_ENABLED',
          'S3_BUCKET_VERSIONING_ENABLED',
          'S3_BUCKET_REPLICATION_ENABLED',
          'S3_BUCKET_LOGGING_ENABLED',
        ],
      },
    }

    vpc = ec2.CfnVPC(self, 'VPC',
          cidr_block = '10.0.0.0/24',
          enable_dns_support = True,
          enable_dns_hostnames = True,
          tags = [
            {
              'key': 'Application',
              'value': self.stack_id,
            },
            {
              'key': 'Name',
              'value': self.stack_name,
            },
          ],
        )

    attachGateway = ec2.CfnVPCGatewayAttachment(self, 'AttachGateway',
          vpc_id = vpc.ref,
          internet_gateway_id = internetGateway.ref,
        )

    auroraSecurityGroup = ec2.CfnSecurityGroup(self, 'AuroraSecurityGroup',
          group_description = 'Security group for Aurora SampleDB DB Instance',
          group_name = 'Aurora SampleDB Security Group',
          vpc_id = vpc.ref,
          security_group_ingress = [
            {
              'ipProtocol': 'tcp',
              'fromPort': 3306,
              'toPort': 3306,
              'cidrIp': props['clientIp'],
            },
            {
              'ipProtocol': 'tcp',
              'fromPort': 3306,
              'toPort': 3306,
              'cidrIp': '10.0.0.0/24',
            },
          ],
        )

    dbSubnet1 = ec2.CfnSubnet(self, 'DBSubnet1',
          vpc_id = vpc.ref,
          cidr_block = '10.0.0.0/26',
          availability_zone = cdk.Fn.select(0, cdk.Fn.get_azs(None)),
          tags = [
            {
              'key': 'Application',
              'value': self.stack_id,
            },
          ],
        )

    dbSubnet2 = ec2.CfnSubnet(self, 'DBSubnet2',
          vpc_id = vpc.ref,
          cidr_block = '10.0.0.64/26',
          availability_zone = cdk.Fn.select(1, cdk.Fn.get_azs(None)),
          tags = [
            {
              'key': 'Application',
              'value': self.stack_id,
            },
          ],
        )

    dmsSecurityGroup = ec2.CfnSecurityGroup(self, 'DMSSecurityGroup',
          group_description = 'Security group for DMS Instance',
          group_name = 'DMS Demo Security Group',
          vpc_id = vpc.ref,
        )

    routeTable = ec2.CfnRouteTable(self, 'RouteTable',
          vpc_id = vpc.ref,
          tags = [
            {
              'key': 'Application',
              'value': self.stack_id,
            },
          ],
        )

    s3TargetDmsRole = iam.CfnRole(self, 'S3TargetDMSRole',
          role_name = 'dms-s3-target-role',
          assume_role_policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'dms.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          path = '/',
          policies = [
            {
              'policyName': 'S3AccessForDMSPolicy',
              'policyDocument': {
                'Version': '2012-10-17',
                'Statement': [
                  {
                    'Effect': 'Allow',
                    'Action': [
                      's3:PutObject',
                      's3:DeleteObject',
                    ],
                    'Resource': [
                      s3Bucket.attr_arn,
                      f"""{s3Bucket.attr_arn}/*""",
                    ],
                  },
                  {
                    'Effect': 'Allow',
                    'Action': 's3:ListBucket',
                    'Resource': s3Bucket.attr_arn,
                  },
                ],
              },
            },
          ],
        )
    s3TargetDmsRole.add_dependency(s3Bucket)

    auroraDbSubnetGroup = rds.CfnDBSubnetGroup(self, 'AuroraDBSubnetGroup',
          db_subnet_group_description = 'Subnets available for the Aurora SampleDB DB Instance',
          subnet_ids = [
            dbSubnet1.ref,
            dbSubnet2.ref,
          ],
        )

    dmsReplicationSubnetGroup = dms.CfnReplicationSubnetGroup(self, 'DMSReplicationSubnetGroup',
          replication_subnet_group_description = 'Subnets available for DMS',
          subnet_ids = [
            dbSubnet1.ref,
            dbSubnet2.ref,
          ],
        )

    route = ec2.CfnRoute(self, 'Route',
          route_table_id = routeTable.ref,
          destination_cidr_block = '0.0.0.0/0',
          gateway_id = internetGateway.ref,
        )
    route.add_dependency(attachGateway)

    subnetRouteTableAssociation = ec2.CfnSubnetRouteTableAssociation(self, 'SubnetRouteTableAssociation',
          subnet_id = dbSubnet1.ref,
          route_table_id = routeTable.ref,
        )

    subnetRouteTableAssociation1 = ec2.CfnSubnetRouteTableAssociation(self, 'SubnetRouteTableAssociation1',
          subnet_id = dbSubnet2.ref,
          route_table_id = routeTable.ref,
        )

    auroraCluster = rds.CfnDBCluster(self, 'AuroraCluster',
          database_name = 'dms_sample',
          backup_retention_period = 7,
          db_subnet_group_name = auroraDbSubnetGroup.ref,
          engine = 'aurora-postgresql',
          snapshot_identifier = props['snapshotIdentifier'],
          vpc_security_group_ids = [
            auroraSecurityGroup.ref,
          ],
          storage_encrypted = True,
        )
    auroraCluster.cfn_options.deletion_policy = cdk.CfnDeletionPolicy.RETAIN

    dmsReplicationInstance = dms.CfnReplicationInstance(self, 'DMSReplicationInstance',
          availability_zone = dbSubnet1.attr_availability_zone,
          publicly_accessible = False,
          replication_instance_class = 'dms.t3.medium',
          replication_instance_identifier = 'aurora-s3-repinstance-sampledb',
          replication_subnet_group_identifier = dmsReplicationSubnetGroup.ref,
          vpc_security_group_ids = [
            dmsSecurityGroup.ref,
          ],
        )
    dmsReplicationInstance.add_dependency(dmsReplicationSubnetGroup)
    dmsReplicationInstance.add_dependency(dmsSecurityGroup)

    auroraDb = rds.CfnDBInstance(self, 'AuroraDB',
          db_cluster_identifier = auroraCluster.ref,
          db_instance_class = 'db.t3.medium',
          db_instance_identifier = 'dms-sample',
          db_subnet_group_name = auroraDbSubnetGroup.ref,
          engine = 'aurora-postgresql',
          multi_az = False,
          publicly_accessible = False,
          tags = [
            {
              'key': 'Application',
              'value': self.stack_id,
            },
          ],
        )
    auroraDb.cfn_options.metadata = {
      'guard': {
        'SuppressedRules': [
          'DB_INSTANCE_BACKUP_ENABLED',
          'RDS_SNAPSHOT_ENCRYPTED',
          'RDS_STORAGE_ENCRYPTED',
        ],
      },
    }
    auroraDb.cfn_options.deletion_policy = cdk.CfnDeletionPolicy.RETAIN
    auroraDb.add_dependency(auroraCluster)

    s3TargetEndpoint = dms.CfnEndpoint(self, 'S3TargetEndpoint',
          endpoint_type = 'target',
          engine_name = 'S3',
          extra_connection_attributes = 'addColumnName=true',
          s3_settings = {
            'bucketName': s3Bucket.ref,
            'serviceAccessRoleArn': s3TargetDmsRole.attr_arn,
          },
        )
    s3TargetEndpoint.add_dependency(dmsReplicationInstance)
    s3TargetEndpoint.add_dependency(s3Bucket)
    s3TargetEndpoint.add_dependency(s3TargetDmsRole)

    auroraSourceEndpoint = dms.CfnEndpoint(self, 'AuroraSourceEndpoint',
          endpoint_type = 'source',
          engine_name = 'AURORA',
          password = '{{resolve:secretsmanager:aurora-source-enpoint-password:SecretString:password}}',
          port = 3306,
          server_name = auroraCluster.attr_endpoint_address,
          username = 'admin',
        )
    auroraSourceEndpoint.add_dependency(dmsReplicationInstance)
    auroraSourceEndpoint.add_dependency(auroraCluster)
    auroraSourceEndpoint.add_dependency(auroraDb)

    dmsReplicationTask = dms.CfnReplicationTask(self, 'DMSReplicationTask',
          migration_type = 'full-load-and-cdc',
          replication_instance_arn = dmsReplicationInstance.ref,
          replication_task_settings = '{ \"Logging\" : { \"EnableLogging\" : true, \"LogComponents\": [ { \"Id\" : \"SOURCE_UNLOAD\", \"Severity\" : \"LOGGER_SEVERITY_DEFAULT\" }, { \"Id\" : \"SOURCE_CAPTURE\", \"Severity\" : \"LOGGER_SEVERITY_DEFAULT\" }, { \"Id\" : \"TARGET_LOAD\", \"Severity\" : \"LOGGER_SEVERITY_DEFAULT\" }, { \"Id\" : \"TARGET_APPLY\", \"Severity\" : \"LOGGER_SEVERITY_DEFAULT\" } ] } }',
          source_endpoint_arn = auroraSourceEndpoint.ref,
          table_mappings = '{ \"rules\": [ { \"rule-type\" : \"selection\", \"rule-id\" : \"1\", \"rule-name\" : \"1\", \"object-locator\" : { \"schema-name\" : \"dms_sample\", \"table-name\" : \"%\" }, \"rule-action\" : \"include\" } ] }',
          target_endpoint_arn = s3TargetEndpoint.ref,
        )
    dmsReplicationTask.add_dependency(auroraSourceEndpoint)
    dmsReplicationTask.add_dependency(s3TargetEndpoint)
    dmsReplicationTask.add_dependency(dmsReplicationInstance)

    # Outputs
    self.stack_name = self.stack_name
    cdk.CfnOutput(self, 'CfnOutputStackName', 
      key = 'StackName',
      value = str(self.stack_name),
    )

    self.region_name = self.region
    cdk.CfnOutput(self, 'CfnOutputRegionName', 
      key = 'RegionName',
      value = str(self.region_name),
    )

    self.s3_bucket_name = s3Bucket.ref
    cdk.CfnOutput(self, 'CfnOutputS3BucketName', 
      key = 'S3BucketName',
      value = str(self.s3_bucket_name),
    )

    self.aurora_endpoint = auroraCluster.attr_endpoint_address
    cdk.CfnOutput(self, 'CfnOutputAuroraEndpoint', 
      key = 'AuroraEndpoint',
      value = str(self.aurora_endpoint),
    )



