from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_apigateway as apigateway
import aws_cdk.aws_dynamodb as dynamodb
import aws_cdk.aws_iam as iam
import aws_cdk.aws_lambda as aws_lambda
import aws_cdk.aws_logs as logs
from constructs import Construct

"""
  This template deploys a Lambda function and an API Gateway to implement 
  a basic REST API.

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    restApi = apigateway.CfnRestApi(self, 'RestApi',
          name = f"""{props['resourceNamePrefix']}-api""",
        )
    restApi.cfn_options.metadata = {
      'Comment': 'An API Gateway REST API',
    }

    restApiAccessLog = logs.CfnLogGroup(self, 'RestApiAccessLog',
          log_group_name = f"""/aws/lambda/{props['resourceNamePrefix']}-rest-api-access""",
          retention_in_days = 90,
        )
    restApiAccessLog.cfn_options.metadata = {
      'Comment': 'A log group for the rest api function access logs',
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_158',
            'commment': 'Log groups are encrypted by default',
          },
        ],
      },
      'guard': {
        'SuppressedRules': [
          'CLOUDWATCH_LOG_GROUP_ENCRYPTED',
        ],
        'Comments': [
          'CloudWatch log groups are encrypted by default',
        ],
      },
    }

    restApiCloudWatchRole = iam.CfnRole(self, 'RestApiCloudWatchRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Action': 'sts:AssumeRole',
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'apigateway.amazonaws.com',
                    'lambda.amazonaws.com',
                  ],
                },
              },
            ],
          },
          path = '/',
        )
    restApiCloudWatchRole.cfn_options.metadata = {
      'Comment': 'A role that allows the API Gateway REST API to log to CloudWatch.\nWe set this to retain to prevent an issue with the Account resource \nbeing a singleton that could result in the role being deleted for\na separately configured API. Ideally this role would be created \nseparately and referenced from this template and others like it.\n',
    }
    restApiCloudWatchRole.cfn_options.deletion_policy = cdk.CfnDeletionPolicy.RETAIN

    restApiDynamoDbTable = dynamodb.CfnTable(self, 'RestApiDynamoDBTable',
          table_name = f"""{props['resourceNamePrefix']}-rest-api-table""",
          attribute_definitions = [
            {
              'attributeName': 'id',
              'attributeType': 'S',
            },
          ],
          key_schema = [
            {
              'attributeName': 'id',
              'keyType': 'HASH',
            },
          ],
          provisioned_throughput = {
            'readCapacityUnits': 5,
            'writeCapacityUnits': 5,
          },
        )

    restFunctionLogGroup = logs.CfnLogGroup(self, 'RestFunctionLogGroup',
          log_group_name = f"""/aws/lambda/{props['resourceNamePrefix']}-rest-api""",
          retention_in_days = 90,
        )
    restFunctionLogGroup.cfn_options.metadata = {
      'Comment': 'A log group for the rest api function',
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_158',
            'commment': 'Log groups are encrypted by default',
          },
        ],
      },
      'guard': {
        'SuppressedRules': [
          'CLOUDWATCH_LOG_GROUP_ENCRYPTED',
        ],
        'Comments': [
          'CloudWatch log groups are encrypted by default',
        ],
      },
    }

    restFunctionRole = iam.CfnRole(self, 'RestFunctionRole',
          role_name = f"""{props['resourceNamePrefix']}-lambda-exec""",
          assume_role_policy_document = {
            'Statement': [
              {
                'Action': [
                  'sts:AssumeRole',
                ],
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'lambda.amazonaws.com',
                  ],
                },
              },
            ],
            'Version': '2012-10-17',
          },
          managed_policy_arns = [
            'arn:aws:iam::aws:policy/AWSLambdaExecute',
          ],
          path = '/',
        )
    restFunctionRole.cfn_options.metadata = {
      'Comment': 'An execution role for the REST API Lambda function',
    }

    restApiCloudWatchPolicy = iam.CfnPolicy(self, 'RestApiCloudWatchPolicy',
          policy_name = 'cwlogsapigateway',
          policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Action': [
                  'logs:CreateLogGroup',
                  'logs:CreateLogStream',
                  'logs:DescribeLogGroups',
                  'logs:DescribeLogStreams',
                  'logs:PutLogEvents',
                  'logs:GetLogEvents',
                  'logs:FilterLogEvents',
                ],
                'Effect': 'Allow',
                'Resource': '*',
              },
            ],
          },
          roles = [
            restApiCloudWatchRole.ref,
          ],
        )
    restApiCloudWatchPolicy.cfn_options.metadata = {
      'Comment': 'A policy that allows the API Gateway REST API to log to CloudWatch.\nNote that we have to use a * for the resource here because this policy \nis attached to a role that is actually a singleton for all gateways \nin the region. Configuring the ::Account resource overwrites the role \nfor any previosly configured gateways.\n',
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_111',
            'comment': 'This policy is a singleton for all gateways, so it needs access to all logs',
          },
        ],
      },
    }
    restApiCloudWatchPolicy.cfn_options.deletion_policy = cdk.CfnDeletionPolicy.RETAIN

    restApiProxy = apigateway.CfnResource(self, 'RestApiProxy',
          parent_id = restApi.attr_root_resource_id,
          path_part = '{proxy+}',
          rest_api_id = restApi.ref,
        )

    restFunction = aws_lambda.CfnFunction(self, 'RestFunction',
          function_name = f"""{props['resourceNamePrefix']}-rest-api""",
          runtime = 'python3.9',
          role = restFunctionRole.attr_arn,
          handler = 'index.handler',
          reserved_concurrent_executions = 100,
          code = {
            'zipFile': 'import boto3\nimport json\ndef handler(event, context):\n  print(event)\n  return {\n      \"statusCode\": 200,\n      \"body\": json.dumps(\'Success\')\n  }\n',
          },
        )
    restFunction.cfn_options.metadata = {
      'Comment': 'A lambda function that implements REST API endpoints',
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_116',
            'comment': 'This function is not called async',
          },
          {
            'id': 'CKV_AWS_117',
            'comment': 'This example does not run in a VPC',
          },
        ],
      },
      'guard': {
        'SuppressedRules': [
          'LAMBDA_INSIDE_VPC',
          'LAMBDA_DLQ_CHECK',
        ],
        'Comments': [
          'This example does not run in a VPC',
          'The function is not called async so a DLQ is not necessary',
        ],
      },
    }
    restFunction.add_dependency(restFunctionLogGroup)

    restFunctionPolicy = iam.CfnPolicy(self, 'RestFunctionPolicy',
          policy_name = 'lambdaexec',
          policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Action': [
                  'logs:CreateLogStream',
                  'logs:PutLogEvents',
                ],
                'Effect': 'Allow',
                'Resource': [
                  f"""arn:aws:logs:{self.region}:{self.account}:log-group:/aws/lambda/{props['resourceNamePrefix']}-rest-api""",
                  f"""arn:aws:logs:{self.region}:{self.account}:log-group:/aws/lambda/{props['resourceNamePrefix']}-rest-api:*""",
                ],
              },
            ],
          },
          roles = [
            f"""{props['resourceNamePrefix']}-lambda-exec""",
          ],
        )
    restFunctionPolicy.cfn_options.metadata = {
      'Comment': 'A policy for the REST API Lambda function role',
    }
    restFunctionPolicy.add_dependency(restFunctionRole)

    restApiAnyProxy = apigateway.CfnMethod(self, 'RestApiANYProxy',
          http_method = 'ANY',
          resource_id = restApiProxy.ref,
          rest_api_id = restApi.ref,
          authorization_type = 'AWS_IAM',
          integration = {
            'integrationHttpMethod': 'POST',
            'type': 'AWS_PROXY',
            'uri': f"""arn:{self.partition}:apigateway:{self.region}:lambda:path/2015-03-31/functions/{restFunction.attr_arn}/invocations""",
          },
        )

    restApiAnyRoot = apigateway.CfnMethod(self, 'RestApiANYRoot',
          http_method = 'ANY',
          resource_id = restApi.attr_root_resource_id,
          rest_api_id = restApi.ref,
          authorization_type = 'AWS_IAM',
          integration = {
            'integrationHttpMethod': 'POST',
            'type': 'AWS_PROXY',
            'uri': f"""arn:{self.partition}:apigateway:{self.region}:lambda:path/2015-03-31/functions/{restFunction.attr_arn}/invocations""",
          },
        )

    restApiAccount = apigateway.CfnAccount(self, 'RestApiAccount',
          cloud_watch_role_arn = restApiCloudWatchRole.attr_arn,
        )
    restApiAccount.cfn_options.metadata = {
      'Comment': 'This is the API Gateway account resource to associate the role with the logs.\nThere is a gotcha with this resource since it\'s actually a singleton for all\ngateways in the account and region. The role will overwrite the role for all \nother gateways, and deleting it will delete it for the others, unless you \nput a retention policy on the role. The redundant DependsOn is required to \nprevent a race condition that causes an error when deploying the stack.\n',
      'cfn-lint': {
        'config': {
          'ignore_checks': [
            'W3005',
          ],
        },
      },
    }
    restApiAccount.add_dependency(restApi)
    restApiAccount.add_dependency(restApiCloudWatchRole)
    restApiAccount.add_dependency(restApiCloudWatchPolicy)

    restApiPermission = aws_lambda.CfnPermission(self, 'RestApiPermission',
          action = 'lambda:InvokeFunction',
          function_name = restFunction.attr_arn,
          principal = 'apigateway.amazonaws.com',
          source_arn = f"""arn:{self.partition}:execute-api:{self.region}:{self.account}:{restApi.ref}/*/*/*""",
        )

    restApiRootPermission = aws_lambda.CfnPermission(self, 'RestApiRootPermission',
          action = 'lambda:InvokeFunction',
          function_name = restFunction.attr_arn,
          principal = 'apigateway.amazonaws.com',
          source_arn = f"""arn:{self.partition}:execute-api:{self.region}:{self.account}:{restApi.ref}/*/*/""",
        )

    restApiDeployment = apigateway.CfnDeployment(self, 'RestApiDeployment',
          rest_api_id = restApi.ref,
        )
    restApiDeployment.add_dependency(restApiAnyProxy)
    restApiDeployment.add_dependency(restApiAnyRoot)

    restApiStage = apigateway.CfnStage(self, 'RestApiStage',
          rest_api_id = restApi.ref,
          deployment_id = restApiDeployment.ref,
          stage_name = 'prod',
          tracing_enabled = True,
          access_log_setting = {
            'destinationArn': restApiAccessLog.attr_arn,
            'format': '$context.identity.sourceIp $context.identity.caller $context.identity.user [$context.requestTime] $context.httpMethod $context.resourcePath $context.protocol $context.status $context.responseLength $context.requestId $context.extendedRequestId',
          },
        )
    restApiStage.cfn_options.metadata = {
      'Comment': 'The API Gateway stage resource',
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_120',
            'comment': 'Caching is not always needed and can increase costs',
          },
        ],
      },
    }


