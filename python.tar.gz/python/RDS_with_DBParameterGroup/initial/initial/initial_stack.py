from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_rds as rds
from constructs import Construct

"""
  Sample template showing how to create an Amazon RDS Database Instance with a
  DBParameterGroup. **WARNING** This template creates an Amazon Relational
  Database Service database instance. You will be billed for the AWS
  resources used if you create a stack from this template.

"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'dbName': kwargs.get('dbName', 'MyDatabase'),
    }

    # Resources
    myRdsParamGroup = rds.CfnDBParameterGroup(self, 'MyRDSParamGroup',
          family = 'MySQL8.0',
          description = 'CloudFormation Sample Database Parameter Group',
          parameters = {
            'autocommit': '1',
            'general_log': '1',
          },
        )

    myDb = rds.CfnDBInstance(self, 'MyDB',
          db_name = props['dbName'],
          allocated_storage = '5',
          db_instance_class = 'db.t3.small',
          backup_retention_period = 7,
          engine = 'MySQL',
          engine_version = '8.0.36',
          master_username = props['dbUser'].value_as_string,
          manage_master_user_password = True,
          db_parameter_group_name = myRdsParamGroup.ref,
          publicly_accessible = False,
          storage_encrypted = True,
        )
    myDb.cfn_options.deletion_policy = cdk.CfnDeletionPolicy.SNAPSHOT

    # Outputs
    """
      JDBC connection string for the database
    """
    self.jdbc_connection_string = ''.join([
      'jdbc:mysql://',
      myDb.attr_endpoint_address,
      ':',
      myDb.attr_endpoint_port,
      '/',
      props['dbName'],
    ])
    cdk.CfnOutput(self, 'CfnOutputJDBCConnectionString', 
      key = 'JDBCConnectionString',
      description = 'JDBC connection string for the database',
      value = str(self.jdbc_connection_string),
    )



