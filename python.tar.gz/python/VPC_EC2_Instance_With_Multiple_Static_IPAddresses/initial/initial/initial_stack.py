from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_ec2 as ec2
from constructs import Construct

"""
  Sample template showing how to create an instance with a single network
  interface and multiple static IP addresses in an existing VPC. It assumes you
  have already created a VPC.  **WARNING** This template creates an Amazon EC2
  instance. You will be billed for the AWS resources used if you create a stack
  from this template.

"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'keyName': cdk.CfnParameter(self, 'keyName', 
        type = 'AWS::EC2::KeyPair::KeyName',
        default = str(kwargs.get('keyName')),
        description = 'Name of an existing EC2 KeyPair to enable SSH access to the instance',
      ),
      'instanceType': kwargs.get('instanceType', 't3.micro'),
      'vpcId': cdk.CfnParameter(self, 'vpcId', 
        type = 'AWS::EC2::VPC::Id',
        default = str(kwargs.get('vpcId')),
        description = 'VpcId of your existing Virtual Private Cloud (VPC)',
      ),
      'subnetId': cdk.CfnParameter(self, 'subnetId', 
        type = 'AWS::EC2::Subnet::Id',
        default = str(kwargs.get('subnetId')),
        description = 'SubnetId of an existing subnet (for the primary network) in your Virtual Private Cloud (VPC)',
      ),
      'sshLocation': kwargs.get('sshLocation', '0.0.0.0/0'),
      'latestAmi': cdk.CfnParameter(self, 'latestAmi', 
        type = 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default = str(kwargs.get('latestAmi', '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2')),
      ),
    }

    # Resources
    eip1 = ec2.CfnEIP(self, 'EIP1',
          domain = 'vpc',
        )

    sshSecurityGroup = ec2.CfnSecurityGroup(self, 'SSHSecurityGroup',
          vpc_id = props['vpcId'],
          group_description = 'Enable SSH access via port 22',
          security_group_ingress = [
            {
              'ipProtocol': 'tcp',
              'fromPort': 22,
              'toPort': 22,
              'cidrIp': props['sshLocation'],
            },
          ],
        )

    eth0 = ec2.CfnNetworkInterface(self, 'Eth0',
          description = 'eth0',
          group_set = [
            sshSecurityGroup.ref,
          ],
          private_ip_addresses = [
            {
              'privateIpAddress': props['primaryIpAddress'],
              'primary': True,
            },
            {
              'privateIpAddress': props['secondaryIpAddress'],
              'primary': False,
            },
          ],
          source_dest_check = True,
          subnet_id = props['subnetId'],
          tags = [
            {
              'key': 'Name',
              'value': 'Interface 0',
            },
            {
              'key': 'Interface',
              'value': 'eth0',
            },
          ],
        )

    ec2Instance = ec2.CfnInstance(self, 'EC2Instance',
          image_id = props['latestAmi'],
          instance_type = props['instanceType'],
          key_name = props['keyName'],
          network_interfaces = [
            {
              'networkInterfaceId': eth0.ref,
              'deviceIndex': '0',
            },
          ],
          tags = [
            {
              'key': 'Name',
              'value': 'myInstance',
            },
          ],
        )
    ec2Instance.cfn_options.metadata = {
      'guard': {
        'SuppressedRules': [
          'EC2_INSTANCES_IN_VPC',
        ],
      },
    }

    eipAssoc1 = ec2.CfnEIPAssociation(self, 'EIPAssoc1',
          network_interface_id = eth0.ref,
          allocation_id = eip1.attr_allocation_id,
        )

    # Outputs
    """
      Instance Id of newly created instance
    """
    self.instance_id = ec2Instance.ref
    cdk.CfnOutput(self, 'CfnOutputInstanceId', 
      key = 'InstanceId',
      description = 'Instance Id of newly created instance',
      value = str(self.instance_id),
    )

    """
      Primary public IP of Eth0
    """
    self.eip1 = ' '.join([
      'IP address',
      eip1.ref,
      'on subnet',
      props['subnetId'],
    ])
    cdk.CfnOutput(self, 'CfnOutputEIP1', 
      key = 'EIP1',
      description = 'Primary public IP of Eth0',
      value = str(self.eip1),
    )

    """
      Primary private IP address of Eth0
    """
    self.primary_private_ip_address = ' '.join([
      'IP address',
      eth0.attr_primary_private_ip_address,
      'on subnet',
      props['subnetId'],
    ])
    cdk.CfnOutput(self, 'CfnOutputPrimaryPrivateIPAddress', 
      key = 'PrimaryPrivateIPAddress',
      description = 'Primary private IP address of Eth0',
      value = str(self.primary_private_ip_address),
    )

    """
      Secondary private IP address of Eth0
    """
    self.secondary_private_ip_addresses = ' '.join([
      'IP address',
      cdk.Fn.select(0, eth0.attr_secondary_private_ip_addresses),
      'on subnet',
      props['subnetId'],
    ])
    cdk.CfnOutput(self, 'CfnOutputSecondaryPrivateIPAddresses', 
      key = 'SecondaryPrivateIPAddresses',
      description = 'Secondary private IP address of Eth0',
      value = str(self.secondary_private_ip_addresses),
    )



