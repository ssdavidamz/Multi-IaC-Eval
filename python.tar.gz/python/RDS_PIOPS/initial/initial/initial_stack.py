from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_rds as rds
import aws_cdk.aws_secretsmanager as secretsmanager
from constructs import Construct

"""
  AWS CloudFormation Sample Template RDS_PIOPS: Sample template showing how to create an Amazon RDS Database Instance with provisioned IOPs.**WARNING** This template creates an Amazon Relational Database Service database instance. You will be billed for the AWS resources used if you create a stack from this template.
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    dbCredential = secretsmanager.CfnSecret(self, 'DBCredential',
          generate_secret_string = {
            'passwordLength': 16,
            'excludeCharacters': '\"@/\\',
            'requireEachIncludedType': True,
          },
        )

    myDb = rds.CfnDBInstance(self, 'myDB',
          allocated_storage = '100',
          db_instance_class = 'db.t3.small',
          backup_retention_period = 7,
          engine = 'MySQL',
          iops = 1000,
          master_username = props['dbUser'].value_as_string,
          master_user_password = f"""{{{{resolve:secretsmanager:{dbCredential.ref}}}}}""",
          publicly_accessible = False,
          storage_encrypted = True,
        )
    myDb.add_dependency(dbCredential)


