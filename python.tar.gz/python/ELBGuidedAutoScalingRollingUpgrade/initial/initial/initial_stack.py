from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_autoscaling as autoscaling
import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_elasticloadbalancing as elasticloadbalancing
import aws_cdk.aws_iam as iam
from constructs import Construct

"""
  AWS CloudFormation Sample Template ELBGuidedAutoScalingRollingUpdates: This example creates an auto scaling group behind a load balancer with a simple health check. The Auto Scaling launch configuration includes an update policy that will keep 2 instances running while doing an autoscaling rolling update. The update will roll forward only when the ELB health check detects an updated instance in-service. **WARNING** This template creates one or more Amazon EC2  instances and an Elastic Load Balancer. You will be billed for the AWS resources used if you create a stack from this template.
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'instanceType': kwargs.get('instanceType', 't2.small'),
      'keyName': cdk.CfnParameter(self, 'keyName', 
        type = 'AWS::EC2::KeyPair::KeyName',
        default = str(kwargs.get('keyName')),
        description = 'Name of an existing EC2 KeyPair to enable SSH access to the instances',
      ),
      'sshLocation': kwargs.get('sshLocation', '192.168.1.0/0'),
      'latestAmiId': cdk.CfnParameter(self, 'latestAmiId', 
        type = 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>',
        default = str(kwargs.get('latestAmiId', '/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2')),
      ),
    }

    # Mappings
    region2Examples = {
      'us-east-1': {
        'Examples': 'https://s3.amazonaws.com/cloudformation-examples-us-east-1',
      },
      'us-west-2': {
        'Examples': 'https://s3-us-west-2.amazonaws.com/cloudformation-examples-us-west-2',
      },
      'us-west-1': {
        'Examples': 'https://s3-us-west-1.amazonaws.com/cloudformation-examples-us-west-1',
      },
      'eu-west-1': {
        'Examples': 'https://s3-eu-west-1.amazonaws.com/cloudformation-examples-eu-west-1',
      },
      'eu-central-1': {
        'Examples': 'https://s3-eu-central-1.amazonaws.com/cloudformation-examples-eu-central-1',
      },
      'ap-southeast-1': {
        'Examples': 'https://s3-ap-southeast-1.amazonaws.com/cloudformation-examples-ap-southeast-1',
      },
      'ap-northeast-1': {
        'Examples': 'https://s3-ap-northeast-1.amazonaws.com/cloudformation-examples-ap-northeast-1',
      },
      'ap-northeast-2': {
        'Examples': 'https://s3-ap-northeast-2.amazonaws.com/cloudformation-examples-ap-northeast-2',
      },
      'ap-southeast-2': {
        'Examples': 'https://s3-ap-southeast-2.amazonaws.com/cloudformation-examples-ap-southeast-2',
      },
      'ap-south-1': {
        'Examples': 'https://s3-ap-south-1.amazonaws.com/cloudformation-examples-ap-south-1',
      },
      'us-east-2': {
        'Examples': 'https://s3-us-east-2.amazonaws.com/cloudformation-examples-us-east-2',
      },
      'sa-east-1': {
        'Examples': 'https://s3-sa-east-1.amazonaws.com/cloudformation-examples-sa-east-1',
      },
      'cn-north-1': {
        'Examples': 'https://s3.cn-north-1.amazonaws.com.cn/cloudformation-examples-cn-north-1',
      },
    }

    # Resources
    describeHealthRole = iam.CfnRole(self, 'DescribeHealthRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'ec2.amazonaws.com',
                  ],
                },
                'Action': [
                  'sts:AssumeRole',
                ],
              },
            ],
          },
          path = '/',
          policies = [
            {
              'policyName': 'describe-instance-health-policy',
              'policyDocument': {
                'Statement': [
                  {
                    'Effect': 'Allow',
                    'Action': [
                      'elasticloadbalancing:DescribeInstanceHealth',
                    ],
                    'Resource': '*',
                  },
                ],
              },
            },
          ],
        )

    elasticLoadBalancer = elasticloadbalancing.CfnLoadBalancer(self, 'ElasticLoadBalancer',
          availability_zones = cdk.Fn.get_azs(None),
          cross_zone = True,
          listeners = [
            {
              'loadBalancerPort': '80',
              'instancePort': '80',
              'protocol': 'HTTP',
            },
          ],
          health_check = {
            'target': 'HTTP:80/',
            'healthyThreshold': '3',
            'unhealthyThreshold': '5',
            'interval': '30',
            'timeout': '5',
          },
        )

    instanceSecurityGroup = ec2.CfnSecurityGroup(self, 'InstanceSecurityGroup',
          group_description = 'Enable SSH access and HTTP access on the configured port',
          security_group_ingress = [
            {
              'ipProtocol': 'tcp',
              'fromPort': 22,
              'toPort': 22,
              'cidrIp': props['sshLocation'],
            },
            {
              'ipProtocol': 'tcp',
              'fromPort': 80,
              'toPort': 80,
              'cidrIp': '0.0.0.0/0',
            },
          ],
        )

    webServerInstanceProfile = iam.CfnInstanceProfile(self, 'WebServerInstanceProfile',
          path = '/',
          roles = [
            describeHealthRole.ref,
          ],
        )

    launchConfig = autoscaling.CfnLaunchConfiguration(self, 'LaunchConfig',
          key_name = props['keyName'],
          image_id = props['latestAmiId'],
          instance_type = props['instanceType'],
          security_groups = [
            instanceSecurityGroup.ref,
          ],
          iam_instance_profile = webServerInstanceProfile.ref,
          user_data = cdk.Fn.base64(f"""#!/bin/bash -xe          
          yum update -y aws-cfn-bootstrap 
          /opt/aws/bin/cfn-init -v --stack {self.stack_name} \
                   --resource LaunchConfig \
                   --configsets full_install \
                   --region {self.region}

          /opt/aws/bin/cfn-signal -e $? --stack {self.stack_name} \
                   --resource WebServerGroup \
                   --region {self.region} 
          """),
        )
    launchConfig.cfn_options.metadata = {
      'AWS::CloudFormation::Init': {
        'configSets': {
          'full_install': [
            'install_cfn',
            'install_app',
            'verify_instance_health',
          ],
        },
        'install_cfn': {
          'files': {
            '/etc/cfn/cfn-hup.conf': {
              'content': ''.join([
                '[main] ',
                'stack=',
                self.stack_id,
                ' ',
                'region=',
                self.region,
                ' ',
              ]),
              'mode': '000400',
              'owner': 'root',
              'group': 'root',
            },
            '/etc/cfn/hooks.d/cfn-auto-reloader.conf': {
              'content': ''.join([
                '[cfn-auto-reloader-hook] ',
                'triggers=post.update ',
                'path=Resources.WebServerInstance.Metadata.AWS::CloudFormation::Init ',
                'action=/opt/aws/bin/cfn-init -v ',
                '         --stack ',
                self.stack_name,
                '         --resource WebServerInstance ',
                '         --configsets full_install ',
                '         --region ',
                self.region,
                ' ',
                'runas=root ',
              ]),
            },
          },
          'services': {
            'sysvinit': {
              'cfn-hup': {
                'enabled': 'true',
                'ensureRunning': 'true',
                'files': [
                  '/etc/cfn/cfn-hup.conf',
                  '/etc/cfn/hooks.d/cfn-auto-reloader.conf',
                ],
              },
            },
          },
        },
        'install_app': {
          'packages': {
            'yum': {
              'httpd': [
              ],
            },
          },
          'files': {
            '/var/www/html/index.html': {
              'content': ''.join([
                '<img src=\"',
                region2Examples[self.region]['Examples'],
                '/cloudformation_graphic.png\" alt=\"AWS CloudFormation Logo\"/>',
                '<h1>Congratulations, you have successfully launched the AWS CloudFormation sample.</h1>',
              ]),
              'mode': '000644',
              'owner': 'root',
              'group': 'root',
            },
          },
          'services': {
            'sysvinit': {
              'httpd': {
                'enabled': 'true',
                'ensureRunning': 'true',
              },
            },
          },
        },
        'verify_instance_health': {
          'commands': {
            'ELBHealthCheck': {
              'command': ''.join([
                'until [ \"$state\" == \"\\\"InService\\\"\" ]; do ',
                '  state=$(aws --region ',
                self.region,
                ' elb describe-instance-health ',
                '              --load-balancer-name ',
                elasticLoadBalancer.ref,
                '              --instances $(curl -s http://169.254.169.254/latest/meta-data/instance-id) ',
                '              --query InstanceStates[0].State); ',
                '  sleep 10; ',
                'done',
              ]),
            },
          },
        },
      },
    }

    webServerGroup = autoscaling.CfnAutoScalingGroup(self, 'WebServerGroup',
          availability_zones = cdk.Fn.get_azs(None),
          launch_configuration_name = launchConfig.ref,
          min_size = '2',
          max_size = '4',
          load_balancer_names = [
            elasticLoadBalancer.ref,
          ],
        )
    webServerGroup.cfn_options.update_policy = {
      'AutoScalingRollingUpdate': {
        'MaxBatchSize': 1,
        'MinInstancesInService': 1,
        'PauseTime': 'PT15M',
        'WaitOnResourceSignals': True,
      },
    }
    # Outputs
    """
      URL of the website
    """
    self.url = ''.join([
      'http://',
      elasticLoadBalancer.attr_dns_name,
    ])
    cdk.CfnOutput(self, 'CfnOutputURL', 
      key = 'URL',
      description = 'URL of the website',
      value = str(self.url),
    )



