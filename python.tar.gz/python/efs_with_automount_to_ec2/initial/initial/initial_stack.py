from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_autoscaling as autoscaling
import aws_cdk.aws_cloudwatch as cloudwatch
import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_efs as efs
import aws_cdk.aws_elasticloadbalancing as elasticloadbalancing
import aws_cdk.aws_iam as iam
from constructs import Construct

"""
  Multi-AZ EFS with automount EFS.
"""
class InitialStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Applying default props
    props = {
      'instanceType': kwargs.get('instanceType', 't2.micro'),
      'keyName': cdk.CfnParameter(self, 'keyName', 
        type = 'AWS::EC2::KeyPair::KeyName',
        default = str(kwargs.get('keyName')),
        description = 'The EC2 Key Pair to allow SSH access to the instances',
      ),
      'vpc': cdk.CfnParameter(self, 'vpc', 
        type = 'AWS::EC2::VPC::Id',
        default = str(kwargs.get('vpc')),
        description = 'VPC ID for EC2 and Elastic Load Balancer',
      ),
    }

    # Mappings
    ec2RegionMap = {
      'ap-northeast-1': {
        '64': 'ami-d85e7fbf',
      },
      'ap-northeast-2': {
        '64': 'ami-15d5077b',
      },
      'ap-south-1': {
        '64': 'ami-83a8dbec',
      },
      'ap-southeast-1': {
        '64': 'ami-0a19a669',
      },
      'ap-southeast-2': {
        '64': 'ami-807876e3',
      },
      'ca-central-1': {
        '64': 'ami-beea56da',
      },
      'eu-central-1': {
        '64': 'ami-25a97a4a',
      },
      'eu-west-1': {
        '64': 'ami-09447c6f',
      },
      'eu-west-2': {
        '64': 'ami-63342007',
      },
      'sa-east-1': {
        '64': 'ami-8df695e1',
      },
      'us-east-1': {
        '64': 'ami-772aa961',
      },
      'us-east-2': {
        '64': 'ami-8fab8fea',
      },
      'us-west-1': {
        '64': 'ami-1da8f27d',
      },
      'us-west-2': {
        '64': 'ami-7c22b41c',
      },
    }

    # Resources
    efsFileSystem = efs.CfnFileSystem(self, 'EFSFileSystem',
          encrypted = True,
          performance_mode = 'generalPurpose',
        )

    elbSecurityGroup = ec2.CfnSecurityGroup(self, 'ELBSecurityGroup',
          group_description = 'Enable public access HTTP and HTTPS',
          security_group_ingress = [
            {
              'cidrIp': '0.0.0.0/0',
              'fromPort': 80,
              'ipProtocol': 'tcp',
              'toPort': 80,
            },
            {
              'cidrIp': '0.0.0.0/0',
              'fromPort': 443,
              'ipProtocol': 'tcp',
              'toPort': 443,
            },
          ],
          vpc_id = props['vpc'],
        )

    iamAssumeInstanceRole = iam.CfnRole(self, 'IAMAssumeInstanceRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Action': [
                  'sts:AssumeRole',
                ],
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    'ec2.amazonaws.com',
                  ],
                },
              },
            ],
            'Version': '2012-10-17',
          },
          path = '/',
          policies = [
            {
              'policyDocument': {
                'Statement': [
                  {
                    'Action': [
                      'ec2:DescribeTags',
                    ],
                    'Effect': 'Allow',
                    'Resource': '*',
                  },
                  {
                    'Action': [
                      's3:Get*',
                      's3:List*',
                    ],
                    'Effect': 'Allow',
                    'Resource': '*',
                  },
                  {
                    'Action': 'logs:*',
                    'Effect': 'Allow',
                    'Resource': '*',
                  },
                ],
                'Version': '2012-10-17',
              },
              'policyName': '-'.join([
                'IAM',
                'EC2',
                'Policy',
              ]),
            },
          ],
          role_name = '-'.join([
            'IAM',
            'EC2',
            'Role',
          ]),
        )

    elasticLoadBalancer = elasticloadbalancing.CfnLoadBalancer(self, 'ElasticLoadBalancer',
          security_groups = [
            elbSecurityGroup.ref,
          ],
          subnets = props['subnets'],
          cross_zone = True,
          health_check = {
            'healthyThreshold': '3',
            'interval': '30',
            'target': ''.join([
              'HTTP:',
              '80',
              '/',
            ]),
            'timeout': '5',
            'unhealthyThreshold': '5',
          },
          listeners = [
            {
              'instancePort': '80',
              'loadBalancerPort': '80',
              'protocol': 'HTTP',
            },
          ],
        )

    instanceProfile = iam.CfnInstanceProfile(self, 'InstanceProfile',
          instance_profile_name = '-'.join([
            'IAM',
            'InstanceProfile',
          ]),
          path = '/',
          roles = [
            iamAssumeInstanceRole.ref,
          ],
        )

    instanceSecurityGroup = ec2.CfnSecurityGroup(self, 'InstanceSecurityGroup',
          group_description = 'Enable SSH public access and HTTP from the load balancer only',
          security_group_ingress = [
            {
              'cidrIp': '0.0.0.0/0',
              'fromPort': 22,
              'ipProtocol': 'tcp',
              'toPort': 22,
            },
            {
              'fromPort': 80,
              'ipProtocol': 'tcp',
              'sourceSecurityGroupId': elbSecurityGroup.attr_group_id,
              'toPort': 80,
            },
          ],
          vpc_id = props['vpc'],
        )

    efsSecurityGroup = ec2.CfnSecurityGroup(self, 'EFSSecurityGroup',
          group_description = 'Enable NFS access from EC2',
          security_group_ingress = [
            {
              'fromPort': 2049,
              'ipProtocol': 'tcp',
              'toPort': 2049,
              'sourceSecurityGroupId': instanceSecurityGroup.attr_group_id,
            },
          ],
          vpc_id = props['vpc'],
        )

    launchConfig = autoscaling.CfnLaunchConfiguration(self, 'LaunchConfig',
          iam_instance_profile = instanceProfile.ref,
          image_id = ec2RegionMap[self.region]['64'],
          instance_type = props['instanceType'],
          key_name = props['keyName'],
          security_groups = [
            instanceSecurityGroup.attr_group_id,
          ],
          user_data = cdk.Fn.base64(f""""#!/bin/bash -x\n",
          "export LC_CTYPE=en_US.UTF-8\n",
          "export LC_ALL=en_US.UTF-8\n",
          "apt-get update\n",
          "apt-get install -y curl nfs-common\n",
          "EC2_REGION={self.region}\n",
          "DIR_TGT=/mnt/efs/\n",
          "EFS_FILE_SYSTEM_ID={efsFileSystem.ref}\n"
          "mkdir -p $DIR_TGT\n",
          "DIR_SRC=$EFS_FILE_SYSTEM_ID.efs.$EC2_REGION.amazonaws.com\n",
          "mount -t nfs4 -o nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2 $DIR_SRC:/ $DIR_TGT\n""""),
        )

    autoScalingGroup = autoscaling.CfnAutoScalingGroup(self, 'AutoScalingGroup',
          launch_configuration_name = launchConfig.ref,
          load_balancer_names = [
            elasticLoadBalancer.ref,
          ],
          max_size = '3',
          min_size = '1',
          vpc_zone_identifier = props['subnets'],
        )

    efsMountTarget1 = efs.CfnMountTarget(self, 'EFSMountTarget1',
          file_system_id = efsFileSystem.ref,
          security_groups = [
            efsSecurityGroup.attr_group_id,
          ],
          subnet_id = cdk.Fn.select(0, props['subnets']),
        )

    efsMountTarget2 = efs.CfnMountTarget(self, 'EFSMountTarget2',
          file_system_id = efsFileSystem.ref,
          security_groups = [
            efsSecurityGroup.attr_group_id,
          ],
          subnet_id = cdk.Fn.select(1, props['subnets']),
        )

    efsMountTarget3 = efs.CfnMountTarget(self, 'EFSMountTarget3',
          file_system_id = efsFileSystem.ref,
          security_groups = [
            efsSecurityGroup.attr_group_id,
          ],
          subnet_id = cdk.Fn.select(2, props['subnets']),
        )

    efsMountTarget4 = efs.CfnMountTarget(self, 'EFSMountTarget4',
          file_system_id = efsFileSystem.ref,
          security_groups = [
            efsSecurityGroup.attr_group_id,
          ],
          subnet_id = cdk.Fn.select(3, props['subnets']),
        )

    scaleDownPolicy = autoscaling.CfnScalingPolicy(self, 'ScaleDownPolicy',
          adjustment_type = 'ChangeInCapacity',
          auto_scaling_group_name = autoScalingGroup.ref,
          cooldown = '60',
          scaling_adjustment = -1,
        )

    scaleUpPolicy = autoscaling.CfnScalingPolicy(self, 'ScaleUpPolicy',
          adjustment_type = 'ChangeInCapacity',
          auto_scaling_group_name = autoScalingGroup.ref,
          cooldown = '60',
          scaling_adjustment = 1,
        )

    cpuAlarmHigh = cloudwatch.CfnAlarm(self, 'CPUAlarmHigh',
          alarm_actions = [
            scaleUpPolicy.ref,
          ],
          alarm_description = 'Scale-up if CPU > 90% for 10 minutes',
          comparison_operator = 'GreaterThanThreshold',
          dimensions = [
            {
              'name': 'AutoScalingGroupName',
              'value': autoScalingGroup.ref,
            },
          ],
          evaluation_periods = 2,
          metric_name = 'CPUUtilization',
          namespace = 'AWS/EC2',
          period = 300,
          statistic = 'Average',
          threshold = 90,
        )

    cpuAlarmLow = cloudwatch.CfnAlarm(self, 'CPUAlarmLow',
          alarm_actions = [
            scaleDownPolicy.ref,
          ],
          alarm_description = 'Scale-down if CPU < 70% for 10 minutes',
          comparison_operator = 'LessThanThreshold',
          dimensions = [
            {
              'name': 'AutoScalingGroupName',
              'value': autoScalingGroup.ref,
            },
          ],
          evaluation_periods = 2,
          metric_name = 'CPUUtilization',
          namespace = 'AWS/EC2',
          period = 300,
          statistic = 'Average',
          threshold = 70,
        )

    # Outputs
    """
      AutoScaling Group Name
    """
    self.auto_scaling_group = autoScalingGroup.ref
    cdk.CfnOutput(self, 'CfnOutputAutoScalingGroup', 
      key = 'AutoScalingGroup',
      description = 'AutoScaling Group Name',
      export_name = f"""{self.stack_name}-AutoScalingGroup""",
      value = str(self.auto_scaling_group),
    )

    """
      Stack Name
    """
    self.stack_name = self.stack_name
    cdk.CfnOutput(self, 'CfnOutputStackName', 
      key = 'StackName',
      description = 'Stack Name',
      value = str(self.stack_name),
    )

    """
      The URL of the website
    """
    self.url = ''.join([
      'http://',
      elasticLoadBalancer.attr_dns_name,
    ])
    cdk.CfnOutput(self, 'CfnOutputURL', 
      key = 'URL',
      description = 'The URL of the website',
      value = str(self.url),
    )



