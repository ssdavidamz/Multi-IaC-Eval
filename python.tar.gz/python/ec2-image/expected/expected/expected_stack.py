from aws_cdk import Stack
import aws_cdk as cdk
import aws_cdk.aws_cloudwatch as cloudwatch
import aws_cdk.aws_iam as iam
import aws_cdk.aws_imagebuilder as imagebuilder
import aws_cdk.aws_logs as logs
import aws_cdk.aws_s3 as s3
import aws_cdk.aws_sns as sns
import aws_cdk.aws_ssm as ssm
from constructs import Construct

"""
  This stack automates the creation of an EC2 AMI image using Amazon Linux 2.
  It also creates the related resources such as roles and policies.

"""
class ExpectedStack(Stack):
  def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    super().__init__(scope, construct_id, **kwargs)

    # Resources
    al2ssmImageRecipe = imagebuilder.CfnImageRecipe(self, 'AL2SSMImageRecipe',
          name = 'AL2-SSM',
          version = '0.0.1',
          parent_image = f"""arn:{self.partition}:imagebuilder:{self.region}:aws:image/amazon-linux-2-x86/x.x.x""",
          components = [
            {
              'componentArn': f"""arn:{self.partition}:imagebuilder:{self.region}:aws:component/update-linux/x.x.x""",
            },
          ],
          additional_instance_configuration = {
            'userDataOverride': cdk.Fn.base64(f"""#!/bin/bash
            sudo yum install -y https://s3.{self.region}.{self.url_suffix}/amazon-ssm-{self.region}/latest/linux_amd64/amazon-ssm-agent.rpm
            """),
          },
        )
    al2ssmImageRecipe.cfn_options.metadata = {
      'Comment': 'An image builder recipe to build the latest version of Amazon Linux 2 with SSM support',
    }

    imageBuilderInstanceRole = iam.CfnRole(self, 'ImageBuilderInstanceRole',
          assume_role_policy_document = {
            'Statement': [
              {
                'Action': [
                  'sts:AssumeRole',
                ],
                'Effect': 'Allow',
                'Principal': {
                  'Service': [
                    f"""ec2.{self.url_suffix}""",
                  ],
                },
              },
            ],
            'Version': '2012-10-17',
          },
          path = '/imagebuilder/',
        )
    imageBuilderInstanceRole.cfn_options.metadata = {
      'Comment': 'Role to be used by instance during image build.',
    }

    imageBuilderInstanceTopic = sns.CfnTopic(self, 'ImageBuilderInstanceTopic',
          topic_name = 'ImageBuilderInstanceTopic',
        )

    imageBuilderLogBucket = s3.CfnBucket(self, 'ImageBuilderLogBucket',
          bucket_encryption = {
            'serverSideEncryptionConfiguration': [
              {
                'serverSideEncryptionByDefault': {
                  'sseAlgorithm': 'AES256',
                },
              },
            ],
          },
          public_access_block_configuration = {
            'blockPublicAcls': True,
            'ignorePublicAcls': True,
            'blockPublicPolicy': True,
            'restrictPublicBuckets': True,
          },
          object_lock_enabled = False,
          versioning_configuration = {
            'status': 'Enabled',
          },
        )
    imageBuilderLogBucket.cfn_options.metadata = {
      'Comment': 'An S3 bucket to hold image builder logs',
      'guard': {
        'SuppressedRules': [
          'S3_BUCKET_DEFAULT_LOCK_ENABLED',
          'S3_BUCKET_REPLICATION_ENABLED',
          'S3_BUCKET_LOGGING_ENABLED',
        ],
      },
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_18',
            'comment': 'This is a log bucket',
          },
        ],
      },
    }

    imageBuilderLogGroup = logs.CfnLogGroup(self, 'ImageBuilderLogGroup',
          log_group_name = '/aws/imagebuilder/AL2-SSM',
          retention_in_days = 3,
        )
    imageBuilderLogGroup.cfn_options.metadata = {
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_158',
            'comment': 'Log groups are encrypted by default',
          },
        ],
      },
      'guard': {
        'SuppressedRules': [
          'CLOUDWATCH_LOG_GROUP_ENCRYPTED',
        ],
      },
    }
    imageBuilderLogGroup.cfn_options.deletion_policy = cdk.CfnDeletionPolicy.DELETE

    imageBuilderInstancePolicy = iam.CfnPolicy(self, 'ImageBuilderInstancePolicy',
          policy_name = 'imagebuilder',
          policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Action': [
                  'ssm:DescribeAssociation',
                  'ssm:GetDeployablePatchSnapshotForInstance',
                  'ssm:GetDocument',
                  'ssm:DescribeDocument',
                  'ssm:GetManifest',
                  'ssm:GetParameter',
                  'ssm:GetParameters',
                  'ssm:ListAssociations',
                  'ssm:ListInstanceAssociations',
                  'ssm:PutInventory',
                  'ssm:PutComplianceItems',
                  'ssm:PutConfigurePackageResult',
                  'ssm:UpdateAssociationStatus',
                  'ssm:UpdateInstanceAssociationStatus',
                  'ssm:UpdateInstanceInformation',
                ],
                'Effect': 'Allow',
                'Resource': '*',
              },
              {
                'Action': [
                  'ssmmessages:CreateControlChannel',
                  'ssmmessages:CreateDataChannel',
                  'ssmmessages:OpenControlChannel',
                  'ssmmessages:OpenDataChannel',
                ],
                'Effect': 'Allow',
                'Resource': '*',
              },
              {
                'Action': [
                  'ec2messages:AcknowledgeMessage',
                  'ec2messages:DeleteMessage',
                  'ec2messages:FailMessage',
                  'ec2messages:GetEndpoint',
                  'ec2messages:GetMessages',
                  'ec2messages:SendReply',
                ],
                'Effect': 'Allow',
                'Resource': '*',
              },
              {
                'Effect': 'Allow',
                'Action': [
                  'imagebuilder:GetComponent',
                ],
                'Resource': '*',
              },
              {
                'Effect': 'Allow',
                'Action': [
                  'kms:Decrypt',
                ],
                'Resource': '*',
                'Condition': {
                  'ForAnyValue:StringEquals': {
                    'kms:EncryptionContextKeys': 'aws:imagebuilder:arn',
                    'aws:CalledVia': [
                      'imagebuilder.amazonaws.com',
                    ],
                  },
                },
              },
              {
                'Effect': 'Allow',
                'Action': [
                  's3:GetObject',
                ],
                'Resource': 'arn:aws:s3:::ec2imagebuilder*',
              },
              {
                'Effect': 'Allow',
                'Action': [
                  'logs:CreateLogStream',
                  'logs:CreateLogGroup',
                  'logs:PutLogEvents',
                ],
                'Resource': 'arn:aws:logs:*:*:log-group:/aws/imagebuilder/*',
              },
            ],
          },
          roles = [
            imageBuilderInstanceRole.ref,
          ],
        )
    imageBuilderInstancePolicy.cfn_options.metadata = {
      'Comment': 'An IAM policy to give EC2 Image Builder and SSM permissions to build images.\nThis policy is based on AmazonSSMManagedInstanceCore and EC2InstanceProfileForImageBuilder.\n',
      'cfn-lint': {
        'config': {
          'ignore_checks': [
            'W3005',
          ],
        },
      },
      'checkov': {
        'skip': [
          {
            'id': 'CKV_AWS_111',
            'comment': 'Resource Arns are not supported for ssmmessages and ec2messages',
          },
          {
            'id': 'CKV_AWS_108',
            'commment': 'Image builder does not allow specific resources to be named for creation',
          },
        ],
      },
    }
    imageBuilderInstancePolicy.add_dependency(imageBuilderInstanceRole)

    imageBuilderInstanceProfile = iam.CfnInstanceProfile(self, 'ImageBuilderInstanceProfile',
          path = '/imagebuilder/',
          roles = [
            imageBuilderInstanceRole.ref,
          ],
        )

    imageBuilderInstanceSubscription = sns.CfnSubscription(self, 'ImageBuilderInstanceSubscription',
          protocol = 'email',
          endpoint = 'example@example.com',
          topic_arn = imageBuilderInstanceTopic.ref,
        )

    imageBuilderLogPolicy = iam.CfnPolicy(self, 'ImageBuilderLogPolicy',
          policy_name = 'ImageBuilderLogBucketPolicy',
          roles = [
            imageBuilderInstanceRole.ref,
          ],
          policy_document = {
            'Version': '2012-10-17',
            'Statement': [
              {
                'Action': [
                  's3:PutObject',
                ],
                'Effect': 'Allow',
                'Resource': [
                  f"""arn:{self.partition}:s3:::{imageBuilderLogBucket.ref}/*""",
                ],
              },
            ],
          },
        )
    imageBuilderLogPolicy.cfn_options.metadata = {
      'Comment': 'A policy to allow the instance to save log files to the log bucket',
    }

    imageBuilderConfig = imagebuilder.CfnInfrastructureConfiguration(self, 'ImageBuilderConfig',
          name = 'AL2-SSM',
          instance_profile_name = imageBuilderInstanceProfile.ref,
          logging = {
            's3Logs': {
              's3BucketName': imageBuilderLogBucket.ref,
            },
          },
          terminate_instance_on_failure = False,
        )

    al2ssmImage = imagebuilder.CfnImage(self, 'AL2SSMImage',
          image_recipe_arn = al2ssmImageRecipe.ref,
          infrastructure_configuration_arn = imageBuilderConfig.ref,
        )
    al2ssmImage.cfn_options.metadata = {
      'Comment': 'An image builder image',
    }

    al2ssmImageParameter = ssm.CfnParameter(self, 'AL2SSMImageParameter',
          description = 'AL2 with SSM image id',
          name = '/images/AL2SSMImageId',
          type = 'String',
          value = al2ssmImage.attr_image_id,
        )
    al2ssmImageParameter.cfn_options.metadata = {
      'Comment': 'An SSM Parameter to store the image id',
    }

    imageBuilderInstanceAlarm = cloudwatch.CfnAlarm(self, 'ImageBuilderInstanceAlarm',
          alarm_name = 'ImageBuilderInstanceAlarm',
          alarm_description = 'Alarm when average CPU utilization exceeds 80% for 5 minutes',
          metrics = [
            {
              'id': 'm1',
              'metricStat': {
                'metric': {
                  'namespace': 'AWS/EC2',
                  'metricName': 'CPUUtilization',
                  'dimensions': [
                    {
                      'name': 'ImageId',
                      'value': al2ssmImage.attr_image_id,
                    },
                  ],
                },
                'period': 300,
                'stat': 'Average',
              },
            },
          ],
          comparison_operator = 'GreaterThanThreshold',
          threshold = 80,
          evaluation_periods = 1,
          treat_missing_data = 'notBreaching',
          alarm_actions = [
            imageBuilderInstanceTopic.ref,
          ],
        )


